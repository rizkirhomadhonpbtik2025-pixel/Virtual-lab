import test from 'node:test';
import assert from 'node:assert/strict';
import {
  buildCsvContent,
  buildTsvContent,
  escapeCsvCell,
  parseCsvScoreRows,
} from './spreadsheetExport';
import { SpreadsheetScoreRow } from '../types';

const SAMPLE_ROWS: SpreadsheetScoreRow[] = [
  {
    id: 'row-1',
    timestamp: '23/11/2026 08:30:00',
    nama: 'Budi Santoso',
    kelas: 'X-1',
    noAbsen: '12',
    skor: 80,
    benar: 4,
    salah: 1,
    predikat: 'Sangat Baik',
  },
  {
    id: 'row-2',
    timestamp: '23/11/2026 08:35:00',
    nama: 'Siti, Aminah',
    kelas: 'X IPA 1',
    noAbsen: '5',
    skor: 100,
    benar: 5,
    salah: 0,
    predikat: 'Istimewa (Sempurna)',
  },
];

test('escapeCsvCell handles commas, quotes, and formula prefixes', () => {
  assert.equal(escapeCsvCell('Siti, Aminah'), '"Siti, Aminah"');
  assert.equal(escapeCsvCell('Kata "Penting"'), '"Kata ""Penting"""');
  assert.equal(escapeCsvCell('=SUM(A1:A5)'), "'=SUM(A1:A5)");
});

test('buildCsvContent generates UTF-8 BOM CSV with 8 summary columns and round-trips cleanly', () => {
  const csv = buildCsvContent(SAMPLE_ROWS);
  assert.ok(csv.startsWith('\uFEFFWaktu Kirim,Nama Siswa,Kelas,No. Urut Absen,Skor Total,Jumlah Benar,Jumlah Salah,Predikat'));

  const parsed = parseCsvScoreRows(csv);
  assert.equal(parsed.length, 2);
  assert.equal(parsed[0].nama, 'Budi Santoso');
  assert.equal(parsed[0].benar, 4);
  assert.equal(parsed[0].salah, 1);
  assert.equal(parsed[1].nama, 'Siti, Aminah');
  assert.equal(parsed[1].skor, 100);
});

test('buildTsvContent formats tab-separated rows ready for Google Sheets paste', () => {
  const tsv = buildTsvContent(SAMPLE_ROWS, true);
  const lines = tsv.split('\n');
  assert.equal(lines.length, 3);
  assert.equal(lines[0].split('\t').length, 8);
  assert.equal(lines[1].split('\t')[1], 'Budi Santoso');
  assert.equal(lines[1].split('\t')[5], '4');
  assert.equal(lines[1].split('\t')[6], '1');
});
