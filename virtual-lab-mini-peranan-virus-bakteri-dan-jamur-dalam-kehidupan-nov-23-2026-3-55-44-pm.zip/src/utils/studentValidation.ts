import { SpreadsheetScoreRow, StudentIdentity } from '../types';
import { QuizScoreResult } from './quizLogic';

export interface StudentValidationResult {
  isValid: boolean;
  errors: Partial<Record<keyof StudentIdentity, string>>;
}

export const SPREADSHEET_HEADERS = [
  'Waktu Kirim',
  'Nama Siswa',
  'Kelas',
  'No. Urut Absen',
  'Skor Total',
  'Jumlah Benar',
  'Jumlah Salah',
  'Predikat',
];

export function validateStudentIdentity(identity: StudentIdentity): StudentValidationResult {
  const errors: Partial<Record<keyof StudentIdentity, string>> = {};

  const trimmedName = identity.nama.trim();
  if (!trimmedName) {
    errors.nama = 'Nama lengkap siswa wajib diisi.';
  } else if (trimmedName.length < 2) {
    errors.nama = 'Nama lengkap minimal terdiri dari 2 karakter.';
  }

  const trimmedClass = identity.kelas.trim();
  if (!trimmedClass) {
    errors.kelas = 'Kelas wajib diisi (contoh: X-1 atau X IPA 1).';
  }

  const trimmedAbsen = identity.noAbsen.trim();
  const absenNum = Number(trimmedAbsen);
  if (!trimmedAbsen) {
    errors.noAbsen = 'Nomor urut absen wajib diisi.';
  } else if (!Number.isInteger(absenNum) || absenNum < 1 || absenNum > 99) {
    errors.noAbsen = 'Nomor urut absen harus berupa angka bulat antara 1 sampai 99.';
  }

  return {
    isValid: Object.keys(errors).length === 0,
    errors,
  };
}

export function buildSpreadsheetScoreRecord(
  identity: StudentIdentity,
  scoreResult: QuizScoreResult,
  timestamp?: string,
  id?: string
): SpreadsheetScoreRow {
  const nowStr =
    timestamp ||
    new Date().toLocaleString('id-ID', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
    });

  const wrongCount = Math.max(0, scoreResult.totalQuestions - scoreResult.correctCount);

  return {
    id: id || `score-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
    timestamp: nowStr,
    nama: identity.nama.trim() || 'Siswa',
    kelas: identity.kelas.trim() || '-',
    noAbsen: identity.noAbsen.trim() || '-',
    skor: scoreResult.score,
    benar: scoreResult.correctCount,
    salah: wrongCount,
    predikat: scoreResult.predicate,
  };
}

export function scoreRowToValues(row: SpreadsheetScoreRow): (string | number)[] {
  return [
    row.timestamp,
    row.nama,
    row.kelas,
    row.noAbsen,
    row.skor,
    row.benar,
    row.salah,
    row.predikat,
  ];
}

export function buildSpreadsheetRowValues(
  identity: StudentIdentity,
  scoreResult: QuizScoreResult,
  timestamp?: string
): (string | number)[] {
  return scoreRowToValues(buildSpreadsheetScoreRecord(identity, scoreResult, timestamp));
}
