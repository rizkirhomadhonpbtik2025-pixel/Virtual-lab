import test from 'node:test';
import assert from 'node:assert/strict';
import {
  validateStudentIdentity,
  buildSpreadsheetRowValues,
  buildSpreadsheetScoreRecord,
  SPREADSHEET_HEADERS,
} from './studentValidation';
import { calculateQuizScore } from './quizLogic';
import { QuizQuestion } from '../types';

test('validateStudentIdentity rejects empty fields and invalid absen', () => {
  const emptyRes = validateStudentIdentity({ nama: '', kelas: '', noAbsen: '' });
  assert.equal(emptyRes.isValid, false);
  assert.ok(emptyRes.errors.nama);
  assert.ok(emptyRes.errors.kelas);
  assert.ok(emptyRes.errors.noAbsen);

  const invalidAbsen = validateStudentIdentity({ nama: 'Siti Aminah', kelas: 'X-2', noAbsen: '0' });
  assert.equal(invalidAbsen.isValid, false);
  assert.ok(invalidAbsen.errors.noAbsen);
  assert.equal(invalidAbsen.errors.nama, undefined);
  assert.equal(invalidAbsen.errors.kelas, undefined);
});

test('validateStudentIdentity accepts valid student identity', () => {
  const valid = validateStudentIdentity({ nama: 'Budi Santoso', kelas: 'X IPA 1', noAbsen: '12' });
  assert.equal(valid.isValid, true);
  assert.deepEqual(valid.errors, {});
});

test('buildSpreadsheetRowValues and buildSpreadsheetScoreRecord align with SPREADSHEET_HEADERS', () => {
  const questions: QuizQuestion[] = [1, 2, 3, 4, 5].map((id) => ({
    id,
    topic: 'Virus',
    question: `Pertanyaan ${id}`,
    options: ['Opsi A', 'Opsi B', 'Opsi C', 'Opsi D'],
    correctIndex: 1,
    explanation: 'Penjelasan',
  }));
  const scoreResult = calculateQuizScore({ 1: 1, 2: 0, 3: 1, 4: 1, 5: 1 }, questions);
  const record = buildSpreadsheetScoreRecord(
    { nama: 'Ani Wijaya', kelas: 'X-3', noAbsen: '5' },
    scoreResult,
    '12/11/2026 10:00:00',
    'rec-1'
  );
  assert.equal(record.id, 'rec-1');
  assert.equal(record.skor, 80);
  assert.equal(record.benar, 4);
  assert.equal(record.salah, 1);

  const row = buildSpreadsheetRowValues(
    { nama: 'Ani Wijaya', kelas: 'X-3', noAbsen: '5' },
    scoreResult,
    '12/11/2026 10:00:00'
  );

  assert.equal(row.length, SPREADSHEET_HEADERS.length);
  assert.deepEqual(SPREADSHEET_HEADERS, [
    'Waktu Kirim',
    'Nama Siswa',
    'Kelas',
    'No. Urut Absen',
    'Skor Total',
    'Jumlah Benar',
    'Jumlah Salah',
    'Predikat',
  ]);
  assert.equal(row[0], '12/11/2026 10:00:00');
  assert.equal(row[1], 'Ani Wijaya');
  assert.equal(row[2], 'X-3');
  assert.equal(row[3], '5');
  assert.equal(row[4], 80);
  assert.equal(row[5], 4);
  assert.equal(row[6], 1);
  assert.equal(row[7], 'Sangat Baik');
});
