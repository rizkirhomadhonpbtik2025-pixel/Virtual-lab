import { SpreadsheetScoreRow } from '../types';
import { SPREADSHEET_HEADERS, scoreRowToValues } from './studentValidation';

const FORMULA_PREFIX_RE = /^[=+\-@\t\r]/;

export function sanitizeSpreadsheetText(value: string | number): string {
  const str = String(value ?? '');
  return FORMULA_PREFIX_RE.test(str) ? `'${str}` : str;
}

export function escapeCsvCell(value: string | number): string {
  const safe = sanitizeSpreadsheetText(value);
  if (/[",\n\r]/.test(safe)) {
    return `"${safe.replace(/"/g, '""')}"`;
  }
  return safe;
}

export function buildCsvContent(rows: SpreadsheetScoreRow[]): string {
  const headerLine = SPREADSHEET_HEADERS.map(escapeCsvCell).join(',');
  const dataLines = rows.map((row) => scoreRowToValues(row).map(escapeCsvCell).join(','));
  return `\uFEFF${[headerLine, ...dataLines].join('\r\n')}`;
}

export function buildTsvContent(rows: SpreadsheetScoreRow[], includeHeaders = true): string {
  const cleanCell = (val: string | number) =>
    sanitizeSpreadsheetText(val).replace(/[\t\r\n]+/g, ' ');
  const lines: string[] = [];
  if (includeHeaders) {
    lines.push(SPREADSHEET_HEADERS.map(cleanCell).join('\t'));
  }
  for (const row of rows) {
    lines.push(scoreRowToValues(row).map(cleanCell).join('\t'));
  }
  return lines.join('\n');
}

function parseCsvLine(line: string): string[] {
  const cells: string[] = [];
  let current = '';
  let inQuotes = false;

  for (let i = 0; i < line.length; i += 1) {
    const ch = line[i];
    if (inQuotes) {
      if (ch === '"' && line[i + 1] === '"') {
        current += '"';
        i += 1;
      } else if (ch === '"') {
        inQuotes = false;
      } else {
        current += ch;
      }
    } else if (ch === '"') {
      inQuotes = true;
    } else if (ch === ',') {
      cells.push(current);
      current = '';
    } else {
      current += ch;
    }
  }
  cells.push(current);
  return cells;
}

export function parseCsvScoreRows(csvText: string): SpreadsheetScoreRow[] {
  const normalized = csvText.replace(/^\uFEFF/, '').replace(/\r\n/g, '\n').replace(/\r/g, '\n');
  const lines = normalized.split('\n').filter((l) => l.trim().length > 0);
  if (lines.length === 0) return [];

  const rows: SpreadsheetScoreRow[] = [];
  const startIdx = lines[0].toLowerCase().includes('nama siswa') ? 1 : 0;

  for (let i = startIdx; i < lines.length; i += 1) {
    const cols = parseCsvLine(lines[i]);
    if (cols.length < 7) continue;

    const nama = (cols[1] || '').trim();
    if (!nama) continue;

    const skor = Number(cols[4]);
    const benar = Number(cols[5]);
    const salah = Number(cols[6]);

    rows.push({
      id: `imp-${Date.now()}-${i}-${Math.random().toString(36).slice(2, 6)}`,
      timestamp: (cols[0] || '-').trim(),
      nama,
      kelas: (cols[2] || '-').trim(),
      noAbsen: (cols[3] || '-').trim(),
      skor: Number.isFinite(skor) ? skor : 0,
      benar: Number.isFinite(benar) ? benar : 0,
      salah: Number.isFinite(salah) ? salah : 0,
      predikat: (cols[7] || '-').trim(),
    });
  }

  return rows;
}
