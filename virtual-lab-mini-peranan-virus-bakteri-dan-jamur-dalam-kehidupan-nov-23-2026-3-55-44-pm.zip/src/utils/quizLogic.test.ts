import test from 'node:test';
import assert from 'node:assert/strict';
import { calculateQuizScore, validateWorksheetRow, countCompletedRows } from './quizLogic';
import { QuizQuestion, WorksheetRow } from '../types';

const mockQuestions: QuizQuestion[] = [
  {
    id: 1,
    topic: 'Virus',
    question: 'Soal 1',
    options: ['A', 'B', 'C', 'D'],
    correctIndex: 2,
    explanation: 'Pembahasan 1',
  },
  {
    id: 2,
    topic: 'Bakteri',
    question: 'Soal 2',
    options: ['A', 'B', 'C', 'D'],
    correctIndex: 1,
    explanation: 'Pembahasan 2',
  },
  {
    id: 3,
    topic: 'Jamur',
    question: 'Soal 3',
    options: ['A', 'B', 'C', 'D'],
    correctIndex: 0,
    explanation: 'Pembahasan 3',
  },
];

test('calculateQuizScore returns perfect score for all correct answers', () => {
  const userAnswers = { 1: 2, 2: 1, 3: 0 };
  const res = calculateQuizScore(userAnswers, mockQuestions);
  assert.equal(res.correctCount, 3);
  assert.equal(res.totalQuestions, 3);
  assert.equal(res.score, 100);
  assert.equal(res.predicate, 'Sangat Memuaskan (Sempurna)');
  assert.equal(res.results.every((r) => r.isCorrect), true);
});

test('calculateQuizScore returns 0 when all answers are wrong or empty', () => {
  const userAnswers = { 1: 0, 2: 0, 3: 1 };
  const res = calculateQuizScore(userAnswers, mockQuestions);
  assert.equal(res.correctCount, 0);
  assert.equal(res.score, 0);
  assert.equal(res.predicate, 'Perlu Belajar Lagi');
});

test('calculateQuizScore handles partial answers correctly', () => {
  const userAnswers = { 1: 2, 2: 0 }; // Q3 unanswered
  const res = calculateQuizScore(userAnswers, mockQuestions);
  assert.equal(res.correctCount, 1);
  assert.equal(res.totalQuestions, 3);
  assert.equal(res.score, 33);
  assert.equal(res.results[2].userAnswerIndex, null);
  assert.equal(res.results[2].isCorrect, false);
});

test('validateWorksheetRow checks completeness', () => {
  const completeRow: WorksheetRow = {
    id: '1',
    namaOrganisme: 'Rhizobium',
    peranan: 'Fiksasi Nitrogen',
    kategori: 'Menguntungkan',
    alasanSingkat: 'Menyediakan nitrogen bagi tanaman legum',
  };
  const val = validateWorksheetRow(completeRow);
  assert.equal(val.isValid, true);
  assert.equal(val.missingFields.length, 0);

  const incompleteRow: WorksheetRow = {
    id: '2',
    namaOrganisme: '',
    peranan: 'Fermentasi',
    kategori: '',
    alasanSingkat: '',
  };
  const valIncomplete = validateWorksheetRow(incompleteRow);
  assert.equal(valIncomplete.isValid, false);
  assert.deepEqual(valIncomplete.missingFields, ['Nama Organisme', 'Kategori', 'Alasan Singkat']);
});

test('countCompletedRows calculates valid rows correctly', () => {
  const rows: WorksheetRow[] = [
    {
      id: '1',
      namaOrganisme: 'A',
      peranan: 'B',
      kategori: 'Menguntungkan',
      alasanSingkat: 'C',
    },
    {
      id: '2',
      namaOrganisme: '',
      peranan: '',
      kategori: '',
      alasanSingkat: '',
    },
    {
      id: '3',
      namaOrganisme: 'D',
      peranan: 'E',
      kategori: 'Merugikan',
      alasanSingkat: 'F',
    },
  ];
  assert.equal(countCompletedRows(rows), 2);
});
