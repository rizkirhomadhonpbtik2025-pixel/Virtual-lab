import { QuizQuestion, WorksheetRow } from '../types';

export interface QuestionResult {
  questionId: number;
  questionText: string;
  userAnswerIndex: number | null;
  correctAnswerIndex: number;
  isCorrect: boolean;
  explanation: string;
}

export interface QuizScoreResult {
  score: number;
  totalQuestions: number;
  correctCount: number;
  percentage: number;
  predicate: string;
  feedback: string;
  results: QuestionResult[];
}

export function calculateQuizScore(
  userAnswers: Record<number, number>,
  questions: QuizQuestion[]
): QuizScoreResult {
  let correctCount = 0;
  const results: QuestionResult[] = [];

  for (const q of questions) {
    const userAnswer = userAnswers[q.id] !== undefined ? userAnswers[q.id] : null;
    const isCorrect = userAnswer === q.correctIndex;
    if (isCorrect) {
      correctCount++;
    }
    results.push({
      questionId: q.id,
      questionText: q.question,
      userAnswerIndex: userAnswer,
      correctAnswerIndex: q.correctIndex,
      isCorrect,
      explanation: q.explanation,
    });
  }

  const totalQuestions = questions.length;
  const percentage = totalQuestions > 0 ? Math.round((correctCount / totalQuestions) * 100) : 0;
  const score = percentage;

  let predicate = 'Perlu Belajar Lagi';
  let feedback = 'Silakan baca kembali materi di Meja Pengamatan untuk memahami peranan masing-masing mikroorganisme.';

  if (score === 100) {
    predicate = 'Sangat Memuaskan (Sempurna)';
    feedback = 'Luar biasa! Kamu telah menguasai seluruh peranan virus, bakteri, dan jamur dengan sangat tepat.';
  } else if (score >= 80) {
    predicate = 'Sangat Baik';
    feedback = 'Bagus sekali! Pemahamanmu mengenai peranan mikroorganisme sudah sangat mendalam.';
  } else if (score >= 60) {
    predicate = 'Cukup Baik';
    feedback = 'Hasil yang lumayan! Periksa kembali pembahasan nomor yang masih keliru untuk menyempurnakan pemahamanmu.';
  }

  return {
    score,
    totalQuestions,
    correctCount,
    percentage,
    predicate,
    feedback,
    results,
  };
}

export function validateWorksheetRow(row: WorksheetRow): { isValid: boolean; missingFields: string[] } {
  const missingFields: string[] = [];
  if (!row.namaOrganisme || !row.namaOrganisme.trim()) {
    missingFields.push('Nama Organisme');
  }
  if (!row.peranan || !row.peranan.trim()) {
    missingFields.push('Peranan');
  }
  if (!row.kategori || !['Menguntungkan', 'Merugikan'].includes(row.kategori)) {
    missingFields.push('Kategori');
  }
  if (!row.alasanSingkat || !row.alasanSingkat.trim()) {
    missingFields.push('Alasan Singkat');
  }

  return {
    isValid: missingFields.length === 0,
    missingFields,
  };
}

export function countCompletedRows(rows: WorksheetRow[]): number {
  return rows.filter((r) => validateWorksheetRow(r).isValid).length;
}
