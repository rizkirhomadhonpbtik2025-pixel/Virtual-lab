import React, { useState } from 'react';
import { FileText, Plus, Trash2, ArrowRight, ArrowLeft, CheckCircle2, RotateCcw, Printer, Sparkles, AlertCircle } from 'lucide-react';
import { WorksheetRow, OrganismCategory, StudentIdentity } from '../types';
import { validateWorksheetRow, countCompletedRows } from '../utils/quizLogic';
import { SAMPLE_WORKSHEET_ROWS } from '../data/biologyData';
import { ConfirmDialog } from './ConfirmDialog';

interface LembarKerjaProps {
  rows: WorksheetRow[];
  onUpdateRows: (rows: WorksheetRow[]) => void;
  onGoToQuiz: () => void;
  onGoToPengamatan: () => void;
  studentIdentity: StudentIdentity;
  onUpdateIdentity: (identity: StudentIdentity) => void;
}

export const LembarKerja: React.FC<LembarKerjaProps> = ({
  rows,
  onUpdateRows,
  onGoToQuiz,
  onGoToPengamatan,
  studentIdentity,
  onUpdateIdentity,
}) => {
  const [showValidationInfo, setShowValidationInfo] = useState<boolean>(false);
  const [tableNotice, setTableNotice] = useState<string | null>(null);
  const [confirmMode, setConfirmMode] = useState<'sample' | 'reset' | null>(null);

  const handleRowChange = (id: string, field: keyof WorksheetRow, value: string) => {
    setTableNotice(null);
    const updated = rows.map((row) => {
      if (row.id === id) {
        return { ...row, [field]: value };
      }
      return row;
    });
    onUpdateRows(updated);
  };

  const handleAddRow = () => {
    setTableNotice(null);
    const newRow: WorksheetRow = {
      id: `row-${Date.now()}`,
      namaOrganisme: '',
      peranan: '',
      kategori: '',
      alasanSingkat: '',
    };
    onUpdateRows([...rows, newRow]);
  };

  const handleDeleteRow = (id: string) => {
    if (rows.length <= 1) {
      setTableNotice('Tabel pengamatan minimal harus memiliki 1 baris.');
      return;
    }
    setTableNotice(null);
    const updated = rows.filter((row) => row.id !== id);
    onUpdateRows(updated);
  };

  const handleLoadSample = () => {
    setConfirmMode('sample');
  };

  const handleReset = () => {
    setConfirmMode('reset');
  };

  const handleConfirmAction = () => {
    if (confirmMode === 'sample') {
      onUpdateRows(SAMPLE_WORKSHEET_ROWS);
    } else if (confirmMode === 'reset') {
      const emptyRows: WorksheetRow[] = [
        { id: 'row-1', namaOrganisme: '', peranan: '', kategori: '', alasanSingkat: '' },
        { id: 'row-2', namaOrganisme: '', peranan: '', kategori: '', alasanSingkat: '' },
        { id: 'row-3', namaOrganisme: '', peranan: '', kategori: '', alasanSingkat: '' },
        { id: 'row-4', namaOrganisme: '', peranan: '', kategori: '', alasanSingkat: '' },
      ];
      onUpdateRows(emptyRows);
    }
    setTableNotice(null);
    setConfirmMode(null);
  };

  const handlePrint = () => {
    window.print();
  };

  const completedCount = countCompletedRows(rows);

  return (
    <div className="space-y-8 animate-fade-in print:space-y-4">
      {/* Header Lembar Kerja */}
      <div className="bg-white rounded-2xl p-6 sm:p-8 border border-slate-200/80 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4 print:border-none print:shadow-none print:p-0">
        <div>
          <div className="flex items-center gap-2 text-xs font-semibold text-emerald-700 mb-1">
            <FileText className="w-4 h-4" />
            <span>Bagian 3 · Lembar Kerja Siswa (Discovery Worksheet)</span>
          </div>
          <h2 className="text-xl sm:text-2xl font-bold text-slate-900 tracking-tight">
            Lembar Pengamatan & Pengelompokkan Mikroorganisme
          </h2>
          <p className="text-sm text-slate-600 mt-1 max-w-2xl leading-relaxed">
            Ketik hasil pengamatanmu dari Meja Pengamatan ke dalam tabel berikut. Tentukan apakah peranannya menguntungkan atau merugikan beserta alasan singkatnya.
          </p>
        </div>

        {/* Action Controls */}
        <div className="flex flex-wrap items-center gap-2 self-start md:self-auto print:hidden">
          <button
            onClick={onGoToPengamatan}
            className="px-3 py-2 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors flex items-center gap-1.5 focus-visible:outline-2 focus-visible:outline-slate-600"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>Kembali ke Pengamatan</span>
          </button>
          <button
            onClick={handlePrint}
            className="px-3 py-2 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors flex items-center gap-1.5 focus-visible:outline-2 focus-visible:outline-slate-600"
            title="Cetak atau simpan lembar kerja ke PDF"
          >
            <Printer className="w-3.5 h-3.5 text-slate-600" />
            <span>Cetak / PDF</span>
          </button>
          <button
            onClick={onGoToQuiz}
            className="px-4 py-2 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 rounded-lg transition-colors shadow-xs flex items-center gap-1.5 focus-visible:outline-2 focus-visible:outline-emerald-600"
          >
            <span>Lanjut ke Kuis</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Identitas Siswa Card (Terhubung otomatis dengan data registrasi siswa) */}
      <div className="bg-emerald-50/50 rounded-2xl p-5 border border-emerald-200/80 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 text-xs">
        <div>
          <label htmlFor="student-name-input" className="block text-slate-700 font-semibold mb-1">
            Nama Peserta Didik:
          </label>
          <input
            id="student-name-input"
            type="text"
            placeholder="Ketik namamu..."
            value={studentIdentity.nama}
            onChange={(e) => onUpdateIdentity({ ...studentIdentity, nama: e.target.value })}
            className="w-full px-3 py-2 bg-white rounded-lg border border-slate-300 focus:outline-emerald-600 font-medium text-slate-900"
          />
        </div>
        <div>
          <label htmlFor="student-class-input" className="block text-slate-700 font-semibold mb-1">
            Kelas / Fase:
          </label>
          <input
            id="student-class-input"
            type="text"
            value={studentIdentity.kelas}
            onChange={(e) => onUpdateIdentity({ ...studentIdentity, kelas: e.target.value })}
            className="w-full px-3 py-2 bg-white rounded-lg border border-slate-300 focus:outline-emerald-600 font-medium text-slate-900"
          />
        </div>
        <div>
          <label htmlFor="student-absen-input" className="block text-slate-700 font-semibold mb-1">
            No. Urut Absen:
          </label>
          <input
            id="student-absen-input"
            type="number"
            min={1}
            max={99}
            value={studentIdentity.noAbsen}
            onChange={(e) => onUpdateIdentity({ ...studentIdentity, noAbsen: e.target.value })}
            className="w-full px-3 py-2 bg-white rounded-lg border border-slate-300 focus:outline-emerald-600 font-medium text-slate-900"
          />
        </div>
        <div className="flex flex-col justify-end">
          <div className="flex items-center gap-2 p-2 bg-white rounded-lg border border-emerald-200 text-emerald-800">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
            <span className="font-medium">
              Status Isian: <strong>{completedCount} dari {rows.length}</strong> baris lengkap
            </span>
          </div>
        </div>
      </div>

      {/* Tabel Isian Lembar Kerja */}
      <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs overflow-hidden">
        {/* Table Top Controls */}
        <div className="p-4 bg-slate-50 border-b border-slate-200 flex flex-wrap items-center justify-between gap-3 text-xs print:hidden">
          <div className="flex items-center gap-2">
            <span className="font-semibold text-slate-700">Tabel Hasil Pengamatan:</span>
            <span className="text-slate-400">·</span>
            <span className="text-slate-500">Minimal 3 baris terisi</span>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={handleLoadSample}
              className="px-2.5 py-1.5 bg-white text-emerald-700 border border-emerald-300 hover:bg-emerald-50 rounded-lg font-medium transition flex items-center gap-1"
            >
              <Sparkles className="w-3 h-3 text-emerald-600" />
              <span>Contoh Isian</span>
            </button>
            <button
              onClick={handleReset}
              className="px-2.5 py-1.5 bg-white text-slate-600 border border-slate-200 hover:bg-slate-100 rounded-lg font-medium transition flex items-center gap-1"
            >
              <RotateCcw className="w-3 h-3" />
              <span>Reset Tabel</span>
            </button>
            <button
              onClick={handleAddRow}
              className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg font-semibold transition flex items-center gap-1.5 shadow-xs"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Tambah Baris</span>
            </button>
          </div>
        </div>

        {/* Responsive Table Container */}
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs sm:text-sm border-collapse">
            <thead>
              <tr className="bg-slate-100/90 text-slate-700 font-semibold border-b border-slate-200">
                <th className="py-3 px-3 w-10 text-center">No</th>
                <th className="py-3 px-3 w-48 sm:w-56">Nama Organisme</th>
                <th className="py-3 px-3 min-w-[200px]">Peranan dalam Kehidupan</th>
                <th className="py-3 px-3 w-36">Kategori</th>
                <th className="py-3 px-3 min-w-[200px]">Alasan Singkat</th>
                <th className="py-3 px-2 w-12 text-center print:hidden">Aksi</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200">
              {rows.map((row, index) => {
                const validation = validateWorksheetRow(row);
                return (
                  <tr
                    key={row.id}
                    className={`hover:bg-slate-50/80 transition-colors ${
                      validation.isValid ? 'bg-emerald-50/20' : ''
                    }`}
                  >
                    {/* No */}
                    <td className="py-2.5 px-3 text-center font-bold text-slate-500">
                      {index + 1}
                    </td>

                    {/* Nama Organisme */}
                    <td className="py-2.5 px-3">
                      <input
                        type="text"
                        placeholder="Misal: Bakteriofag"
                        value={row.namaOrganisme}
                        onChange={(e) => handleRowChange(row.id, 'namaOrganisme', e.target.value)}
                        className="w-full px-2.5 py-1.5 bg-white border border-slate-300 rounded-md focus:outline-emerald-600 text-slate-900 text-xs sm:text-sm"
                        aria-label={`Nama Organisme baris ${index + 1}`}
                      />
                    </td>

                    {/* Peranan */}
                    <td className="py-2.5 px-3">
                      <input
                        type="text"
                        placeholder="Misal: Pembuatan yoghurt fermentasi"
                        value={row.peranan}
                        onChange={(e) => handleRowChange(row.id, 'peranan', e.target.value)}
                        className="w-full px-2.5 py-1.5 bg-white border border-slate-300 rounded-md focus:outline-emerald-600 text-slate-900 text-xs sm:text-sm"
                        aria-label={`Peranan baris ${index + 1}`}
                      />
                    </td>

                    {/* Kategori Dropdown */}
                    <td className="py-2.5 px-3">
                      <select
                        value={row.kategori}
                        onChange={(e) => handleRowChange(row.id, 'kategori', e.target.value as OrganismCategory)}
                        className={`w-full px-2.5 py-1.5 rounded-md font-medium text-xs sm:text-sm border focus:outline-emerald-600 ${
                          row.kategori === 'Menguntungkan'
                            ? 'bg-emerald-50 border-emerald-300 text-emerald-800 font-semibold'
                            : row.kategori === 'Merugikan'
                            ? 'bg-rose-50 border-rose-300 text-rose-800 font-semibold'
                            : 'bg-white border-slate-300 text-slate-600'
                        }`}
                        aria-label={`Kategori baris ${index + 1}`}
                      >
                        <option value="">-- Pilih --</option>
                        <option value="Menguntungkan">Menguntungkan</option>
                        <option value="Merugikan">Merugikan</option>
                      </select>
                    </td>

                    {/* Alasan Singkat */}
                    <td className="py-2.5 px-3">
                      <input
                        type="text"
                        placeholder="Misal: Menghasilkan asam laktat & mengentalkan susu"
                        value={row.alasanSingkat}
                        onChange={(e) => handleRowChange(row.id, 'alasanSingkat', e.target.value)}
                        className="w-full px-2.5 py-1.5 bg-white border border-slate-300 rounded-md focus:outline-emerald-600 text-slate-900 text-xs sm:text-sm"
                        aria-label={`Alasan Singkat baris ${index + 1}`}
                      />
                    </td>

                    {/* Action Button: Delete */}
                    <td className="py-2.5 px-2 text-center print:hidden">
                      <button
                        onClick={() => handleDeleteRow(row.id)}
                        className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-md transition"
                        title="Hapus baris ini"
                        aria-label={`Hapus baris ${index + 1}`}
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>

        {/* Table Footer */}
        <div className="p-4 bg-slate-50 border-t border-slate-200 flex flex-wrap items-center justify-between gap-3 text-xs text-slate-500">
          <div className="flex items-center gap-2">
            <button
              onClick={handleAddRow}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-white border border-slate-300 hover:bg-slate-100 rounded-lg font-medium text-slate-700 transition"
            >
              <Plus className="w-3.5 h-3.5 text-emerald-600" />
              <span>Tambah Baris Baru</span>
            </button>
            <button
              onClick={() => setShowValidationInfo(!showValidationInfo)}
              className="text-xs text-emerald-700 hover:underline font-medium ml-2"
            >
              {showValidationInfo ? 'Sembunyikan Bantuan' : 'Cek Status Pengisian'}
            </button>
          </div>

          <div className="flex items-center gap-3">
            <span>Total baris: <strong>{rows.length}</strong></span>
            <span>·</span>
            <span>Lengkap: <strong className="text-emerald-700">{completedCount}</strong></span>
          </div>
        </div>
      </div>

      {/* Validation / Guidance Box */}
      {showValidationInfo && (
        <div className="bg-amber-50 rounded-2xl p-4 border border-amber-200 text-xs text-amber-900 flex items-start gap-3">
          <AlertCircle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
          <div className="space-y-1">
            <strong className="block font-semibold">Tips Pengisian Lembar Kerja:</strong>
            <p>
              Pastikan setiap baris memuat Nama Organisme, Peranan yang jelas dalam kehidupan, Kategori (Menguntungkan atau Merugikan), dan Alasan Singkat mekanismenya. Bila kamu membutuhkan data kembali, kamu dapat mengeklik tombol &quot;Kembali ke Pengamatan&quot; sewaktu-waktu tanpa kehilangan data yang sudah diketik!
            </p>
          </div>
        </div>
      )}

      {/* Inline Table Notice */}
      {tableNotice && (
        <div role="alert" className="bg-amber-50 rounded-2xl p-4 border border-amber-200 text-xs text-amber-900 flex items-center gap-2.5">
          <AlertCircle className="w-4 h-4 text-amber-600 shrink-0" />
          <span>{tableNotice}</span>
        </div>
      )}

      {/* Navigation Footer */}
      <div className="bg-slate-50 border border-slate-200/60 rounded-2xl p-5 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-600 print:hidden">
        <button
          onClick={onGoToPengamatan}
          className="inline-flex items-center gap-2 px-4 py-2 text-slate-700 hover:bg-slate-200 rounded-xl transition font-medium"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Kembali ke Meja Pengamatan</span>
        </button>

        <button
          onClick={onGoToQuiz}
          className="inline-flex items-center gap-2 px-6 py-3 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl transition shadow-xs focus-visible:outline-2 focus-visible:outline-emerald-600"
        >
          <span>Lanjut ke Kuis Evaluasi (5 Soal)</span>
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>

      <ConfirmDialog
        isOpen={confirmMode !== null}
        title={confirmMode === 'sample' ? 'Muat Contoh Isian Lengkap?' : 'Kosongkan Semua Baris Tabel?'}
        description={
          confirmMode === 'sample'
            ? 'Data yang sedang Anda ketik di tabel pengamatan akan digantikan dengan contoh isian lengkap.'
            : 'Seluruh isian hasil pengamatan di tabel ini akan dihapus dan dikembalikan ke 4 baris kosong.'
        }
        confirmLabel={confirmMode === 'sample' ? 'Ya, Muat Contoh' : 'Ya, Kosongkan Tabel'}
        variant={confirmMode === 'reset' ? 'danger' : 'primary'}
        onConfirm={handleConfirmAction}
        onCancel={() => setConfirmMode(null)}
      />
    </div>
  );
};
