import React, { useState } from 'react';
import {
  Microscope,
  ArrowRight,
  BookOpen,
  Target,
  Sparkles,
  CheckCircle,
  ShieldAlert,
  FlaskConical,
  Layers,
  Dna,
  Binary,
  CheckCircle2,
  FileSpreadsheet,
  Award,
  HelpCircle,
  Eye,
  Sliders,
} from 'lucide-react';
import { ActiveTab, OrganismDetail } from '../types';
import { ORGANISM_GROUPS } from '../data/biologyData';
import { OrganismSvg } from './OrganismSvg';
import { playLensClickSound, playSlidePlaceSound } from '../utils/labAudio';

interface BerandaProps {
  onStart: () => void;
  onNavigateTab: (tab: ActiveTab) => void;
}

export const Beranda: React.FC<BerandaProps> = ({ onStart, onNavigateTab }) => {
  // Live interactive preview in hero (switches between Virus, Bakteri, Jamur)
  const [heroActiveGroupIdx, setHeroActiveGroupIdx] = useState<number>(0);
  const heroGroup = ORGANISM_GROUPS[heroActiveGroupIdx];
  const heroSpecimen = heroGroup.organisms[0];

  const handleSwitchHeroGroup = (idx: number) => {
    playLensClickSound();
    setHeroActiveGroupIdx(idx);
  };

  const handleStartLab = () => {
    playSlidePlaceSound();
    onStart();
  };

  return (
    <div className="space-y-10 animate-fade-in">
      {/* 1. HERO SECTION: Interactive Virtual Bio-Laboratory Station Entrance */}
      <section className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-slate-950 via-emerald-950 to-slate-900 text-white p-6 sm:p-10 lg:p-12 shadow-xl border border-emerald-500/30">
        {/* Subtle decorative glow & laboratory optics atmosphere */}
        <div className="absolute -right-20 -top-20 w-96 h-96 rounded-full bg-emerald-500/15 blur-3xl pointer-events-none" />
        <div className="absolute right-1/3 -bottom-20 w-80 h-80 rounded-full bg-teal-400/10 blur-3xl pointer-events-none" />

        <div className="relative z-10 grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
          {/* Left Hero Content (7 cols) */}
          <div className="lg:col-span-7 space-y-5">
            <div className="flex flex-wrap items-center gap-2">
              <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/20 border border-emerald-400/40 text-emerald-300 text-xs font-semibold tracking-wide">
                <FlaskConical className="w-3.5 h-3.5" />
                <span>Laboratorium Biologi Digital</span>
              </span>
              <span className="inline-flex items-center gap-1 text-slate-400 text-xs">
                <span>Fase E (Kelas X SMA/MA)</span>
                <span aria-hidden="true">·</span>
                <span>Discovery Learning</span>
              </span>
            </div>

            <h1 className="text-2xl sm:text-4xl lg:text-5xl font-black tracking-tight leading-tight text-white">
              Virtual Lab Mini: Peranan Virus, Bakteri, & Jamur
            </h1>

            <p className="text-xs sm:text-base text-emerald-100/90 leading-relaxed max-w-2xl">
              Media pembelajaran mandiri interaktif untuk mengamati morfologi mikroskopis spesimen biologis, menganalisis peranan yang menguntungkan maupun merugikan bagi kehidupan manusia, serta mendokumentasikan temuan ilmiah ke dalam lembar kerja digital.
            </p>

            {/* Quick Metrics Badge strip */}
            <div className="grid grid-cols-3 gap-2 sm:gap-4 pt-1 max-w-md">
              <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-2.5 text-center">
                <div className="text-emerald-400 font-extrabold text-lg sm:text-xl leading-none">10</div>
                <div className="text-[10px] text-slate-400 mt-1 uppercase tracking-wider font-semibold">Preparat Kaca</div>
              </div>
              <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-2.5 text-center">
                <div className="text-teal-300 font-extrabold text-lg sm:text-xl leading-none">4× – 1000×</div>
                <div className="text-[10px] text-slate-400 mt-1 uppercase tracking-wider font-semibold">Lensa Optik</div>
              </div>
              <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-2.5 text-center">
                <div className="text-sky-400 font-extrabold text-lg sm:text-xl leading-none">5 Soal</div>
                <div className="text-[10px] text-slate-400 mt-1 uppercase tracking-wider font-semibold">Kuis Evaluasi</div>
              </div>
            </div>

            {/* Primary Action Buttons */}
            <div className="pt-3 flex flex-wrap items-center gap-3">
              <button
                onClick={handleStartLab}
                className="inline-flex items-center gap-2.5 px-6 py-3.5 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-extrabold text-sm sm:text-base rounded-xl transition duration-150 shadow-lg hover:shadow-emerald-500/20 active:scale-98 focus-visible:outline-2 focus-visible:outline-white cursor-pointer"
              >
                <Microscope className="w-5 h-5 text-slate-950" />
                <span>Masuk ke Meja Mikroskop</span>
                <ArrowRight className="w-4 h-4 ml-1" />
              </button>

              <button
                onClick={() => onNavigateTab('lembarkerja')}
                className="inline-flex items-center gap-2 px-4 py-3.5 bg-slate-900/90 hover:bg-slate-800 text-emerald-200 border border-emerald-500/30 text-xs sm:text-sm font-semibold rounded-xl transition cursor-pointer"
              >
                <FileSpreadsheet className="w-4 h-4 text-emerald-400" />
                <span>Lembar Kerja Siswa</span>
              </button>
            </div>
          </div>

          {/* Right Hero: Live Interactive Specimen Chamber (5 cols) */}
          <div className="lg:col-span-5 flex flex-col items-center">
            <div className="w-full bg-slate-900/90 rounded-3xl p-5 border border-emerald-500/30 shadow-2xl relative">
              {/* Top Selector Tabs in Chamber */}
              <div className="flex items-center justify-between pb-3 mb-3 border-b border-slate-800 text-xs">
                <span className="text-[11px] font-mono text-emerald-400 uppercase tracking-wider font-semibold flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
                  Pratinjau Kaca Objek
                </span>
                <div className="flex items-center gap-1 bg-slate-950 p-1 rounded-lg border border-slate-800">
                  {ORGANISM_GROUPS.map((grp, idx) => (
                    <button
                      key={grp.id}
                      onClick={() => handleSwitchHeroGroup(idx)}
                      className={`px-2.5 py-1 rounded text-[11px] font-bold transition ${
                        heroActiveGroupIdx === idx
                          ? 'bg-emerald-600 text-white shadow-xs'
                          : 'text-slate-400 hover:text-white'
                      }`}
                    >
                      {grp.title}
                    </button>
                  ))}
                </div>
              </div>

              {/* Glass Petri Dish / Eyepiece Preview Circle */}
              <div className="relative w-48 h-48 sm:w-56 sm:h-56 mx-auto rounded-full bg-gradient-to-br from-slate-950 via-slate-900 to-emerald-950 p-2 border-4 border-slate-800 shadow-inner flex items-center justify-center overflow-hidden">
                {/* Optical lens reticle */}
                <div className="absolute inset-0 pointer-events-none opacity-25">
                  <div className="w-full h-[1px] bg-emerald-400 absolute top-1/2 -translate-y-1/2" />
                  <div className="h-full w-[1px] bg-emerald-400 absolute left-1/2 -translate-x-1/2" />
                  <div className="w-3/4 h-3/4 border border-emerald-400/40 rounded-full absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2" />
                </div>

                <div className="w-full h-full p-2 flex items-center justify-center">
                  <OrganismSvg type={heroSpecimen.svgType} className="w-full h-full" />
                </div>
              </div>

              {/* Specimen Info in Chamber */}
              <div className="mt-4 text-center space-y-1">
                <div className="inline-flex items-center gap-1.5 text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full bg-emerald-900/60 text-emerald-300 border border-emerald-500/40">
                  <span>{heroGroup.badge}</span>
                </div>
                <h3 className="text-base font-extrabold text-white">
                  {heroSpecimen.name}
                </h3>
                <p className="text-xs text-slate-400 italic font-serif">
                  {heroSpecimen.scientificName}
                </p>
                <p className="text-xs text-emerald-200/90 pt-1 line-clamp-2 leading-relaxed">
                  {heroSpecimen.peranan}
                </p>
              </div>

              {/* Jump Button */}
              <button
                onClick={handleStartLab}
                className="mt-4 w-full py-2 bg-emerald-600/80 hover:bg-emerald-600 text-white text-xs font-bold rounded-xl transition flex items-center justify-center gap-1.5 shadow-xs"
              >
                <Eye className="w-3.5 h-3.5" />
                <span>Amati Spesimen Ini di Meja Lab</span>
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* 2. ALUR MODEL PEMBELAJARAN (DISCOVERY LEARNING SCIENTIFIC WORKFLOW) */}
      <section className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200/90 shadow-xs space-y-6">
        <div>
          <div className="flex items-center gap-2 text-xs font-semibold text-emerald-700 mb-1">
            <Layers className="w-4 h-4 text-emerald-600" />
            <span>Alur Model Pembelajaran</span>
          </div>
          <h2 className="text-xl sm:text-2xl font-bold text-slate-900 tracking-tight">
            Sintaks Praktikum Saintifik: Discovery Learning
          </h2>
          <p className="text-xs sm:text-sm text-slate-600 mt-1 max-w-2xl leading-relaxed">
            Praktikum virtual ini disusun sistematis mengikuti 4 tahapan penemuan ilmiah untuk membangun pemahaman konsep secara mandiri dan kritis.
          </p>
        </div>

        {/* 4 Interactive Process Steps */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {/* Tahap 1 */}
          <div className="bg-emerald-50/50 rounded-2xl p-5 border border-emerald-200/80 flex flex-col justify-between hover:shadow-xs transition">
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="w-7 h-7 rounded-xl bg-emerald-600 text-white font-extrabold text-xs flex items-center justify-center shadow-xs">
                  1
                </span>
                <span className="text-[11px] font-bold text-emerald-700 uppercase tracking-wider">Stimulasi</span>
              </div>
              <h3 className="text-sm font-bold text-slate-900">
                Observasi Preparat Mikroskopis
              </h3>
              <p className="text-xs text-slate-600 leading-relaxed">
                Pilih kaca preparat di rak lab, putar mikrometer untuk memfokuskan bayangan, dan ganti lensa objektif untuk mengamati ciri morfologi serta bagian organelnya.
              </p>
            </div>
            <div className="mt-4 pt-3 border-t border-emerald-200/60 text-[11px] font-semibold text-emerald-800 flex items-center gap-1">
              <Microscope className="w-3.5 h-3.5" />
              <span>Lokasi: Meja Pengamatan</span>
            </div>
          </div>

          {/* Tahap 2 */}
          <div className="bg-teal-50/50 rounded-2xl p-5 border border-teal-200/80 flex flex-col justify-between hover:shadow-xs transition">
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="w-7 h-7 rounded-xl bg-teal-600 text-white font-extrabold text-xs flex items-center justify-center shadow-xs">
                  2
                </span>
                <span className="text-[11px] font-bold text-teal-700 uppercase tracking-wider">Data Collection</span>
              </div>
              <h3 className="text-sm font-bold text-slate-900">
                Pencatatan & Pengelompokkan
              </h3>
              <p className="text-xs text-slate-600 leading-relaxed">
                Dokumentasikan nama organisme, peranannya dalam kehidupan, klasifikasikan apakah menguntungkan atau merugikan, dan ketik alasan mekanismenya.
              </p>
            </div>
            <div className="mt-4 pt-3 border-t border-teal-200/60 text-[11px] font-semibold text-teal-800 flex items-center gap-1">
              <FileSpreadsheet className="w-3.5 h-3.5" />
              <span>Lokasi: Lembar Kerja</span>
            </div>
          </div>

          {/* Tahap 3 */}
          <div className="bg-sky-50/50 rounded-2xl p-5 border border-sky-200/80 flex flex-col justify-between hover:shadow-xs transition">
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="w-7 h-7 rounded-xl bg-sky-600 text-white font-extrabold text-xs flex items-center justify-center shadow-xs">
                  3
                </span>
                <span className="text-[11px] font-bold text-sky-700 uppercase tracking-wider">Verifikasi</span>
              </div>
              <h3 className="text-sm font-bold text-slate-900">
                Uji Evaluasi Pemahaman
              </h3>
              <p className="text-xs text-slate-600 leading-relaxed">
                Uji pemahamanmu secara objektif dengan menjawab 5 butir soal kuis pilihan ganda untuk menguji daya serap materi dan verifikasi konsep ilmiah.
              </p>
            </div>
            <div className="mt-4 pt-3 border-t border-sky-200/60 text-[11px] font-semibold text-sky-800 flex items-center gap-1">
              <Award className="w-3.5 h-3.5" />
              <span>Lokasi: Kuis Evaluasi</span>
            </div>
          </div>

          {/* Tahap 4 */}
          <div className="bg-amber-50/50 rounded-2xl p-5 border border-amber-200/80 flex flex-col justify-between hover:shadow-xs transition">
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="w-7 h-7 rounded-xl bg-amber-600 text-white font-extrabold text-xs flex items-center justify-center shadow-xs">
                  4
                </span>
                <span className="text-[11px] font-bold text-amber-700 uppercase tracking-wider">Generalisasi</span>
              </div>
              <h3 className="text-sm font-bold text-slate-900">
                Refleksi & Pembahasan
              </h3>
              <p className="text-xs text-slate-600 leading-relaxed">
                Evaluasi pembahasan lengkap, perbaiki kekeliruan konsep, dan simpulkan pentingnya keanekaragaman mikroorganisme dalam ekosistem dan bioteknologi.
              </p>
            </div>
            <div className="mt-4 pt-3 border-t border-amber-200/60 text-[11px] font-semibold text-amber-800 flex items-center gap-1">
              <Sparkles className="w-3.5 h-3.5" />
              <span>Lokasi: Kunci & Pembahasan</span>
            </div>
          </div>
        </div>
      </section>

      {/* 3. SCIENTIFIC COMPARISON MATRIX: 3 DOMAIN MIKROORGANISME */}
      <section className="space-y-5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div>
            <h2 className="text-xl sm:text-2xl font-bold text-slate-900 tracking-tight">
              Tiga Kelompok Mikroorganisme Pengamatan
            </h2>
            <p className="text-xs sm:text-sm text-slate-600">
              Pelajari karakteristik biologis pembeda antara Virus, Bakteri, dan Jamur sebelum memulai pengamatan:
            </p>
          </div>
          <button
            onClick={handleStartLab}
            className="text-xs font-bold text-emerald-700 hover:text-emerald-800 flex items-center gap-1 self-start sm:self-auto"
          >
            <span>Buka Semua di Meja Lab</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Card 1: Virus */}
          <div className="bg-white rounded-3xl p-6 border border-emerald-200/90 hover:border-emerald-400 hover:shadow-md transition-all flex flex-col justify-between group">
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="w-9 h-9 rounded-xl bg-emerald-100 flex items-center justify-center text-emerald-700">
                  <Dna className="w-5 h-5" />
                </span>
                <span className="text-[11px] font-mono text-emerald-800 bg-emerald-50 px-2.5 py-0.5 rounded-full border border-emerald-200">
                  20 - 400 nm
                </span>
              </div>

              <div>
                <h3 className="text-xl font-bold text-slate-900 group-hover:text-emerald-700 transition">
                  1. Virus
                </h3>
                <p className="text-xs text-slate-500 font-medium">Partikel Aseluler (Bukan Sel Hidup Mandiri)</p>
              </div>

              {/* Biological Specs */}
              <div className="bg-slate-50 p-3 rounded-xl border border-slate-200/60 text-xs space-y-1.5 text-slate-600">
                <div>
                  <strong className="text-slate-800">Organisasi:</strong> Aseluler (hanya DNA/RNA + Kapsid)
                </div>
                <div>
                  <strong className="text-slate-800">Sifat Hidup:</strong> Parasit intraseluler obligat
                </div>
                <div>
                  <strong className="text-slate-800">Mikroskop:</strong> Mikroskop Elektron (TEM / Cryo-EM)
                </div>
              </div>

              {/* Roles Summary */}
              <div className="space-y-2 text-xs">
                <div className="flex items-start gap-2 text-emerald-900 bg-emerald-50/80 p-2.5 rounded-xl border border-emerald-200/60">
                  <CheckCircle className="w-3.5 h-3.5 text-emerald-600 shrink-0 mt-0.5" />
                  <span><strong>Menguntungkan:</strong> Bakteriofag (vektor rekayasa genetik & terapi fag bakterisida).</span>
                </div>
                <div className="flex items-start gap-2 text-rose-900 bg-rose-50/80 p-2.5 rounded-xl border border-rose-200/60">
                  <ShieldAlert className="w-3.5 h-3.5 text-rose-600 shrink-0 mt-0.5" />
                  <span><strong>Merugikan:</strong> Virus Influenza (saluran pernapasan) & Virus Dengue (demam berdarah).</span>
                </div>
              </div>
            </div>

            <button
              onClick={handleStartLab}
              className="mt-5 w-full py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl transition flex items-center justify-center gap-1.5 shadow-xs"
            >
              <Microscope className="w-3.5 h-3.5" />
              <span>Amati Spesimen Virus</span>
            </button>
          </div>

          {/* Card 2: Bakteri */}
          <div className="bg-white rounded-3xl p-6 border border-teal-200/90 hover:border-teal-400 hover:shadow-md transition-all flex flex-col justify-between group">
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="w-9 h-9 rounded-xl bg-teal-100 flex items-center justify-center text-teal-700">
                  <Binary className="w-5 h-5" />
                </span>
                <span className="text-[11px] font-mono text-teal-800 bg-teal-50 px-2.5 py-0.5 rounded-full border border-teal-200">
                  0.5 - 5.0 µm
                </span>
              </div>

              <div>
                <h3 className="text-xl font-bold text-slate-900 group-hover:text-teal-700 transition">
                  2. Bakteri
                </h3>
                <p className="text-xs text-slate-500 font-medium">Organisme Prokariotik Uniseluler</p>
              </div>

              {/* Biological Specs */}
              <div className="bg-slate-50 p-3 rounded-xl border border-slate-200/60 text-xs space-y-1.5 text-slate-600">
                <div>
                  <strong className="text-slate-800">Organisasi:</strong> Sel tunggal tanpa membran inti
                </div>
                <div>
                  <strong className="text-slate-800">Dinding Sel:</strong> Peptidoglikan (Gram +/-)
                </div>
                <div>
                  <strong className="text-slate-800">Mikroskop:</strong> Mikroskop Cahaya (Objektif 100× Imersi)
                </div>
              </div>

              {/* Roles Summary */}
              <div className="space-y-2 text-xs">
                <div className="flex items-start gap-2 text-teal-900 bg-teal-50/80 p-2.5 rounded-xl border border-teal-200/60">
                  <CheckCircle className="w-3.5 h-3.5 text-teal-600 shrink-0 mt-0.5" />
                  <span><strong>Menguntungkan:</strong> Lactobacillus & Streptococcus (yoghurt), Rhizobium (fiksasi N₂).</span>
                </div>
                <div className="flex items-start gap-2 text-rose-900 bg-rose-50/80 p-2.5 rounded-xl border border-rose-200/60">
                  <ShieldAlert className="w-3.5 h-3.5 text-rose-600 shrink-0 mt-0.5" />
                  <span><strong>Merugikan:</strong> Salmonella enterica (penyakit bawaan pangan & tipes usus).</span>
                </div>
              </div>
            </div>

            <button
              onClick={handleStartLab}
              className="mt-5 w-full py-2.5 bg-teal-600 hover:bg-teal-700 text-white font-bold text-xs rounded-xl transition flex items-center justify-center gap-1.5 shadow-xs"
            >
              <Microscope className="w-3.5 h-3.5" />
              <span>Amati Spesimen Bakteri</span>
            </button>
          </div>

          {/* Card 3: Jamur */}
          <div className="bg-white rounded-3xl p-6 border border-sky-200/90 hover:border-sky-400 hover:shadow-md transition-all flex flex-col justify-between group">
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="w-9 h-9 rounded-xl bg-sky-100 flex items-center justify-center text-sky-700">
                  <FlaskConical className="w-5 h-5" />
                </span>
                <span className="text-[11px] font-mono text-sky-800 bg-sky-50 px-2.5 py-0.5 rounded-full border border-sky-200">
                  5 µm - Makro
                </span>
              </div>

              <div>
                <h3 className="text-xl font-bold text-slate-900 group-hover:text-sky-700 transition">
                  3. Jamur (Fungi)
                </h3>
                <p className="text-xs text-slate-500 font-medium">Eukariotik Heterotrof Dinding Kitin</p>
              </div>

              {/* Biological Specs */}
              <div className="bg-slate-50 p-3 rounded-xl border border-slate-200/60 text-xs space-y-1.5 text-slate-600">
                <div>
                  <strong className="text-slate-800">Organisasi:</strong> Uniseluler (khamir) & Hifa kapang
                </div>
                <div>
                  <strong className="text-slate-800">Dinding Sel:</strong> Senyawa Kitin & Glukan
                </div>
                <div>
                  <strong className="text-slate-800">Mikroskop:</strong> Mikroskop Cahaya (Objektif 40× / 400×)
                </div>
              </div>

              {/* Roles Summary */}
              <div className="space-y-2 text-xs">
                <div className="flex items-start gap-2 text-sky-900 bg-sky-50/80 p-2.5 rounded-xl border border-sky-200/60">
                  <CheckCircle className="w-3.5 h-3.5 text-sky-600 shrink-0 mt-0.5" />
                  <span><strong>Menguntungkan:</strong> Rhizopus (fermentasi tempe) & Saccharomyces (ragi roti).</span>
                </div>
                <div className="flex items-start gap-2 text-rose-900 bg-rose-50/80 p-2.5 rounded-xl border border-rose-200/60">
                  <ShieldAlert className="w-3.5 h-3.5 text-rose-600 shrink-0 mt-0.5" />
                  <span><strong>Merugikan:</strong> Trichophyton (infeksi kurap/kadas) & Aspergillus flavus (aflatoksin).</span>
                </div>
              </div>
            </div>

            <button
              onClick={handleStartLab}
              className="mt-5 w-full py-2.5 bg-sky-600 hover:bg-sky-700 text-white font-bold text-xs rounded-xl transition flex items-center justify-center gap-1.5 shadow-xs"
            >
              <Microscope className="w-3.5 h-3.5" />
              <span>Amati Spesimen Jamur</span>
            </button>
          </div>
        </div>
      </section>

      {/* 4. MODUL IDENTITAS & SOP PRAKTIKUM DIGITAL */}
      <section className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Tujuan & Capaian Pembelajaran */}
        <div className="bg-white rounded-3xl p-6 sm:p-7 border border-slate-200/90 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center gap-2.5 text-emerald-800 font-bold text-base sm:text-lg mb-3">
              <div className="w-8 h-8 rounded-xl bg-emerald-100 flex items-center justify-center text-emerald-700">
                <Target className="w-4 h-4" />
              </div>
              <h2>Capaian & Tujuan Pembelajaran (Fase E)</h2>
            </div>
            <p className="text-xs text-slate-500 mb-3 leading-relaxed">
              <strong>Capaian Pembelajaran:</strong> Peserta didik mampu mendeskripsikan peranan virus, bakteri, dan jamur dalam kehidupan manusia dan ekosistem lingkungan.
            </p>
            <ul className="space-y-2.5 text-xs text-slate-600">
              <li className="flex items-start gap-2.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                <span>
                  <strong>Mengidentifikasi:</strong> Mengenali karakteristik morfologi spesimen mikroskopis melalui pengamatan visual beresolusi tinggi.
                </span>
              </li>
              <li className="flex items-start gap-2.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                <span>
                  <strong>Menjelaskan Peranan:</strong> Menguraikan peranan menguntungkan dan merugikan serta mekanisme biologis yang melatarbelakanginya.
                </span>
              </li>
              <li className="flex items-start gap-2.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                <span>
                  <strong>Mengelompokkan:</strong> Menyusun matriks peranan pada tabel lembar kerja mandiri untuk kemudian divalidasi lewat evaluasi kuis.
                </span>
              </li>
            </ul>
          </div>

          <div className="mt-5 pt-3.5 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-500">
            <span>Model: Discovery Learning</span>
            <span>Alokasi: 3 Pertemuan × 2 JP</span>
          </div>
        </div>

        {/* SOP Protokol & Etika Praktikum */}
        <div className="bg-white rounded-3xl p-6 sm:p-7 border border-slate-200/90 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center gap-2.5 text-teal-800 font-bold text-base sm:text-lg mb-3">
              <div className="w-8 h-8 rounded-xl bg-teal-100 flex items-center justify-center text-teal-700">
                <Sliders className="w-4 h-4" />
              </div>
              <h2>SOP & Panduan Praktikum Digital</h2>
            </div>
            <p className="text-xs text-slate-500 mb-3 leading-relaxed">
              Panduan langkah operasional untuk memaksimalkan pengalaman pengamatan mikroskopis di laboratorium digital:
            </p>
            <ul className="space-y-2.5 text-xs text-slate-600">
              <li className="flex items-start gap-2.5">
                <span className="w-5 h-5 rounded-full bg-teal-100 text-teal-800 font-bold text-[11px] flex items-center justify-center shrink-0 mt-0.5">
                  1
                </span>
                <span>
                  <strong>Atur Fokus Mikroskop:</strong> Geser slider mikrometer hingga bayangan spesimen jernih sebelum mencatat data.
                </span>
              </li>
              <li className="flex items-start gap-2.5">
                <span className="w-5 h-5 rounded-full bg-teal-100 text-teal-800 font-bold text-[11px] flex items-center justify-center shrink-0 mt-0.5">
                  2
                </span>
                <span>
                  <strong>Eksplorasi Revolver Objektif:</strong> Mulai dari perbesaran 40× untuk lapang pandang luas hingga 1000× untuk struktur organel spesifik.
                </span>
              </li>
              <li className="flex items-start gap-2.5">
                <span className="w-5 h-5 rounded-full bg-teal-100 text-teal-800 font-bold text-[11px] flex items-center justify-center shrink-0 mt-0.5">
                  3
                </span>
                <span>
                  <strong>Tombol Catat Otomatis:</strong> Gunakan tombol <em>&quot;Catat ke Lembar Kerja&quot;</em> agar data tersalin rapi tanpa perlu berpindah-pindah layar berulang kali.
                </span>
              </li>
            </ul>
          </div>

          <div className="mt-5 pt-3.5 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-500">
            <span>Penyusun Media: Rizki Rhomadhon</span>
            <span>NPM: 2413024077</span>
          </div>
        </div>
      </section>
    </div>
  );
};
