import React, { useEffect, useRef } from 'react';
import * as THREE from 'three';
import { OrganismDetail } from '../types';

interface Microscope3DCanvasProps {
  organism: OrganismDetail;
  lensPower: '40x' | '100x' | '400x' | '1000x';
  focusBlur: number; // 0 to 4 px blur
  lightIntensity: number; // 20 to 100
  isLightOn: boolean;
  isPlaying?: boolean;
  showStructureLabels?: boolean;
  activeHotspot?: string | null;
  onSelectHotspot?: (name: string | null) => void;
}

export const Microscope3DCanvas: React.FC<Microscope3DCanvasProps> = ({
  organism,
  lensPower,
  focusBlur,
  lightIntensity,
  isLightOn,
  isPlaying = true,
  showStructureLabels = true,
  activeHotspot = null,
  onSelectHotspot,
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const pinElsRef = useRef<(HTMLDivElement | null)[]>([]);

  const isPlayingRef = useRef(isPlaying);
  isPlayingRef.current = isPlaying;

  const lightIntensityRef = useRef(lightIntensity);
  lightIntensityRef.current = lightIntensity;

  const isLightOnRef = useRef(isLightOn);
  isLightOnRef.current = isLightOn;

  const lensPowerRef = useRef(lensPower);
  lensPowerRef.current = lensPower;

  const showStructureLabelsRef = useRef(showStructureLabels);
  showStructureLabelsRef.current = showStructureLabels;

  // Touch and mouse drag rotation
  const isDraggingRef = useRef(false);
  const previousMousePositionRef = useRef({ x: 0, y: 0 });
  const modelRotationRef = useRef({ x: 0.2, y: 0.3 });

  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    const width = container.clientWidth || 360;
    const height = container.clientHeight || 360;

    // 1. Scene setup
    const scene = new THREE.Scene();

    // Slide background tint based on organism
    let bgHex = 0x061e14; // default dark emerald
    if (organism.svgType === 'influenza' || organism.svgType === 'dengue' || organism.svgType === 'trichophyton') {
      bgHex = 0x1f080c; // dark red/rose tint
    } else if (organism.svgType === 'lactobacillus') {
      bgHex = 0x051a1a; // teal
    } else if (organism.svgType === 'salmonella') {
      bgHex = 0x221305; // amber
    } else if (organism.svgType === 'rhizopus') {
      bgHex = 0x061726; // sky blue
    } else if (organism.svgType === 'saccharomyces') {
      bgHex = 0x1f1406; // warm yeast amber
    } else if (organism.svgType === 'aspergillus') {
      bgHex = 0x171f05; // lime greenish
    }
    scene.background = new THREE.Color(bgHex);

    // 2. Camera setup
    const camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 100);
    camera.position.set(0, 0, 7.5);

    // 3. Renderer setup
    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: false, powerPreference: 'high-performance' });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.2;
    container.appendChild(renderer.domElement);

    // 4. Lighting Rig
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.8);
    scene.add(ambientLight);

    const mainLight = new THREE.DirectionalLight(0xffffff, 1.8);
    mainLight.position.set(5, 8, 6);
    scene.add(mainLight);

    const rimLight = new THREE.DirectionalLight(0x34d399, 1.2);
    rimLight.position.set(-6, -4, -4);
    scene.add(rimLight);

    // 5. Specimen Model Root Group
    const modelGroup = new THREE.Group();
    scene.add(modelGroup);

    // Secondary floating particles in immersion fluid (Brownian motion)
    const particleCount = 45;
    const particleGeometry = new THREE.SphereGeometry(0.04, 8, 8);
    const particleMaterial = new THREE.MeshBasicMaterial({
      color: 0x93c5fd,
      transparent: true,
      opacity: 0.35,
    });
    const particlesGroup = new THREE.Group();
    const particleData: { mesh: THREE.Mesh; vx: number; vy: number; vz: number }[] = [];

    for (let i = 0; i < particleCount; i++) {
      const mesh = new THREE.Mesh(particleGeometry, particleMaterial);
      mesh.position.set(
        (Math.random() - 0.5) * 8,
        (Math.random() - 0.5) * 8,
        (Math.random() - 0.5) * 4
      );
      particlesGroup.add(mesh);
      particleData.push({
        mesh,
        vx: (Math.random() - 0.5) * 0.005,
        vy: (Math.random() - 0.5) * 0.005,
        vz: (Math.random() - 0.5) * 0.003,
      });
    }
    scene.add(particlesGroup);

    // Animated sub-elements reference for the tick loop
    const animatedSubMeshes: {
      update: (time: number, delta: number) => void;
    }[] = [];

    // --- PROCEDURAL 3D BIOLOGICAL MODEL GENERATION ---
    const buildModel = () => {
      // Clear previous children
      while (modelGroup.children.length > 0) {
        const obj = modelGroup.children[0];
        modelGroup.remove(obj);
      }
      animatedSubMeshes.length = 0;

      switch (organism.svgType) {
        case 'bakteriofag': {
          // --- BAKTERIOFAG (T4 PHAGE) ---
          const phageRoot = new THREE.Group();

          // 1. Icosahedral Head
          const headGeo = new THREE.IcosahedronGeometry(1.2, 0);
          const headMat = new THREE.MeshStandardMaterial({
            color: 0x10b981,
            roughness: 0.3,
            metalness: 0.1,
            flatShading: true,
          });
          const headMesh = new THREE.Mesh(headGeo, headMat);
          headMesh.position.y = 1.3;
          phageRoot.add(headMesh);

          // Head Wireframe highlight
          const wireMat = new THREE.MeshBasicMaterial({ color: 0x34d399, wireframe: true, transparent: true, opacity: 0.4 });
          const wireMesh = new THREE.Mesh(headGeo, wireMat);
          wireMesh.position.copy(headMesh.position);
          wireMesh.scale.setScalar(1.02);
          phageRoot.add(wireMesh);

          // Internal Glowing DNA strand
          const dnaCurve = new THREE.CatmullRomCurve3([
            new THREE.Vector3(0, 0.7, 0),
            new THREE.Vector3(0.3, 1.0, 0.2),
            new THREE.Vector3(-0.3, 1.3, -0.2),
            new THREE.Vector3(0.2, 1.6, 0.1),
            new THREE.Vector3(0, 1.9, 0),
          ]);
          const dnaGeo = new THREE.TubeGeometry(dnaCurve, 20, 0.07, 8, false);
          const dnaMat = new THREE.MeshBasicMaterial({ color: 0xfef08a });
          const dnaMesh = new THREE.Mesh(dnaGeo, dnaMat);
          phageRoot.add(dnaMesh);

          // 2. Neck Collar
          const collarGeo = new THREE.CylinderGeometry(0.3, 0.3, 0.2, 16);
          const collarMat = new THREE.MeshStandardMaterial({ color: 0x047857 });
          const collarMesh = new THREE.Mesh(collarGeo, collarMat);
          collarMesh.position.y = 0.6;
          phageRoot.add(collarMesh);

          // 3. Contractile Sheath (with corrugated rings)
          const sheathGeo = new THREE.CylinderGeometry(0.22, 0.22, 1.2, 16);
          const sheathMat = new THREE.MeshStandardMaterial({ color: 0x059669, roughness: 0.4 });
          const sheathMesh = new THREE.Mesh(sheathGeo, sheathMat);
          sheathMesh.position.y = -0.1;
          phageRoot.add(sheathMesh);

          // Sheath rings
          for (let r = 0; r < 6; r++) {
            const ringGeo = new THREE.TorusGeometry(0.25, 0.03, 8, 20);
            const ringMat = new THREE.MeshStandardMaterial({ color: 0x6ee7b7 });
            const ringMesh = new THREE.Mesh(ringGeo, ringMat);
            ringMesh.rotation.x = Math.PI / 2;
            ringMesh.position.y = -0.6 + r * 0.2;
            phageRoot.add(ringMesh);
          }

          // 4. Baseplate
          const plateGeo = new THREE.CylinderGeometry(0.42, 0.42, 0.12, 6);
          const plateMat = new THREE.MeshStandardMaterial({ color: 0x047857 });
          const plateMesh = new THREE.Mesh(plateGeo, plateMat);
          plateMesh.position.y = -0.75;
          phageRoot.add(plateMesh);

          // 5. 6 Articulated Tail Fibers
          const fiberLegs: THREE.Group[] = [];
          for (let i = 0; i < 6; i++) {
            const angle = (i * Math.PI * 2) / 6;
            const legGroup = new THREE.Group();
            legGroup.position.set(Math.cos(angle) * 0.35, -0.75, Math.sin(angle) * 0.35);

            // Upper segment
            const upperGeo = new THREE.CylinderGeometry(0.04, 0.04, 0.8, 8);
            upperGeo.translate(0, -0.4, 0);
            const legMat = new THREE.MeshStandardMaterial({ color: 0x065f46 });
            const upperMesh = new THREE.Mesh(upperGeo, legMat);
            upperMesh.rotation.z = Math.cos(angle) * 0.7;
            upperMesh.rotation.x = Math.sin(angle) * 0.7;

            // Lower claw segment
            const lowerGeo = new THREE.CylinderGeometry(0.03, 0.015, 0.9, 8);
            lowerGeo.translate(0, -0.45, 0);
            const lowerMesh = new THREE.Mesh(lowerGeo, legMat);
            lowerMesh.position.set(Math.cos(angle) * 0.4, -0.65, Math.sin(angle) * 0.4);
            lowerMesh.rotation.z = Math.cos(angle) * -0.5;
            lowerMesh.rotation.x = Math.sin(angle) * -0.5;

            legGroup.add(upperMesh);
            legGroup.add(lowerMesh);
            phageRoot.add(legGroup);
            fiberLegs.push(legGroup);
          }

          // Gentle leg flexing animation
          animatedSubMeshes.push({
            update: (time) => {
              fiberLegs.forEach((leg, idx) => {
                const wave = Math.sin(time * 2.5 + idx * 0.9) * 0.06;
                leg.rotation.y = wave;
              });
            },
          });

          modelGroup.add(phageRoot);
          break;
        }

        case 'influenza': {
          // --- VIRUS INFLUENZA ---
          const fluRoot = new THREE.Group();

          // Spherical Viral Envelope
          const envGeo = new THREE.SphereGeometry(1.4, 32, 32);
          const envMat = new THREE.MeshStandardMaterial({
            color: 0xef4444,
            roughness: 0.5,
            metalness: 0.1,
          });
          const envMesh = new THREE.Mesh(envGeo, envMat);
          fluRoot.add(envMesh);

          // Internal Core RNA
          const coreGeo = new THREE.SphereGeometry(0.8, 16, 16);
          const coreMat = new THREE.MeshStandardMaterial({ color: 0x7f1d1d, wireframe: true });
          const coreMesh = new THREE.Mesh(coreGeo, coreMat);
          fluRoot.add(coreMesh);

          // Spikes: Hemagglutinin (Red) and Neuraminidase (Blue)
          const spikeCount = 90;
          for (let i = 0; i < spikeCount; i++) {
            const phi = Math.acos(-1 + (2 * i) / spikeCount);
            const theta = Math.sqrt(spikeCount * Math.PI) * phi;

            const isHA = i % 2 === 0;
            const spikeGroup = new THREE.Group();

            const stalkGeo = new THREE.CylinderGeometry(0.04, 0.04, 0.4, 6);
            stalkGeo.translate(0, 0.2, 0);
            const stalkMat = new THREE.MeshStandardMaterial({ color: isHA ? 0xdc2626 : 0x2563eb });
            const stalk = new THREE.Mesh(stalkGeo, stalkMat);

            const knobGeo = isHA ? new THREE.SphereGeometry(0.09, 8, 8) : new THREE.BoxGeometry(0.14, 0.14, 0.14);
            const knobMat = new THREE.MeshStandardMaterial({ color: isHA ? 0xf87171 : 0x60a5fa });
            const knob = new THREE.Mesh(knobGeo, knobMat);
            knob.position.y = 0.42;

            spikeGroup.add(stalk);
            spikeGroup.add(knob);

            const x = Math.sin(phi) * Math.cos(theta);
            const y = Math.sin(phi) * Math.sin(theta);
            const z = Math.cos(phi);

            spikeGroup.position.set(x * 1.35, y * 1.35, z * 1.35);
            spikeGroup.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), new THREE.Vector3(x, y, z));

            fluRoot.add(spikeGroup);
          }

          animatedSubMeshes.push({
            update: (time) => {
              const pulse = 1 + Math.sin(time * 3) * 0.03;
              envMesh.scale.set(pulse, pulse, pulse);
            },
          });

          modelGroup.add(fluRoot);
          break;
        }

        case 'dengue': {
          // --- VIRUS DENGUE ---
          const dengueRoot = new THREE.Group();

          const coreGeo = new THREE.IcosahedronGeometry(1.3, 2);
          const coreMat = new THREE.MeshStandardMaterial({
            color: 0xe11d48,
            roughness: 0.3,
            metalness: 0.2,
            flatShading: true,
          });
          const coreMesh = new THREE.Mesh(coreGeo, coreMat);
          dengueRoot.add(coreMesh);

          // Herringbone surface E-dimers
          const dimerCount = 60;
          for (let i = 0; i < dimerCount; i++) {
            const phi = Math.acos(-1 + (2 * i) / dimerCount);
            const theta = Math.sqrt(dimerCount * Math.PI) * phi;

            const dimerGeo = new THREE.BoxGeometry(0.24, 0.08, 0.12);
            const dimerMat = new THREE.MeshStandardMaterial({ color: 0xf43f5e });
            const dimerMesh = new THREE.Mesh(dimerGeo, dimerMat);

            const x = Math.sin(phi) * Math.cos(theta);
            const y = Math.sin(phi) * Math.sin(theta);
            const z = Math.cos(phi);

            dimerMesh.position.set(x * 1.36, y * 1.36, z * 1.36);
            dimerMesh.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), new THREE.Vector3(x, y, z));
            dengueRoot.add(dimerMesh);
          }

          modelGroup.add(dengueRoot);
          break;
        }

        case 'lactobacillus': {
          // --- LACTOBACILLUS (RODS) & STREPTOCOCCUS (COCCI CHAINS) ---
          const lactoRoot = new THREE.Group();

          // 2 Bacillus Rods (Lactobacillus)
          const makeRod = (px: number, py: number, pz: number, rx: number, ry: number) => {
            const rodGroup = new THREE.Group();
            const cylGeo = new THREE.CylinderGeometry(0.4, 0.4, 1.8, 16);
            const capGeo = new THREE.SphereGeometry(0.4, 16, 16);

            const rodMat = new THREE.MeshStandardMaterial({
              color: 0x0d9488,
              roughness: 0.3,
              metalness: 0.1,
            });

            const body = new THREE.Mesh(cylGeo, rodMat);
            const topCap = new THREE.Mesh(capGeo, rodMat);
            topCap.position.y = 0.9;
            const bottomCap = new THREE.Mesh(capGeo, rodMat);
            bottomCap.position.y = -0.9;

            rodGroup.add(body);
            rodGroup.add(topCap);
            rodGroup.add(bottomCap);

            rodGroup.position.set(px, py, pz);
            rodGroup.rotation.set(rx, ry, 0);
            return rodGroup;
          };

          const rod1 = makeRod(-0.7, 0.2, 0, 0.3, 0.4);
          const rod2 = makeRod(0.6, -0.4, 0.3, -0.5, 0.8);
          lactoRoot.add(rod1);
          lactoRoot.add(rod2);

          // Streptococcus: chain of cocci beads
          const chainGroup = new THREE.Group();
          const coccusGeo = new THREE.SphereGeometry(0.22, 16, 16);
          const coccusMat = new THREE.MeshStandardMaterial({ color: 0x0284c7, roughness: 0.3 });

          for (let c = 0; c < 7; c++) {
            const coccus = new THREE.Mesh(coccusGeo, coccusMat);
            const curve = Math.sin(c * 0.6) * 0.15;
            coccus.position.set(-1.2 + c * 0.38, -1.2 + curve, 0.5);
            chainGroup.add(coccus);
          }
          lactoRoot.add(chainGroup);

          // Gentle swimming motion
          animatedSubMeshes.push({
            update: (time) => {
              rod1.rotation.z = Math.sin(time * 1.5) * 0.1;
              rod2.rotation.x = Math.cos(time * 1.8) * 0.1;
              chainGroup.position.y = -1.2 + Math.sin(time * 2) * 0.08;
            },
          });

          modelGroup.add(lactoRoot);
          break;
        }

        case 'rhizobium': {
          // --- RHIZOBIUM (ROOT NODULE & BACTEROIDS) ---
          const rootRoot = new THREE.Group();

          // Main Plant Root
          const rootGeo = new THREE.CylinderGeometry(0.35, 0.45, 4.0, 16);
          const rootMat = new THREE.MeshStandardMaterial({ color: 0x78350f, roughness: 0.9 });
          const rootMesh = new THREE.Mesh(rootGeo, rootMat);
          rootRoot.add(rootMesh);

          // Nodules containing bacteroids
          const nodule1Geo = new THREE.SphereGeometry(0.85, 16, 16);
          nodule1Geo.scale(1.2, 0.9, 1.0);
          const noduleMat = new THREE.MeshStandardMaterial({ color: 0xd97706, roughness: 0.6 });
          const nodule1 = new THREE.Mesh(nodule1Geo, noduleMat);
          nodule1.position.set(0.7, 0.3, 0.2);
          rootRoot.add(nodule1);

          const nodule2 = new THREE.Mesh(nodule1Geo, noduleMat);
          nodule2.position.set(-0.6, -0.8, -0.1);
          nodule2.scale.setScalar(0.75);
          rootRoot.add(nodule2);

          // Bacteroids inside / around nodule
          const bacteroidGroup = new THREE.Group();
          for (let b = 0; b < 18; b++) {
            const bGeo = new THREE.CapsuleGeometry(0.06, 0.16, 4, 8);
            const bMat = new THREE.MeshStandardMaterial({ color: 0x16a34a });
            const bMesh = new THREE.Mesh(bGeo, bMat);
            bMesh.position.set(
              0.7 + (Math.random() - 0.5) * 0.8,
              0.3 + (Math.random() - 0.5) * 0.7,
              0.2 + (Math.random() - 0.5) * 0.8
            );
            bMesh.rotation.set(Math.random() * Math.PI, Math.random() * Math.PI, 0);
            bacteroidGroup.add(bMesh);
          }
          rootRoot.add(bacteroidGroup);

          modelGroup.add(rootRoot);
          break;
        }

        case 'salmonella': {
          // --- SALMONELLA ENTERICA (ROD WITH PERITRICHOUS FLAGELLA) ---
          const salRoot = new THREE.Group();

          // Capsule body
          const bodyGroup = new THREE.Group();
          const salCyl = new THREE.CylinderGeometry(0.5, 0.5, 2.2, 20);
          const salCap = new THREE.SphereGeometry(0.5, 20, 20);
          const salMat = new THREE.MeshStandardMaterial({
            color: 0xf59e0b,
            roughness: 0.3,
            metalness: 0.1,
          });

          const salBody = new THREE.Mesh(salCyl, salMat);
          const salTop = new THREE.Mesh(salCap, salMat);
          salTop.position.y = 1.1;
          const salBot = new THREE.Mesh(salCap, salMat);
          salBot.position.y = -1.1;

          bodyGroup.add(salBody);
          bodyGroup.add(salTop);
          bodyGroup.add(salBot);
          bodyGroup.rotation.z = Math.PI / 3;
          salRoot.add(bodyGroup);

          // 8 Long Waving Flagella
          const flagellaMeshes: { curveMesh: THREE.Mesh; baseAngle: number; length: number; basePos: THREE.Vector3 }[] = [];
          for (let f = 0; f < 8; f++) {
            const angle = (f * Math.PI * 2) / 8;
            const yOffset = -0.8 + (f * 1.6) / 7;
            const basePos = new THREE.Vector3(Math.cos(angle) * 0.5, yOffset, Math.sin(angle) * 0.5);

            const points: THREE.Vector3[] = [];
            for (let p = 0; p < 7; p++) {
              points.push(new THREE.Vector3(basePos.x + Math.cos(angle + p * 0.5) * (p * 0.35), basePos.y + p * 0.25, basePos.z + Math.sin(angle + p * 0.5) * (p * 0.35)));
            }
            const flagellaCurve = new THREE.CatmullRomCurve3(points);
            const flagellaGeo = new THREE.TubeGeometry(flagellaCurve, 16, 0.025, 6, false);
            const flagellaMat = new THREE.MeshStandardMaterial({ color: 0xd97706, roughness: 0.5 });
            const flagellaMesh = new THREE.Mesh(flagellaGeo, flagellaMat);

            salRoot.add(flagellaMesh);
            flagellaMeshes.push({ curveMesh: flagellaMesh, baseAngle: angle, length: 7, basePos });
          }

          animatedSubMeshes.push({
            update: (time) => {
              bodyGroup.position.y = Math.sin(time * 3) * 0.08;
              bodyGroup.rotation.y = Math.cos(time * 2) * 0.1;

              // Wave flagella
              flagellaMeshes.forEach((fl, idx) => {
                fl.curveMesh.rotation.y = Math.sin(time * 6 + idx) * 0.15;
                fl.curveMesh.rotation.z = Math.cos(time * 5 + idx) * 0.12;
              });
            },
          });

          modelGroup.add(salRoot);
          break;
        }

        case 'rhizopus': {
          // --- RHIZOPUS (TEMPE MOLD: HYPHAE, SPORANGIOPHORES & SPORANGIA) ---
          const moldRoot = new THREE.Group();

          // Soybean grains substrate at base
          const beanGeo = new THREE.SphereGeometry(0.7, 16, 16);
          beanGeo.scale(1.2, 0.8, 0.9);
          const beanMat = new THREE.MeshStandardMaterial({ color: 0xfef08a, roughness: 0.8 });
          const bean1 = new THREE.Mesh(beanGeo, beanMat);
          bean1.position.set(-0.8, -1.8, 0);
          const bean2 = new THREE.Mesh(beanGeo, beanMat);
          bean2.position.set(0.6, -1.9, 0.2);
          moldRoot.add(bean1);
          moldRoot.add(bean2);

          // White Mycelium hyphae mesh
          const hyphaeGeo = new THREE.TorusGeometry(1.4, 0.06, 8, 24);
          const hyphaeMat = new THREE.MeshStandardMaterial({ color: 0xf8fafc, roughness: 0.4 });
          const hyphaeMesh = new THREE.Mesh(hyphaeGeo, hyphaeMat);
          hyphaeMesh.rotation.x = Math.PI / 2.3;
          hyphaeMesh.position.y = -1.6;
          moldRoot.add(hyphaeMesh);

          // 3 Upright Sporangiophores with Sporangia
          const stalks: { stalk: THREE.Mesh; head: THREE.Mesh; pivot: THREE.Group }[] = [];
          const stalkCoords = [
            { x: -0.6, z: 0.2, height: 2.4, headR: 0.42 },
            { x: 0.3, z: -0.2, height: 2.8, headR: 0.48 },
            { x: 0.9, z: 0.4, height: 2.2, headR: 0.38 },
          ];

          stalkCoords.forEach((coord, i) => {
            const pivot = new THREE.Group();
            pivot.position.set(coord.x, -1.6, coord.z);

            const stalkGeo = new THREE.CylinderGeometry(0.04, 0.07, coord.height, 12);
            stalkGeo.translate(0, coord.height / 2, 0);
            const stalkMat = new THREE.MeshStandardMaterial({ color: 0x64748b, roughness: 0.5 });
            const stalk = new THREE.Mesh(stalkGeo, stalkMat);

            const headGeo = new THREE.SphereGeometry(coord.headR, 20, 20);
            const headMat = new THREE.MeshStandardMaterial({ color: 0x1e293b, roughness: 0.3 });
            const head = new THREE.Mesh(headGeo, headMat);
            head.position.y = coord.height;

            pivot.add(stalk);
            pivot.add(head);
            moldRoot.add(pivot);
            stalks.push({ stalk, head, pivot });
          });

          animatedSubMeshes.push({
            update: (time) => {
              stalks.forEach((st, idx) => {
                const sway = Math.sin(time * 1.5 + idx * 1.2) * 0.04;
                st.pivot.rotation.z = sway;
              });
            },
          });

          modelGroup.add(moldRoot);
          break;
        }

        case 'saccharomyces': {
          // --- SACCHAROMYCES CEREVISIAE (BUDDING YEAST & CO2) ---
          const yeastRoot = new THREE.Group();

          // Mother yeast cell
          const motherGeo = new THREE.SphereGeometry(1.2, 24, 24);
          motherGeo.scale(1.2, 0.95, 1.0);
          const yeastMat = new THREE.MeshStandardMaterial({
            color: 0xfde68a,
            roughness: 0.4,
            metalness: 0.05,
          });
          const motherMesh = new THREE.Mesh(motherGeo, yeastMat);
          yeastRoot.add(motherMesh);

          // Daughter budding cell
          const daughterGeo = new THREE.SphereGeometry(0.65, 20, 20);
          const daughterMesh = new THREE.Mesh(daughterGeo, yeastMat);
          daughterMesh.position.set(1.2, 0.7, 0.3);
          yeastRoot.add(daughterMesh);

          // Budding neck junction
          const neckGeo = new THREE.CylinderGeometry(0.25, 0.35, 0.3, 12);
          const neckMat = new THREE.MeshStandardMaterial({ color: 0xf59e0b });
          const neckMesh = new THREE.Mesh(neckGeo, neckMat);
          neckMesh.position.set(0.85, 0.45, 0.2);
          neckMesh.rotation.z = -Math.PI / 4;
          yeastRoot.add(neckMesh);

          // Effervescent rising CO2 bubbles
          const bubbles: { mesh: THREE.Mesh; speed: number; startY: number }[] = [];
          for (let b = 0; b < 12; b++) {
            const bGeo = new THREE.SphereGeometry(0.12 + Math.random() * 0.1, 12, 12);
            const bMat = new THREE.MeshStandardMaterial({
              color: 0x38bdf8,
              transparent: true,
              opacity: 0.6,
              roughness: 0.1,
            });
            const bMesh = new THREE.Mesh(bGeo, bMat);
            bMesh.position.set((Math.random() - 0.5) * 3, -2 + Math.random() * 4, (Math.random() - 0.5) * 2);
            yeastRoot.add(bMesh);
            bubbles.push({ mesh: bMesh, speed: 0.02 + Math.random() * 0.02, startY: -2.5 });
          }

          animatedSubMeshes.push({
            update: () => {
              bubbles.forEach((bubble) => {
                bubble.mesh.position.y += bubble.speed;
                if (bubble.mesh.position.y > 3) {
                  bubble.mesh.position.y = bubble.startY;
                  bubble.mesh.position.x = (Math.random() - 0.5) * 3;
                }
              });
            },
          });

          modelGroup.add(yeastRoot);
          break;
        }

        case 'trichophyton': {
          // --- TRICHOPHYTON (DERMATOPHYTE HYPHAE & MACROCONIDIA) ---
          const triRoot = new THREE.Group();

          // Septate branching hyphae
          for (let h = 0; h < 4; h++) {
            const angle = (h * Math.PI) / 2.5;
            const points: THREE.Vector3[] = [];
            for (let s = 0; s < 6; s++) {
              points.push(new THREE.Vector3(Math.cos(angle) * (s * 0.6), Math.sin(angle) * (s * 0.5) - 0.5, (s % 2) * 0.2));
            }
            const hyphaCurve = new THREE.CatmullRomCurve3(points);
            const hyphaGeo = new THREE.TubeGeometry(hyphaCurve, 20, 0.08, 8, false);
            const hyphaMat = new THREE.MeshStandardMaterial({ color: 0xdc2626, roughness: 0.5 });
            const hyphaMesh = new THREE.Mesh(hyphaGeo, hyphaMat);
            triRoot.add(hyphaMesh);
          }

          // Cigar-shaped Macroconidia
          const macroGeo = new THREE.CylinderGeometry(0.18, 0.18, 1.4, 16);
          const macroCap = new THREE.SphereGeometry(0.18, 16, 16);
          const macroMat = new THREE.MeshStandardMaterial({ color: 0xf87171, roughness: 0.4 });

          const macroGroup = new THREE.Group();
          const macroBody = new THREE.Mesh(macroGeo, macroMat);
          const cap1 = new THREE.Mesh(macroCap, macroMat);
          cap1.position.y = 0.7;
          const cap2 = new THREE.Mesh(macroCap, macroMat);
          cap2.position.y = -0.7;

          macroGroup.add(macroBody);
          macroGroup.add(cap1);
          macroGroup.add(cap2);
          macroGroup.position.set(1.0, 0.8, 0.3);
          macroGroup.rotation.set(0.4, 0.5, 0.8);
          triRoot.add(macroGroup);

          modelGroup.add(triRoot);
          break;
        }

        case 'aspergillus': {
          // --- ASPERGILLUS FLAVUS (CONIDIOPHORE & SPORE HEAD) ---
          const aspRoot = new THREE.Group();

          // Conidiophore stalk
          const stalkGeo = new THREE.CylinderGeometry(0.18, 0.24, 2.8, 16);
          stalkGeo.translate(0, -1.2, 0);
          const stalkMat = new THREE.MeshStandardMaterial({ color: 0x65a30d, roughness: 0.6 });
          const stalkMesh = new THREE.Mesh(stalkGeo, stalkMat);
          aspRoot.add(stalkMesh);

          // Swollen Vesicle (Bulbous Head)
          const vesicleGeo = new THREE.SphereGeometry(0.85, 20, 20);
          const vesicleMat = new THREE.MeshStandardMaterial({ color: 0x84cc16, roughness: 0.4 });
          const vesicleMesh = new THREE.Mesh(vesicleGeo, vesicleMat);
          vesicleMesh.position.y = 0.4;
          aspRoot.add(vesicleMesh);

          // Radiating Phialides and chains of conidiospores
          const sporeGroup = new THREE.Group();
          const sporeCount = 48;
          for (let s = 0; s < sporeCount; s++) {
            const phi = Math.acos(-1 + (2 * s) / sporeCount);
            if (phi > Math.PI * 0.75) continue; // upper hemisphere
            const theta = Math.sqrt(sporeCount * Math.PI) * phi;

            for (let chain = 1; chain <= 3; chain++) {
              const spGeo = new THREE.SphereGeometry(0.08, 8, 8);
              const spMat = new THREE.MeshStandardMaterial({ color: chain === 3 ? 0xbbf7d0 : 0xa3e635 });
              const spMesh = new THREE.Mesh(spGeo, spMat);

              const dist = 0.9 + chain * 0.2;
              const x = Math.sin(phi) * Math.cos(theta) * dist;
              const y = 0.4 + Math.cos(phi) * dist;
              const z = Math.sin(phi) * Math.sin(theta) * dist;

              spMesh.position.set(x, y, z);
              sporeGroup.add(spMesh);
            }
          }
          aspRoot.add(sporeGroup);

          modelGroup.add(aspRoot);
          break;
        }
      }

      // Add 3D anchor beacons for each anatomical structure
      const anchorGroup = new THREE.Group();
      organism.structures.forEach((struct) => {
        if (!struct.pos3d) return;
        const dotGeo = new THREE.SphereGeometry(0.045, 10, 10);
        const dotMat = new THREE.MeshBasicMaterial({ color: 0x34d399 });
        const dotMesh = new THREE.Mesh(dotGeo, dotMat);
        dotMesh.position.set(struct.pos3d[0], struct.pos3d[1], struct.pos3d[2]);

        // Subtle pulsing halo ring
        const ringGeo = new THREE.RingGeometry(0.065, 0.085, 16);
        const ringMat = new THREE.MeshBasicMaterial({
          color: 0x10b981,
          side: THREE.DoubleSide,
          transparent: true,
          opacity: 0.7,
        });
        const ringMesh = new THREE.Mesh(ringGeo, ringMat);
        dotMesh.add(ringMesh);

        anchorGroup.add(dotMesh);
      });
      modelGroup.add(anchorGroup);
    };

    buildModel();

    // 6. Interactive Drag to Rotate Event Handlers
    const onMouseDown = (e: MouseEvent) => {
      isDraggingRef.current = true;
      previousMousePositionRef.current = { x: e.clientX, y: e.clientY };
    };

    const onMouseMove = (e: MouseEvent) => {
      if (!isDraggingRef.current) return;
      const deltaX = e.clientX - previousMousePositionRef.current.x;
      const deltaY = e.clientY - previousMousePositionRef.current.y;

      modelRotationRef.current.y += deltaX * 0.008;
      modelRotationRef.current.x += deltaY * 0.008;

      previousMousePositionRef.current = { x: e.clientX, y: e.clientY };
    };

    const onMouseUp = () => {
      isDraggingRef.current = false;
    };

    // Touch support for mobile devices
    const onTouchStart = (e: TouchEvent) => {
      if (e.touches.length === 1) {
        isDraggingRef.current = true;
        previousMousePositionRef.current = { x: e.touches[0].clientX, y: e.touches[0].clientY };
      }
    };

    const onTouchMove = (e: TouchEvent) => {
      if (!isDraggingRef.current || e.touches.length !== 1) return;
      const deltaX = e.touches[0].clientX - previousMousePositionRef.current.x;
      const deltaY = e.touches[0].clientY - previousMousePositionRef.current.y;

      modelRotationRef.current.y += deltaX * 0.008;
      modelRotationRef.current.x += deltaY * 0.008;

      previousMousePositionRef.current = { x: e.touches[0].clientX, y: e.touches[0].clientY };
    };

    const onTouchEnd = () => {
      isDraggingRef.current = false;
    };

    const domElement = renderer.domElement;
    domElement.addEventListener('mousedown', onMouseDown);
    window.addEventListener('mousemove', onMouseMove);
    window.addEventListener('mouseup', onMouseUp);

    domElement.addEventListener('touchstart', onTouchStart, { passive: true });
    window.addEventListener('touchmove', onTouchMove, { passive: true });
    window.addEventListener('touchend', onTouchEnd);

    // 7. Animation Loop
    let animationFrameId: number;
    let lastTime = performance.now();
    const tempProjVec = new THREE.Vector3();

    const animate = () => {
      animationFrameId = requestAnimationFrame(animate);

      const now = performance.now();
      const delta = Math.min((now - lastTime) / 1000, 0.1);
      lastTime = now;
      const time = now / 1000;

      // Dynamic light intensity update
      const targetIntensity = isLightOnRef.current ? (lightIntensityRef.current / 100) * 1.8 : 0.05;
      mainLight.intensity = THREE.MathUtils.lerp(mainLight.intensity, targetIntensity, 0.1);
      ambientLight.intensity = THREE.MathUtils.lerp(ambientLight.intensity, isLightOnRef.current ? 0.7 : 0.02, 0.1);

      // Objective lens zoom target (adapting dynamically 4x to 1000x)
      let targetZoom = 7.5;
      if (lensPowerRef.current === '40x') targetZoom = 9.8;
      else if (lensPowerRef.current === '100x') targetZoom = 8.0;
      else if (lensPowerRef.current === '400x') targetZoom = 6.4;
      else if (lensPowerRef.current === '1000x') targetZoom = 4.8;

      camera.position.z = THREE.MathUtils.lerp(camera.position.z, targetZoom, 0.08);

      // Passive idle rotation when not dragging
      if (isPlayingRef.current && !isDraggingRef.current) {
        modelRotationRef.current.y += 0.008;
      }

      // Smooth model rotation dampening
      modelGroup.rotation.x = THREE.MathUtils.lerp(modelGroup.rotation.x, modelRotationRef.current.x, 0.1);
      modelGroup.rotation.y = THREE.MathUtils.lerp(modelGroup.rotation.y, modelRotationRef.current.y, 0.1);

      // Dynamic 3D hotspot screen-tracking calculation
      if (showStructureLabelsRef.current && isLightOnRef.current && pinElsRef.current) {
        organism.structures.forEach((struct, idx) => {
          const pinEl = pinElsRef.current[idx];
          if (!pinEl) return;

          const coords = struct.pos3d || [0, 0, 0];
          tempProjVec.set(coords[0], coords[1], coords[2]);
          modelGroup.localToWorld(tempProjVec);

          const distToCam = tempProjVec.distanceTo(camera.position);

          tempProjVec.project(camera);

          const screenX = (tempProjVec.x * 0.5 + 0.5) * 100;
          const screenY = (-(tempProjVec.y * 0.5) + 0.5) * 100;

          const dx = screenX - 50;
          const dy = screenY - 50;
          const distFromCenter = Math.sqrt(dx * dx + dy * dy);

          // If point is behind camera plane or outside the circular lens field of view (r ~ 47%)
          if (tempProjVec.z > 0.99 || distFromCenter > 47) {
            pinEl.style.display = 'none';
          } else {
            pinEl.style.display = 'block';
            pinEl.style.left = `${screenX.toFixed(2)}%`;
            pinEl.style.top = `${screenY.toFixed(2)}%`;

            // Depth perception: if structure is on the far/back side of the model
            const isBehind = distToCam > camera.position.z;
            pinEl.style.opacity = isBehind ? '0.45' : '1.0';
            pinEl.style.zIndex = isBehind ? '25' : '35';

            // Smart inward positioning for the label tag:
            // If pin is on right half of the circle, place label to the left of the pin; otherwise to the right
            const labelEl = pinEl.querySelector<HTMLElement>('.pin-label');
            if (labelEl) {
              if (screenX > 50) {
                labelEl.style.left = 'auto';
                labelEl.style.right = 'calc(100% + 6px)';
              } else {
                labelEl.style.right = 'auto';
                labelEl.style.left = 'calc(100% + 6px)';
              }
            }
          }
        });
      }

      // Update biological sub-mesh motions (flagella waving, pulses, stalks swaying)
      if (isPlayingRef.current) {
        animatedSubMeshes.forEach((sub) => sub.update(time, delta));

        // Brownian particle drift in immersion liquid
        particleData.forEach((p) => {
          p.mesh.position.x += p.vx;
          p.mesh.position.y += p.vy;
          p.mesh.position.z += p.vz;

          if (Math.abs(p.mesh.position.x) > 4) p.vx *= -1;
          if (Math.abs(p.mesh.position.y) > 4) p.vy *= -1;
          if (Math.abs(p.mesh.position.z) > 2) p.vz *= -1;
        });
      }

      renderer.render(scene, camera);
    };

    animate();

    // 8. Resize observer
    const handleResize = () => {
      if (!container) return;
      const w = container.clientWidth || 360;
      const h = container.clientHeight || 360;
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
    };

    window.addEventListener('resize', handleResize);

    // Cleanup resources
    return () => {
      cancelAnimationFrame(animationFrameId);
      domElement.removeEventListener('mousedown', onMouseDown);
      window.removeEventListener('mousemove', onMouseMove);
      window.removeEventListener('mouseup', onMouseUp);

      domElement.removeEventListener('touchstart', onTouchStart);
      window.removeEventListener('touchmove', onTouchMove);
      window.removeEventListener('touchend', onTouchEnd);
      window.removeEventListener('resize', handleResize);

      // Recursive disposal
      scene.traverse((object) => {
        if ((object as THREE.Mesh).isMesh) {
          const mesh = object as THREE.Mesh;
          mesh.geometry?.dispose();
          if (Array.isArray(mesh.material)) {
            mesh.material.forEach((mat) => mat.dispose());
          } else if (mesh.material) {
            mesh.material.dispose();
          }
        }
      });

      renderer.dispose();
      if (container.contains(domElement)) {
        container.removeChild(domElement);
      }
    };
  }, [organism.svgType, organism.id]);

  return (
    <div className="relative w-full h-full select-none">
      {/* 3D WebGL Canvas */}
      <div
        ref={containerRef}
        className="w-full h-full cursor-grab active:cursor-grabbing relative"
        style={{
          filter: isLightOn ? `blur(${focusBlur}px)` : 'brightness(0.1)',
          transition: 'filter 0.15s ease-out',
        }}
        title="Klik dan geser (drag) untuk memutar spesimen 3D 360°"
      />

      {/* 3D Tracked Dynamic Pins Overlay */}
      {showStructureLabels && isLightOn && (
        <div className="absolute inset-0 pointer-events-none z-30 overflow-hidden rounded-full">
          {organism.structures.map((struct, idx) => {
            const isOpened = activeHotspot === struct.name;
            return (
              <div
                key={idx}
                ref={(el) => {
                  pinElsRef.current[idx] = el;
                }}
                className="absolute -translate-x-1/2 -translate-y-1/2 pointer-events-auto transition-opacity duration-150"
                style={{
                  left: '50%',
                  top: '50%',
                  display: 'none',
                }}
              >
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    onSelectHotspot?.(isOpened ? null : struct.name);
                  }}
                  className={`group relative flex items-center justify-center p-2 focus-visible:outline-2 focus-visible:outline-white ${
                    isOpened ? 'scale-125 z-40' : 'hover:scale-115'
                  }`}
                  aria-label={`Lihat struktur ${struct.name}`}
                  title={`${struct.name} (Klik untuk membaca keterangan lengkap di panel bawah)`}
                >
                  <span
                    className={`w-4 h-4 rounded-full border-2 border-slate-950 flex items-center justify-center transition-all ${
                      isOpened
                        ? 'bg-yellow-400 ring-4 ring-yellow-400/50 scale-110 shadow-lg'
                        : 'bg-emerald-400 group-hover:bg-emerald-300 shadow-md ring-2 ring-emerald-500/40'
                    }`}
                  >
                    <span className={`w-1.5 h-1.5 rounded-full ${isOpened ? 'bg-slate-950' : 'bg-slate-950/80'}`} />
                  </span>
                  <span className={`absolute w-7 h-7 rounded-full animate-ping pointer-events-none ${isOpened ? 'bg-yellow-400/40' : 'bg-emerald-400/35'}`} />

                  {/* Smart Inward-Facing Label Tag (Never clipped by circle border) */}
                  <span
                    className={`pin-label absolute px-2.5 py-1 rounded-md text-[10px] font-bold whitespace-nowrap pointer-events-none transition-all shadow-lg ${
                      isOpened
                        ? 'bg-yellow-400 text-slate-950 block z-40 ring-1 ring-slate-900/40'
                        : 'bg-slate-900/95 text-white border border-slate-700 hidden group-hover:block z-30'
                    }`}
                    style={{
                      left: 'calc(100% + 6px)',
                      top: '50%',
                      transform: 'translateY(-50%)',
                    }}
                  >
                    {struct.name}
                  </span>
                </button>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
