import React from 'react';

interface OrganismSvgProps {
  type: string;
  className?: string;
}

export const OrganismSvg: React.FC<OrganismSvgProps> = ({ type, className = 'w-full h-full' }) => {
  switch (type) {
    case 'bakteriofag':
      return (
        <svg viewBox="0 0 240 240" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          <circle cx="120" cy="120" r="110" fill="#ECFDF5" stroke="#A7F3D0" strokeWidth="2" strokeDasharray="4 4" />
          {/* Icosahedral Head */}
          <polygon
            points="120,28 158,50 158,95 120,118 82,95 82,50"
            fill="#10B981"
            stroke="#047857"
            strokeWidth="3"
          />
          <polygon points="120,28 120,118 158,95" fill="#34D399" opacity="0.6" />
          <polygon points="120,28 82,50 120,118" fill="#059669" opacity="0.7" />
          {/* DNA inside head */}
          <path
            d="M105,58 Q120,48 135,58 Q120,68 105,78 Q120,88 135,98"
            stroke="#FDE047"
            strokeWidth="2.5"
            strokeLinecap="round"
            fill="none"
          />
          {/* Collar & Sheath */}
          <rect x="114" y="118" width="12" height="10" fill="#047857" rx="2" />
          <rect x="110" y="128" width="20" height="42" fill="#059669" rx="3" stroke="#047857" strokeWidth="2" />
          {/* Sheath rings */}
          <line x1="110" y1="136" x2="130" y2="136" stroke="#A7F3D0" strokeWidth="2" />
          <line x1="110" y1="144" x2="130" y2="144" stroke="#A7F3D0" strokeWidth="2" />
          <line x1="110" y1="152" x2="130" y2="152" stroke="#A7F3D0" strokeWidth="2" />
          <line x1="110" y1="160" x2="130" y2="160" stroke="#A7F3D0" strokeWidth="2" />
          {/* Baseplate */}
          <polygon points="104,170 136,170 128,178 112,178" fill="#047857" />
          {/* Tail Fibers */}
          <path d="M106,174 Q80,186 64,212" stroke="#047857" strokeWidth="3" strokeLinecap="round" />
          <path d="M109,176 Q95,198 88,218" stroke="#047857" strokeWidth="3" strokeLinecap="round" />
          <path d="M134,174 Q160,186 176,212" stroke="#047857" strokeWidth="3" strokeLinecap="round" />
          <path d="M131,176 Q145,198 152,218" stroke="#047857" strokeWidth="3" strokeLinecap="round" />
          {/* Specimen Label */}
          <text x="120" y="232" textAnchor="middle" fill="#065F46" fontSize="10" fontWeight="bold">
            Bakteriofag T4
          </text>
        </svg>
      );

    case 'influenza':
      return (
        <svg viewBox="0 0 240 240" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          <circle cx="120" cy="120" r="110" fill="#FEF2F2" stroke="#FECACA" strokeWidth="2" strokeDasharray="4 4" />
          {/* Spikes HA & NA */}
          {[0, 30, 60, 90, 120, 150, 180, 210, 240, 270, 300, 330].map((deg, i) => {
            const rad = (deg * Math.PI) / 180;
            const x1 = 120 + 64 * Math.cos(rad);
            const y1 = 120 + 64 * Math.sin(rad);
            const x2 = 120 + 82 * Math.cos(rad);
            const y2 = 120 + 82 * Math.sin(rad);
            const isRed = i % 2 === 0;
            return (
              <g key={deg}>
                <line x1={x1} y1={y1} x2={x2} y2={y2} stroke={isRed ? '#DC2626' : '#2563EB'} strokeWidth="3" strokeLinecap="round" />
                <circle cx={x2} cy={y2} r={isRed ? 4.5 : 3.5} fill={isRed ? '#EF4444' : '#3B82F6'} />
              </g>
            );
          })}
          {/* Viral Envelope */}
          <circle cx="120" cy="120" r="64" fill="#FCA5A5" stroke="#DC2626" strokeWidth="3" />
          <circle cx="120" cy="120" r="54" fill="#FEE2E2" stroke="#F87171" strokeWidth="2" strokeDasharray="3 3" />
          {/* Ribonucleoprotein (RNA segments) */}
          <g stroke="#991B1B" strokeWidth="2.5" strokeLinecap="round" fill="none">
            <path d="M100,98 Q120,90 140,98" />
            <path d="M92,112 Q120,104 148,112" />
            <path d="M96,128 Q120,120 144,128" />
            <path d="M102,142 Q120,136 138,142" />
          </g>
          <text x="120" y="232" textAnchor="middle" fill="#991B1B" fontSize="10" fontWeight="bold">
            Virus Influenza
          </text>
        </svg>
      );

    case 'dengue':
      return (
        <svg viewBox="0 0 240 240" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          <circle cx="120" cy="120" r="110" fill="#FFF1F2" stroke="#FFE4E6" strokeWidth="2" strokeDasharray="4 4" />
          {/* Outer Glycoprotein Shell with Herringbone Dimers */}
          <circle cx="120" cy="120" r="70" fill="#FDA4AF" stroke="#E11D48" strokeWidth="3" />
          {/* Surface glycoprotein raft patterns */}
          {[15, 75, 135, 195, 255, 315].map((deg) => {
            const rad = (deg * Math.PI) / 180;
            const cx = 120 + 44 * Math.cos(rad);
            const cy = 120 + 44 * Math.sin(rad);
            return (
              <g key={deg} transform={`rotate(${deg}, ${cx}, ${cy})`}>
                <rect x={cx - 14} y={cy - 4} width="28" height="8" rx="4" fill="#E11D48" opacity="0.8" />
                <rect x={cx - 10} y={cy - 2} width="20" height="4" rx="2" fill="#FFE4E6" />
              </g>
            );
          })}
          {/* Inner core capsid & RNA */}
          <circle cx="120" cy="120" r="32" fill="#BE123C" />
          <path
            d="M108,114 Q120,106 132,114 Q120,122 108,130 Q120,138 132,130"
            stroke="#FEF08A"
            strokeWidth="2.5"
            strokeLinecap="round"
            fill="none"
          />
          <text x="120" y="232" textAnchor="middle" fill="#9F1239" fontSize="10" fontWeight="bold">
            Virus Dengue (Flavivirus)
          </text>
        </svg>
      );

    case 'lactobacillus':
      return (
        <svg viewBox="0 0 240 240" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          <circle cx="120" cy="120" r="110" fill="#F0FDFA" stroke="#CCFBF1" strokeWidth="2" strokeDasharray="4 4" />
          {/* Yoghurt fermentation milky droplets */}
          <circle cx="60" cy="70" r="12" fill="#CCFBF1" opacity="0.6" />
          <circle cx="185" cy="65" r="9" fill="#CCFBF1" opacity="0.7" />
          <circle cx="190" cy="170" r="14" fill="#CCFBF1" opacity="0.5" />
          {/* Lactobacillus: Bacilli (Rod shapes) */}
          <g transform="rotate(-20 100 110)">
            <rect x="60" y="94" width="85" height="32" rx="16" fill="#0D9488" stroke="#115E59" strokeWidth="3" />
            <path d="M72,110 Q90,104 110,110 Q125,116 135,110" stroke="#5EEAD4" strokeWidth="2" fill="none" />
          </g>
          <g transform="rotate(35 150 145)">
            <rect x="110" y="130" width="75" height="28" rx="14" fill="#14B8A6" stroke="#0F766E" strokeWidth="3" />
            <path d="M120,144 Q145,138 170,144" stroke="#99F6E4" strokeWidth="2" fill="none" />
          </g>
          {/* Streptococcus: Spherical chains (Cocci) */}
          <g>
            <circle cx="65" cy="165" r="10" fill="#0284C7" stroke="#0369A1" strokeWidth="2.5" />
            <circle cx="82" cy="160" r="10" fill="#0284C7" stroke="#0369A1" strokeWidth="2.5" />
            <circle cx="98" cy="164" r="10" fill="#0284C7" stroke="#0369A1" strokeWidth="2.5" />
            <circle cx="112" cy="173" r="9" fill="#0284C7" stroke="#0369A1" strokeWidth="2.5" />
          </g>
          <text x="120" y="232" textAnchor="middle" fill="#0F766E" fontSize="10" fontWeight="bold">
            Lactobacillus & Streptococcus
          </text>
        </svg>
      );

    case 'rhizobium':
      return (
        <svg viewBox="0 0 240 240" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          <circle cx="120" cy="120" r="110" fill="#F0FDF4" stroke="#BBF7D0" strokeWidth="2" strokeDasharray="4 4" />
          {/* Legume Root Plant Structure */}
          <path d="M120,20 Q125,80 120,190" stroke="#78350F" strokeWidth="8" strokeLinecap="round" />
          <path d="M120,70 Q70,95 40,130" stroke="#92400E" strokeWidth="5" strokeLinecap="round" />
          <path d="M120,120 Q170,135 195,170" stroke="#92400E" strokeWidth="5" strokeLinecap="round" />
          {/* Root Nodules (Bintil Akar) containing Rhizobium */}
          <circle cx="70" cy="98" r="18" fill="#FCD34D" stroke="#D97706" strokeWidth="2.5" />
          <circle cx="160" cy="132" r="22" fill="#FCD34D" stroke="#D97706" strokeWidth="2.5" />
          <circle cx="120" cy="160" r="16" fill="#FCD34D" stroke="#D97706" strokeWidth="2.5" />
          {/* Magnified Rhizobium bacteroids inside nodule */}
          <g>
            <rect x="150" y="122" width="16" height="7" rx="3.5" fill="#15803D" />
            <rect x="162" y="132" width="14" height="6" rx="3" fill="#15803D" />
            <rect x="152" y="138" width="15" height="6.5" rx="3" fill="#16A34A" />
            <circle cx="68" cy="96" r="3" fill="#15803D" />
            <circle cx="74" cy="100" r="3" fill="#16A34A" />
          </g>
          {/* Nitrogen Fixation Label */}
          <rect x="25" y="32" width="80" height="22" rx="6" fill="#DCFCE7" stroke="#16A34A" strokeWidth="1.5" />
          <text x="65" y="47" textAnchor="middle" fill="#15803D" fontSize="10" fontWeight="bold">
            Fiksasi N₂ → NH₃
          </text>
          <text x="120" y="232" textAnchor="middle" fill="#14532D" fontSize="10" fontWeight="bold">
            Rhizobium di Bintil Akar
          </text>
        </svg>
      );

    case 'salmonella':
      return (
        <svg viewBox="0 0 240 240" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          <circle cx="120" cy="120" r="110" fill="#FFFBEB" stroke="#FDE68A" strokeWidth="2" strokeDasharray="4 4" />
          {/* Salmonella Peritrichous Flagella (Whip-like hairs all over) */}
          <g stroke="#D97706" strokeWidth="2" strokeLinecap="round" fill="none">
            <path d="M70,95 Q40,65 25,75 Q15,85 20,105" />
            <path d="M85,75 Q75,45 60,35 Q45,30 35,45" />
            <path d="M135,70 Q145,40 160,30 Q175,25 180,45" />
            <path d="M165,90 Q195,65 210,80 Q220,95 215,115" />
            <path d="M170,140 Q205,150 215,170 Q220,190 205,200" />
            <path d="M130,165 Q135,195 125,210 Q115,220 95,215" />
            <path d="M75,145 Q45,165 35,185 Q30,200 45,210" />
          </g>
          {/* Rod Bacterium Body */}
          <g transform="rotate(-15 120 120)">
            <rect x="70" y="95" width="100" height="50" rx="25" fill="#F59E0B" stroke="#B45309" strokeWidth="3" />
            {/* Peptidoglycan Wall Layer */}
            <rect x="76" y="101" width="88" height="38" rx="19" fill="#FDE68A" stroke="#D97706" strokeWidth="1.5" />
            {/* Bacterial Nucleoid DNA */}
            <path
              d="M92,120 Q105,110 120,120 Q135,130 148,120"
              stroke="#B45309"
              strokeWidth="3"
              strokeLinecap="round"
              fill="none"
            />
          </g>
          <text x="120" y="232" textAnchor="middle" fill="#92400E" fontSize="10" fontWeight="bold">
            Salmonella enterica (Basil Berflagela)
          </text>
        </svg>
      );

    case 'rhizopus':
      return (
        <svg viewBox="0 0 240 240" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          <circle cx="120" cy="120" r="110" fill="#F0F9FF" stroke="#BAE6FD" strokeWidth="2" strokeDasharray="4 4" />
          {/* Tempe Soybeans base */}
          <ellipse cx="65" cy="195" rx="22" ry="14" fill="#FDE047" stroke="#CA8A04" strokeWidth="2" />
          <ellipse cx="110" cy="200" rx="24" ry="15" fill="#FEF08A" stroke="#CA8A04" strokeWidth="2" />
          <ellipse cx="160" cy="192" rx="20" ry="14" fill="#FDE047" stroke="#CA8A04" strokeWidth="2" />
          {/* White mycelium threads (hifa) */}
          <g stroke="#94A3B8" strokeWidth="2" strokeLinecap="round" fill="none">
            <path d="M60,190 Q90,180 120,185 Q150,180 180,195" />
            <path d="M80,198 Q115,188 150,196" />
          </g>
          {/* Rhizoids (Root-like hyphae) */}
          <path d="M105,185 L95,210 M105,185 L108,214 M105,185 L120,212" stroke="#64748B" strokeWidth="2" />
          {/* Sporangiophores (Upright stalks) */}
          <path d="M105,185 Q95,120 75,70" stroke="#475569" strokeWidth="3.5" strokeLinecap="round" />
          <path d="M105,185 Q125,110 145,55" stroke="#475569" strokeWidth="3.5" strokeLinecap="round" />
          <path d="M105,185 Q135,130 170,95" stroke="#475569" strokeWidth="3.5" strokeLinecap="round" />
          {/* Sporangia (Rounded spore heads) */}
          <circle cx="75" cy="70" r="18" fill="#1E293B" stroke="#0F172A" strokeWidth="2.5" />
          <circle cx="145" cy="55" r="22" fill="#334155" stroke="#0F172A" strokeWidth="2.5" />
          <circle cx="170" cy="95" r="16" fill="#1E293B" stroke="#0F172A" strokeWidth="2.5" />
          {/* Released Spores */}
          <circle cx="168" cy="45" r="3" fill="#64748B" />
          <circle cx="178" cy="52" r="2.5" fill="#64748B" />
          <circle cx="185" cy="65" r="3" fill="#64748B" />
          <circle cx="55" cy="58" r="3" fill="#64748B" />
          <text x="120" y="232" textAnchor="middle" fill="#0369A1" fontSize="10" fontWeight="bold">
            Rhizopus oligosporus (Jamur Tempe)
          </text>
        </svg>
      );

    case 'saccharomyces':
      return (
        <svg viewBox="0 0 240 240" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          <circle cx="120" cy="120" r="110" fill="#F8FAFC" stroke="#E2E8F0" strokeWidth="2" strokeDasharray="4 4" />
          {/* CO2 Bubbles from Dough Fermentation */}
          <circle cx="45" cy="80" r="10" fill="#E0F2FE" stroke="#38BDF8" strokeWidth="1.5" />
          <text x="45" y="83" textAnchor="middle" fill="#0284C7" fontSize="8" fontWeight="bold">CO₂</text>
          <circle cx="195" cy="65" r="14" fill="#E0F2FE" stroke="#38BDF8" strokeWidth="1.5" />
          <text x="195" y="69" textAnchor="middle" fill="#0284C7" fontSize="9" fontWeight="bold">CO₂</text>
          {/* Mother Yeast Cell */}
          <ellipse cx="110" cy="130" rx="48" ry="40" fill="#FDE68A" stroke="#D97706" strokeWidth="3" />
          {/* Nucleus and Vacuole */}
          <ellipse cx="102" cy="125" rx="16" ry="14" fill="#FEF3C7" stroke="#F59E0B" strokeWidth="2" />
          <circle cx="128" cy="138" r="10" fill="#FBBF24" />
          {/* Budding Daughter Cell (Tunas Baru) */}
          <ellipse cx="152" cy="98" rx="26" ry="22" fill="#FDE68A" stroke="#D97706" strokeWidth="3" />
          <circle cx="154" cy="96" r="8" fill="#FEF3C7" stroke="#F59E0B" strokeWidth="1.5" />
          {/* Budding Scar Connection */}
          <ellipse cx="132" cy="112" rx="6" ry="8" fill="#F59E0B" />
          <text x="120" y="232" textAnchor="middle" fill="#B45309" fontSize="10" fontWeight="bold">
            Saccharomyces (Ragi Tunas)
          </text>
        </svg>
      );

    case 'trichophyton':
      return (
        <svg viewBox="0 0 240 240" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          <circle cx="120" cy="120" r="110" fill="#FEF2F2" stroke="#FECACA" strokeWidth="2" strokeDasharray="4 4" />
          {/* Skin Keratin Layer Representation */}
          <path d="M20,185 Q120,175 220,185" stroke="#FCA5A5" strokeWidth="14" strokeLinecap="round" />
          <path d="M20,205 Q120,195 220,205" stroke="#FECDD3" strokeWidth="14" strokeLinecap="round" />
          {/* Branching Septate Hyphae */}
          <path d="M40,165 Q75,140 115,135 Q160,130 195,100" stroke="#DC2626" strokeWidth="3.5" fill="none" />
          <path d="M115,135 Q130,85 160,65" stroke="#DC2626" strokeWidth="3" fill="none" />
          {/* Hyphal Septa (Cross-walls) */}
          <line x1="60" y1="150" x2="63" y2="158" stroke="#7F1D1D" strokeWidth="2.5" />
          <line x1="95" y1="135" x2="96" y2="143" stroke="#7F1D1D" strokeWidth="2.5" />
          <line x1="140" y1="128" x2="142" y2="136" stroke="#7F1D1D" strokeWidth="2.5" />
          <line x1="130" y1="105" x2="138" y2="108" stroke="#7F1D1D" strokeWidth="2.5" />
          {/* Cigar-shaped Macroconidia */}
          <g transform="rotate(-30 180 80)">
            <rect x="160" y="70" width="42" height="16" rx="8" fill="#F87171" stroke="#B91C1C" strokeWidth="2" />
            <line x1="172" y1="70" x2="172" y2="86" stroke="#B91C1C" strokeWidth="1.5" />
            <line x1="185" y1="70" x2="185" y2="86" stroke="#B91C1C" strokeWidth="1.5" />
          </g>
          {/* Tear-drop Microconidia */}
          <circle cx="70" cy="132" r="4" fill="#B91C1C" />
          <circle cx="85" cy="124" r="4" fill="#B91C1C" />
          <circle cx="145" cy="70" r="4" fill="#B91C1C" />
          <text x="120" y="232" textAnchor="middle" fill="#991B1B" fontSize="10" fontWeight="bold">
            Trichophyton (Jamur Kulit)
          </text>
        </svg>
      );

    case 'aspergillus':
      return (
        <svg viewBox="0 0 240 240" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          <circle cx="120" cy="120" r="110" fill="#FEFCE8" stroke="#FEF08A" strokeWidth="2" strokeDasharray="4 4" />
          {/* Stalk / Conidiophore */}
          <path d="M120,205 Q120,150 120,115" stroke="#65A30D" strokeWidth="6" strokeLinecap="round" />
          {/* Swollen Vesicle (Kepala Pembengkakan) */}
          <circle cx="120" cy="100" r="24" fill="#84CC16" stroke="#4D7C0F" strokeWidth="3" />
          {/* Phialides & Chains of Conidia radiating outward like a sprinkler */}
          {[0, 25, 50, 75, 100, 125, 150, 175, 200, 225, 250, 275, 300, 325].map((deg) => {
            const rad = (deg * Math.PI) / 180;
            // Only radiating on top 240 degrees
            if (deg > 60 && deg < 120) return null;
            const r1 = 28;
            const r2 = 38;
            const r3 = 48;
            const x1 = 120 + r1 * Math.cos(rad);
            const y1 = 100 + r1 * Math.sin(rad);
            const x2 = 120 + r2 * Math.cos(rad);
            const y2 = 100 + r2 * Math.sin(rad);
            const x3 = 120 + r3 * Math.cos(rad);
            const y3 = 100 + r3 * Math.sin(rad);
            return (
              <g key={deg}>
                <line x1={x1} y1={y1} x2={x2} y2={y2} stroke="#4D7C0F" strokeWidth="2" />
                <circle cx={x2} cy={y2} r={3.5} fill="#A3E635" stroke="#4D7C0F" strokeWidth="1" />
                <circle cx={x3} cy={y3} r={3} fill="#BEF264" stroke="#4D7C0F" strokeWidth="1" />
              </g>
            );
          })}
          {/* Toxic Warning Symbol */}
          <g transform="translate(160, 140)">
            <polygon points="18,0 36,32 0,32" fill="#FACC15" stroke="#CA8A04" strokeWidth="2" />
            <text x="18" y="27" textAnchor="middle" fill="#713F12" fontSize="18" fontWeight="bold">!</text>
          </g>
          <text x="120" y="232" textAnchor="middle" fill="#4D7C0F" fontSize="10" fontWeight="bold">
            Aspergillus flavus (Aflatoksin)
          </text>
        </svg>
      );

    default:
      return (
        <div className="w-full h-full flex items-center justify-center bg-slate-100 text-slate-400">
          Mikroorganisme
        </div>
      );
  }
};
