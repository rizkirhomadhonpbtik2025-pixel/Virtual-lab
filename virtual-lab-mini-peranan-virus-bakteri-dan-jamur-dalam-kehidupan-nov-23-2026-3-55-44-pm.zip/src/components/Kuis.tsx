import React, { useState } from 'react';
import {
  CheckCircle2,
  XCircle,
  RotateCcw,
  ArrowLeft,
  Trophy,
  BookOpen,
  AlertCircle,
  Sparkles,
  UserCheck,
} from 'lucide-react';
import { QUIZ_QUESTIONS } from '../data/biologyData';
import { calculateQuizScore, QuizScoreResult } from '../utils/quizLogic';
import { buildSpreadsheetScoreRecord } from '../utils/studentValidation';
import { SpreadsheetScoreRow, StudentIdentity } from '../types';
import { SpreadsheetPanel } from './SpreadsheetPanel';
import { ConfirmDialog } from './ConfirmDialog';

interface KuisProps {
  onGoToBeranda: () => void;
  onGoToWorksheet: () => void;
  onQuizCompletedChange?: (completed: boolean) => void;
  studentIdentity: StudentIdentity;
  onEditIdentity: () => void;
  scoreRecords: SpreadsheetScoreRow[];
  onRecordScore: (record: SpreadsheetScoreRow) => void;
  onDeleteScoreRecord: (id: string) => void;
  onClearScoreRecords: () => void;
  onImportScoreRecords: (rows: SpreadsheetScoreRow[]) => void;
}

export const Kuis: React.FC<KuisProps> = ({
  onGoToBeranda,
  onGoToWorksheet,
  onQuizCompletedChange,
  studentIdentity,
  onEditIdentity,
  scoreRecords,
  onRecordScore,
  onDeleteScoreRecord,
  onClearScoreRecords,
  onImportScoreRecords,
}) => {
  const [selectedAnswers, setSelectedAnswers] = useState<Record<number, number>>({});
  const [isSubmitted, setIsSubmitted] = useState<boolean>(false);
  const [scoreResult, setScoreResult] = useState<QuizScoreResult | null>(null);
  const [validationError, setValidationError] = useState<string | null>(null);
  const [lastRecordedNotice, setLastRecordedNotice] = useState<string | null>(null);
  const [showResetConfirm, setShowResetConfirm] = useState<boolean>(false);

  const handleSelectOption = (questionId: number, optionIndex: number) => {
    if (isSubmitted) return; // Answer locked after submission
    setSelectedAnswers((prev) => ({
      ...prev,
      [questionId]: optionIndex,
    }));
    setValidationError(null);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    const unanswered = QUIZ_QUESTIONS.filter((q) => selectedAnswers[q.id] === undefined);
    if (unanswered.length > 0) {
      setValidationError(
        `Ada ${unanswered.length} soal yang belum dijawab (Nomor ${unanswered.map((q) => q.id).join(', ')}). Silakan lengkapi semua jawaban sebelum mengirim.`
      );
      return;
    }

    const result = calculateQuizScore(selectedAnswers, QUIZ_QUESTIONS);
    const record = buildSpreadsheetScoreRecord(studentIdentity, result);
    onRecordScore(record);

    setScoreResult(result);
    setIsSubmitted(true);
    setValidationError(null);
    setLastRecordedNotice(
      `Data ${record.nama} (${record.kelas}, Absen ${record.noAbsen}) — Skor ${record.skor}/100 (Benar ${record.benar}, Salah ${record.salah}) otomatis dicatat ke tabel rekap.`
    );
    if (onQuizCompletedChange) {
      onQuizCompletedChange(true);
    }
  };

  const handleConfirmResetQuiz = () => {
    setSelectedAnswers({});
    setIsSubmitted(false);
    setScoreResult(null);
    setValidationError(null);
    setLastRecordedNotice(null);
    setShowResetConfirm(false);
    if (onQuizCompletedChange) {
      onQuizCompletedChange(false);
    }
  };

  const answeredCount = Object.keys(selectedAnswers).length;

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header Kuis */}
      <div className="bg-white rounded-2xl p-6 sm:p-8 border border-slate-200/80 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs font-semibold text-emerald-700 mb-1">
            <CheckCircle2 className="w-4 h-4" />
            <span>Bagian 4 · Evaluasi Pemahaman Mandiri</span>
          </div>
          <h2 className="text-xl sm:text-2xl font-bold text-slate-900 tracking-tight">
            Kuis: Peranan Virus, Bakteri, dan Jamur
          </h2>
          <p className="text-sm text-slate-600 mt-1 max-w-2xl leading-relaxed">
            Jawablah 5 butir soal pilihan ganda berikut. Setelah menekan tombol{' '}
            <strong>&quot;Kirim Jawaban Kuis&quot;</strong>, jawaban akan dikunci, skor ditampilkan, dan otomatis didata ke tabel rekap spreadsheet.
          </p>
        </div>

        <div className="flex items-center gap-2 self-start md:self-auto shrink-0">
          <button
            type="button"
            onClick={onGoToWorksheet}
            className="px-3.5 py-2 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors flex items-center gap-1.5 focus-visible:outline-2 focus-visible:outline-slate-600"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>Ke Lembar Kerja</span>
          </button>
        </div>
      </div>

      {/* Ringkasan Identitas Siswa */}
      <div className="bg-emerald-50/80 border border-emerald-200 rounded-2xl px-5 py-3.5 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
        <div className="flex flex-wrap items-center gap-x-4 gap-y-1.5 text-emerald-950">
          <span className="inline-flex items-center gap-1.5 font-bold text-emerald-800">
            <UserCheck className="w-4 h-4 text-emerald-600" />
            <span>Identitas Peserta Kuis:</span>
          </span>
          <span>
            Nama: <strong>{studentIdentity.nama}</strong>
          </span>
          <span>
            Kelas: <strong>{studentIdentity.kelas}</strong>
          </span>
          <span>
            No. Urut Absen: <strong>{studentIdentity.noAbsen}</strong>
          </span>
        </div>
        <button
          type="button"
          onClick={onEditIdentity}
          className="self-start sm:self-auto px-3 py-1 bg-white hover:bg-emerald-100 text-emerald-800 font-semibold rounded-lg border border-emerald-200 transition"
        >
          Ubah Identitas
        </button>
      </div>

      {/* Panel Rekap Skor & Ekspor Spreadsheet Gratis */}
      <SpreadsheetPanel
        studentIdentity={studentIdentity}
        scoreRecords={scoreRecords}
        lastRecordedNotice={lastRecordedNotice}
        onDeleteRecord={onDeleteScoreRecord}
        onClearRecords={onClearScoreRecords}
        onImportRecords={onImportScoreRecords}
      />

      {/* HASIL SKOR TOTAL (Tampil setelah dikirim) */}
      {isSubmitted && scoreResult && (
        <section
          aria-live="polite"
          className="rounded-3xl p-6 sm:p-8 bg-gradient-to-br from-slate-900 via-emerald-950 to-teal-950 text-white shadow-xl border border-emerald-500/40 animate-scale-up space-y-6"
        >
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-6 pb-6 border-b border-emerald-800/60">
            <div className="flex items-center gap-4">
              <div className="w-16 h-16 rounded-2xl bg-emerald-500/20 border border-emerald-400/50 flex items-center justify-center text-emerald-400 shrink-0">
                <Trophy className="w-8 h-8" />
              </div>
              <div>
                <span className="text-xs uppercase tracking-widest text-emerald-300 font-bold block mb-1">
                  Hasil Evaluasi Kuis · {studentIdentity.nama} ({studentIdentity.kelas} / Absen {studentIdentity.noAbsen})
                </span>
                <h3 className="text-2xl sm:text-3xl font-extrabold text-white">
                  Skor: {scoreResult.score} / 100
                </h3>
                <p className="text-xs sm:text-sm text-emerald-200/90 font-medium">
                  {scoreResult.correctCount} dari {scoreResult.totalQuestions} Soal Dijawab Benar ({scoreResult.percentage}%)
                </p>
              </div>
            </div>

            <div className="flex flex-wrap items-center gap-3">
              <div className="bg-emerald-900/60 border border-emerald-500/40 px-4 py-2 rounded-xl text-right">
                <span className="text-[10px] text-emerald-300 uppercase block font-semibold">Predikat</span>
                <span className="text-sm sm:text-base font-bold text-white">{scoreResult.predicate}</span>
              </div>
              <button
                type="button"
                onClick={() => setShowResetConfirm(true)}
                className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-white text-xs font-semibold rounded-xl border border-slate-700 transition flex items-center gap-2"
              >
                <RotateCcw className="w-3.5 h-3.5 text-emerald-400" />
                <span>Ulangi Kuis</span>
              </button>
            </div>
          </div>

          <div className="bg-emerald-900/40 rounded-2xl p-4 border border-emerald-500/30 text-xs sm:text-sm text-emerald-100 flex items-start gap-3">
            <Sparkles className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
            <div>
              <strong className="block font-semibold text-white mb-0.5">Umpan Balik Guru Biologi:</strong>
              <p>{scoreResult.feedback}</p>
            </div>
          </div>
        </section>
      )}

      {/* Form Kuis 5 Soal */}
      <form onSubmit={handleSubmit} className="space-y-6">
        {/* Status Bar */}
        <div className="bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 flex items-center justify-between text-xs text-slate-600">
          <div className="flex items-center gap-2">
            <span className="font-semibold text-slate-700">Progres Jawaban:</span>
            <span>
              {answeredCount} dari {QUIZ_QUESTIONS.length} Soal Dijawab
            </span>
          </div>
          {isSubmitted && (
            <span className="text-emerald-700 font-semibold bg-emerald-100 px-2.5 py-0.5 rounded-full">
              Jawaban Telah Terkunci
            </span>
          )}
        </div>

        {/* Validation Error Alert */}
        {validationError && (
          <div
            role="alert"
            className="p-4 bg-rose-50 border border-rose-200 text-rose-800 text-xs sm:text-sm rounded-xl flex items-start gap-2.5"
          >
            <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
            <span>{validationError}</span>
          </div>
        )}

        {/* Daftar 5 Soal */}
        <div className="space-y-6">
          {QUIZ_QUESTIONS.map((q, qIndex) => {
            const userAnswer = selectedAnswers[q.id];
            const isCorrect = isSubmitted && userAnswer === q.correctIndex;

            return (
              <div
                key={q.id}
                className={`bg-white rounded-2xl p-6 sm:p-7 border transition-all duration-200 shadow-xs ${
                  isSubmitted
                    ? isCorrect
                      ? 'border-emerald-300 bg-emerald-50/10'
                      : 'border-rose-300 bg-rose-50/10'
                    : 'border-slate-200/80 hover:border-slate-300'
                }`}
              >
                {/* Question Topic & Number Header */}
                <div className="flex items-center justify-between mb-3 text-xs">
                  <div className="flex items-center gap-2">
                    <span className="w-6 h-6 rounded-md bg-slate-900 text-white font-bold flex items-center justify-center text-xs">
                      {qIndex + 1}
                    </span>
                    <span className="font-semibold text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded-md border border-emerald-100">
                      Topik: {q.topic}
                    </span>
                  </div>

                  {isSubmitted && (
                    <div className="flex items-center gap-1.5 font-bold">
                      {isCorrect ? (
                        <span className="text-emerald-700 flex items-center gap-1">
                          <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                          <span>Benar (+20 Poin)</span>
                        </span>
                      ) : (
                        <span className="text-rose-700 flex items-center gap-1">
                          <XCircle className="w-4 h-4 text-rose-600" />
                          <span>Kurang Tepat</span>
                        </span>
                      )}
                    </div>
                  )}
                </div>

                {/* Question Text */}
                <h3 className="text-sm sm:text-base font-semibold text-slate-900 mb-4 leading-relaxed">
                  {q.question}
                </h3>

                {/* Multiple Choice Options */}
                <fieldset disabled={isSubmitted} className="space-y-2.5">
                  <legend className="sr-only">Pilihan jawaban untuk soal nomor {qIndex + 1}</legend>
                  {q.options.map((option, optIdx) => {
                    const isSelected = userAnswer === optIdx;
                    const isOptionCorrect = q.correctIndex === optIdx;

                    let optionStyle = 'border-slate-200 hover:bg-slate-50 text-slate-700';

                    if (isSubmitted) {
                      if (isOptionCorrect) {
                        optionStyle =
                          'border-emerald-500 bg-emerald-50 text-emerald-900 font-semibold ring-1 ring-emerald-500';
                      } else if (isSelected && !isOptionCorrect) {
                        optionStyle = 'border-rose-400 bg-rose-50 text-rose-900 line-through';
                      } else {
                        optionStyle = 'border-slate-200 text-slate-400 opacity-60';
                      }
                    } else if (isSelected) {
                      optionStyle =
                        'border-emerald-600 bg-emerald-50/70 text-emerald-950 font-medium ring-1 ring-emerald-600';
                    }

                    const optionLetter = String.fromCharCode(65 + optIdx); // A, B, C, D

                    return (
                      <label
                        key={optIdx}
                        className={`flex items-center justify-between p-3 sm:p-3.5 rounded-xl border text-xs sm:text-sm cursor-pointer transition-all ${optionStyle} ${
                          isSubmitted ? 'cursor-default' : ''
                        }`}
                      >
                        <div className="flex items-center gap-3">
                          <input
                            type="radio"
                            name={`question-${q.id}`}
                            value={optIdx}
                            checked={isSelected}
                            onChange={() => handleSelectOption(q.id, optIdx)}
                            disabled={isSubmitted}
                            className="w-4 h-4 text-emerald-600 focus:ring-emerald-500 cursor-pointer disabled:cursor-default"
                          />
                          <span className="font-bold text-slate-600 mr-1">{optionLetter}.</span>
                          <span>{option}</span>
                        </div>

                        {/* Visual indicator after submission */}
                        {isSubmitted && isOptionCorrect && (
                          <span className="text-xs font-bold text-emerald-700 flex items-center gap-1 shrink-0 ml-2">
                            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                            <span className="hidden sm:inline">Kunci Benar</span>
                          </span>
                        )}
                        {isSubmitted && isSelected && !isOptionCorrect && (
                          <span className="text-xs font-bold text-rose-700 flex items-center gap-1 shrink-0 ml-2">
                            <XCircle className="w-4 h-4 text-rose-600" />
                            <span className="hidden sm:inline">Jawaban Kamu</span>
                          </span>
                        )}
                      </label>
                    );
                  })}
                </fieldset>

                {/* PEMBAHASAN DETAIL (Hanya tampil setelah submit) */}
                {isSubmitted && (
                  <div className="mt-4 pt-4 border-t border-slate-200 text-xs sm:text-sm text-slate-700 space-y-2 bg-slate-50/70 p-4 rounded-xl">
                    <div className="flex items-center gap-2 font-bold text-slate-900">
                      <BookOpen className="w-4 h-4 text-emerald-700" />
                      <span>Pembahasan &amp; Konsep Ilmiah:</span>
                    </div>
                    <p className="leading-relaxed text-slate-600 pl-6">{q.explanation}</p>
                    <div className="pl-6 text-[11px] text-slate-500 pt-1 font-medium">
                      Kunci Jawaban yang Benar:{' '}
                      <strong className="text-emerald-700">
                        {String.fromCharCode(65 + q.correctIndex)}. {q.options[q.correctIndex]}
                      </strong>
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>

        {/* Submit or Reset Buttons */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-4 shadow-xs">
          {!isSubmitted ? (
            <div className="w-full flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <span className="text-xs text-slate-500">
                Jawaban akan dikunci dan skor {studentIdentity.nama} otomatis dicatat ke tabel rekap spreadsheet.
              </span>
              <button
                type="submit"
                className="w-full sm:w-auto px-6 py-3 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-sm rounded-xl transition shadow-sm hover:shadow-md active:scale-98 focus-visible:outline-2 focus-visible:outline-emerald-600 flex items-center justify-center gap-2"
              >
                <CheckCircle2 className="w-4 h-4" />
                <span>Kirim Jawaban Kuis</span>
              </button>
            </div>
          ) : (
            <div className="w-full flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <span className="text-xs text-slate-600">
                Kuis telah dinilai dan dicatat otomatis. Kamu dapat mengulangi kuis atau mengunduh hasil spreadsheet (.csv).
              </span>
              <div className="flex items-center gap-3">
                <button
                  type="button"
                  onClick={() => setShowResetConfirm(true)}
                  className="px-4 py-2.5 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-xl transition flex items-center gap-1.5"
                >
                  <RotateCcw className="w-3.5 h-3.5 text-emerald-600" />
                  <span>Ulangi Kuis</span>
                </button>
                <button
                  type="button"
                  onClick={onGoToBeranda}
                  className="px-5 py-2.5 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 rounded-xl transition shadow-xs flex items-center gap-1.5"
                >
                  <span>Selesai &amp; Kembali ke Beranda</span>
                </button>
              </div>
            </div>
          )}
        </div>
      </form>

      {/* Confirmation Dialog: Reset Quiz */}
      <ConfirmDialog
        isOpen={showResetConfirm}
        title="Ulangi Kuis dari Awal?"
        description="Semua pilihan jawaban Anda saat ini akan direset sehingga Anda dapat mengerjakan ulang 5 soal evaluasi."
        confirmLabel="Ya, Ulangi Kuis"
        variant="danger"
        onConfirm={handleConfirmResetQuiz}
        onCancel={() => setShowResetConfirm(false)}
      />
    </div>
  );
};
