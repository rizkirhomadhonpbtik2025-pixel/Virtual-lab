import React from 'react';
import { Microscope, Home, FileText, CheckCircle2, UserCheck, Pencil } from 'lucide-react';
import { ActiveTab, StudentIdentity } from '../types';

interface HeaderProps {
  activeTab: ActiveTab;
  onSelectTab: (tab: ActiveTab) => void;
  completedWorksheetCount: number;
  quizSubmitted: boolean;
  studentIdentity?: StudentIdentity | null;
  onEditIdentity?: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  onSelectTab,
  completedWorksheetCount,
  quizSubmitted,
  studentIdentity,
  onEditIdentity,
}) => {
  const steps: { id: ActiveTab; label: string; number: string; icon: React.ReactNode; indicator?: string }[] = [
    {
      id: 'beranda',
      label: 'Beranda',
      number: '1',
      icon: <Home className="w-4 h-4" />,
    },
    {
      id: 'pengamatan',
      label: 'Meja Pengamatan',
      number: '2',
      icon: <Microscope className="w-4 h-4" />,
    },
    {
      id: 'lembarkerja',
      label: 'Lembar Kerja',
      number: '3',
      icon: <FileText className="w-4 h-4" />,
      indicator: completedWorksheetCount > 0 ? `${completedWorksheetCount} Terisi` : undefined,
    },
    {
      id: 'kuis',
      label: 'Kuis Evaluasi',
      number: '4',
      icon: <CheckCircle2 className="w-4 h-4" />,
      indicator: quizSubmitted ? 'Selesai' : undefined,
    },
  ];

  return (
    <header className="sticky top-0 z-30 bg-white/95 backdrop-blur-md border-b border-emerald-100 shadow-xs">
      <div className="max-w-7xl mx-auto px-3 sm:px-6 lg:px-8">
        <div className="flex flex-col xl:flex-row xl:items-center xl:justify-between py-2.5 gap-2.5">
          {/* Logo & Title */}
          <div className="flex items-center justify-between gap-2 min-w-0">
            <div className="flex items-center gap-2.5 min-w-0">
              <div className="w-9 h-9 sm:w-10 sm:h-10 rounded-xl bg-gradient-to-tr from-emerald-600 to-teal-500 text-white flex items-center justify-center shadow-sm shrink-0">
                <Microscope className="w-5 h-5" />
              </div>
              <div className="min-w-0">
                <div className="flex flex-wrap items-center gap-1 text-[11px] sm:text-xs text-emerald-700 font-medium leading-tight">
                  <span>Biologi SMA/MA Kelas X</span>
                  <span aria-hidden="true">·</span>
                  <span>(Fase E)</span>
                  <span className="hidden md:inline" aria-hidden="true">·</span>
                  <span className="hidden md:inline">Discovery Learning</span>
                </div>
                <h1 className="text-sm sm:text-base font-bold text-slate-900 tracking-tight leading-snug truncate">
                  Virtual Lab Mini: Peranan Virus, Bakteri, &amp; Jamur
                </h1>
              </div>
            </div>

            {studentIdentity && (
              <div className="xl:hidden flex items-center gap-1.5 px-2.5 py-1 bg-emerald-50 border border-emerald-200 rounded-lg text-[11px] text-emerald-900 shrink-0">
                <UserCheck className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                <span className="font-semibold truncate max-w-[95px] sm:max-w-[160px]">{studentIdentity.nama}</span>
                <span className="hidden sm:inline text-emerald-700">
                  ({studentIdentity.kelas} · #{studentIdentity.noAbsen})
                </span>
                {onEditIdentity && (
                  <button
                    type="button"
                    onClick={onEditIdentity}
                    className="text-emerald-700 hover:text-emerald-950 p-0.5 rounded"
                    aria-label="Ubah identitas siswa"
                    title="Ubah Identitas Siswa"
                  >
                    <Pencil className="w-3 h-3" />
                  </button>
                )}
              </div>
            )}
          </div>

          <div className="flex items-center justify-between xl:justify-end gap-2">
            {/* Student Identity Pill (Desktop XL single-row) */}
            {studentIdentity && (
              <div className="hidden xl:flex items-center gap-1.5 px-2.5 py-1.5 bg-emerald-50/90 border border-emerald-200 rounded-xl text-xs text-emerald-950 shrink-0">
                <UserCheck className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                <div className="leading-tight whitespace-nowrap flex items-center gap-1">
                  <span className="font-bold max-w-[120px] truncate">{studentIdentity.nama}</span>
                  <span className="text-emerald-700">
                    ({studentIdentity.kelas} · Absen {studentIdentity.noAbsen})
                  </span>
                </div>
                {onEditIdentity && (
                  <button
                    type="button"
                    onClick={onEditIdentity}
                    className="ml-0.5 px-2 py-0.5 text-[10px] font-semibold bg-white hover:bg-emerald-100 text-emerald-800 border border-emerald-200 rounded-md transition"
                    aria-label="Ubah identitas siswa"
                  >
                    Ubah
                  </button>
                )}
              </div>
            )}

            {/* Navigation Steps */}
            <nav
              className="grid grid-cols-4 sm:flex sm:items-center gap-1 p-1 bg-slate-100/90 rounded-xl w-full sm:w-auto"
              aria-label="Navigasi Tahapan Laboratorium"
            >
              {steps.map((step) => {
                const isActive = activeTab === step.id;
                return (
                  <button
                    key={step.id}
                    onClick={() => onSelectTab(step.id)}
                    aria-current={isActive ? 'page' : undefined}
                    className={`flex items-center justify-center sm:justify-start gap-1 sm:gap-1.5 px-1.5 sm:px-2.5 py-1.5 text-[11px] sm:text-xs font-medium rounded-lg transition-all duration-150 whitespace-nowrap focus-visible:outline-2 focus-visible:outline-emerald-600 ${
                      isActive
                        ? 'bg-white text-emerald-800 shadow-xs font-semibold'
                        : 'text-slate-600 hover:text-slate-900 hover:bg-white/60'
                    }`}
                  >
                    <span
                      className={`w-4 h-4 sm:w-5 sm:h-5 rounded-full text-[10px] sm:text-[11px] font-bold flex items-center justify-center transition-colors shrink-0 ${
                        isActive ? 'bg-emerald-600 text-white' : 'bg-slate-200 text-slate-700'
                      }`}
                    >
                      {step.number}
                    </span>
                    <span className="hidden sm:inline">{step.label}</span>
                    <span className="sm:hidden truncate">{step.label.split(' ')[0]}</span>
                    {step.indicator && (
                      <span className="hidden md:inline text-[10px] text-emerald-700 font-semibold bg-emerald-50 border border-emerald-200 px-1.5 py-0.5 rounded">
                        {step.indicator}
                      </span>
                    )}
                  </button>
                );
              })}
            </nav>
          </div>
        </div>
      </div>
    </header>
  );
};

