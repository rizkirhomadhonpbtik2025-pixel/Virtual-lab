import React, { useState } from 'react';
import {
  User,
  GraduationCap,
  Hash,
  ArrowRight,
  Microscope,
  AlertCircle,
  FileSpreadsheet,
  CheckCircle2,
  FlaskConical,
} from 'lucide-react';
import { StudentIdentity } from '../types';
import { validateStudentIdentity } from '../utils/studentValidation';
import { playSlidePlaceSound } from '../utils/labAudio';

interface IdentitasSiswaProps {
  initialIdentity: StudentIdentity;
  onSubmitIdentity: (identity: StudentIdentity) => void;
}

const SUGGESTED_CLASSES = ['X-1', 'X-2', 'X-3', 'X IPA 1', 'X IPA 2', 'X Fase E'];

export const IdentitasSiswa: React.FC<IdentitasSiswaProps> = ({
  initialIdentity,
  onSubmitIdentity,
}) => {
  const [nama, setNama] = useState<string>(initialIdentity.nama);
  const [kelas, setKelas] = useState<string>(initialIdentity.kelas);
  const [noAbsen, setNoAbsen] = useState<string>(initialIdentity.noAbsen);
  const [errors, setErrors] = useState<Partial<Record<keyof StudentIdentity, string>>>({});

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const candidate: StudentIdentity = {
      nama: nama.trim(),
      kelas: kelas.trim(),
      noAbsen: noAbsen.trim(),
    };
    const validation = validateStudentIdentity(candidate);
    if (!validation.isValid) {
      setErrors(validation.errors);
      return;
    }

    setErrors({});
    playSlidePlaceSound();
    onSubmitIdentity(candidate);
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col justify-center py-8 px-4 sm:px-6 lg:px-8">
      <div className="max-w-4xl w-full mx-auto grid grid-cols-1 lg:grid-cols-12 gap-0 rounded-3xl overflow-hidden shadow-2xl border border-emerald-200/80 bg-white animate-scale-up">
        {/* Left Lab Cover Panel */}
        <div className="lg:col-span-5 bg-gradient-to-br from-slate-950 via-emerald-950 to-teal-950 text-white p-7 sm:p-8 flex flex-col justify-between relative overflow-hidden">
          <div className="absolute -right-12 -top-12 w-56 h-56 rounded-full bg-emerald-500/15 blur-2xl pointer-events-none" />
          <div className="absolute -left-12 -bottom-12 w-56 h-56 rounded-full bg-teal-400/10 blur-2xl pointer-events-none" />

          <div className="relative z-10 space-y-4">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/20 border border-emerald-400/40 text-emerald-300 text-xs font-semibold">
              <FlaskConical className="w-3.5 h-3.5" />
              <span>Biologi SMA/MA Kelas X (Fase E)</span>
            </div>

            <div className="w-12 h-12 rounded-2xl bg-emerald-500/20 border border-emerald-400/40 flex items-center justify-center text-emerald-300">
              <Microscope className="w-7 h-7" />
            </div>

            <h1 className="text-2xl sm:text-3xl font-black tracking-tight leading-snug text-white">
              Virtual Lab Mini
            </h1>
            <p className="text-xs sm:text-sm text-emerald-100/85 leading-relaxed">
              Media Pembelajaran Interaktif Peranan Virus, Bakteri, dan Jamur dalam Kehidupan.
            </p>
          </div>

          <div className="relative z-10 mt-8 space-y-3 pt-6 border-t border-emerald-800/60 text-xs text-emerald-100/90">
            <div className="flex items-start gap-2.5">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
              <span>Identitasmu otomatis terhubung ke Lembar Kerja &amp; Kuis Evaluasi.</span>
            </div>
            <div className="flex items-start gap-2.5">
              <FileSpreadsheet className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
              <span>
                Skor kuis otomatis dicatat ke <strong>Tabel Rekap &amp; Ekspor Spreadsheet (.csv)</strong> tanpa perlu login berbayar.
              </span>
            </div>
          </div>
        </div>

        {/* Right Identity Form */}
        <div className="lg:col-span-7 p-7 sm:p-10 flex flex-col justify-center">
          <div className="mb-6">
            <span className="text-xs font-bold uppercase tracking-wider text-emerald-700">
              Registrasi Kehadiran Praktikum
            </span>
            <h2 className="text-xl sm:text-2xl font-extrabold text-slate-900 mt-1">
              Isi Identitas Siswa Sebelum Memulai
            </h2>
            <p className="text-xs sm:text-sm text-slate-500 mt-1 leading-relaxed">
              Masukkan nama lengkap, kelas, dan nomor urut absen agar hasil pengamatan serta skor kuis kamu terdata secara otomatis di rekap spreadsheet.
            </p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4" noValidate>
            {/* Nama Lengkap */}
            <div>
              <label
                htmlFor="gate-nama-siswa"
                className="block text-xs font-bold text-slate-700 mb-1.5"
              >
                Nama Lengkap Siswa <span className="text-rose-600">*</span>
              </label>
              <div className="relative">
                <User className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
                <input
                  id="gate-nama-siswa"
                  type="text"
                  value={nama}
                  onChange={(e) => {
                    setNama(e.target.value);
                    if (errors.nama) setErrors((prev) => ({ ...prev, nama: undefined }));
                  }}
                  placeholder="Contoh: Budi Santoso"
                  autoComplete="name"
                  className={`w-full pl-10 pr-4 py-2.5 text-sm rounded-xl border bg-white text-slate-900 placeholder:text-slate-400 transition focus:outline-none focus:ring-2 ${
                    errors.nama
                      ? 'border-rose-400 focus:ring-rose-500/30'
                      : 'border-slate-300 focus:border-emerald-600 focus:ring-emerald-500/20'
                  }`}
                />
              </div>
              {errors.nama && (
                <p role="alert" className="mt-1 text-xs text-rose-600 flex items-center gap-1">
                  <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                  <span>{errors.nama}</span>
                </p>
              )}
            </div>

            {/* Kelas & No Urut Absen */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {/* Kelas */}
              <div>
                <label
                  htmlFor="gate-kelas-siswa"
                  className="block text-xs font-bold text-slate-700 mb-1.5"
                >
                  Kelas <span className="text-rose-600">*</span>
                </label>
                <div className="relative">
                  <GraduationCap className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
                  <input
                    id="gate-kelas-siswa"
                    type="text"
                    value={kelas}
                    onChange={(e) => {
                      setKelas(e.target.value);
                      if (errors.kelas) setErrors((prev) => ({ ...prev, kelas: undefined }));
                    }}
                    placeholder="Contoh: X-1 / X IPA 1"
                    className={`w-full pl-10 pr-4 py-2.5 text-sm rounded-xl border bg-white text-slate-900 placeholder:text-slate-400 transition focus:outline-none focus:ring-2 ${
                      errors.kelas
                        ? 'border-rose-400 focus:ring-rose-500/30'
                        : 'border-slate-300 focus:border-emerald-600 focus:ring-emerald-500/20'
                    }`}
                  />
                </div>
                <div className="flex flex-wrap gap-1 mt-1.5">
                  {SUGGESTED_CLASSES.map((cls) => (
                    <button
                      key={cls}
                      type="button"
                      onClick={() => {
                        setKelas(cls);
                        if (errors.kelas) setErrors((prev) => ({ ...prev, kelas: undefined }));
                      }}
                      className={`px-2 py-0.5 text-[10px] font-semibold rounded border transition ${
                        kelas === cls
                          ? 'bg-emerald-600 text-white border-emerald-600'
                          : 'bg-slate-50 text-slate-600 border-slate-200 hover:bg-emerald-50 hover:text-emerald-700'
                      }`}
                    >
                      {cls}
                    </button>
                  ))}
                </div>
                {errors.kelas && (
                  <p role="alert" className="mt-1 text-xs text-rose-600 flex items-center gap-1">
                    <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                    <span>{errors.kelas}</span>
                  </p>
                )}
              </div>

              {/* Nomor Urut Absen */}
              <div>
                <label
                  htmlFor="gate-absen-siswa"
                  className="block text-xs font-bold text-slate-700 mb-1.5"
                >
                  No. Urut Absen <span className="text-rose-600">*</span>
                </label>
                <div className="relative">
                  <Hash className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
                  <input
                    id="gate-absen-siswa"
                    type="number"
                    min={1}
                    max={99}
                    value={noAbsen}
                    onChange={(e) => {
                      setNoAbsen(e.target.value);
                      if (errors.noAbsen) setErrors((prev) => ({ ...prev, noAbsen: undefined }));
                    }}
                    placeholder="Contoh: 12"
                    className={`w-full pl-10 pr-4 py-2.5 text-sm rounded-xl border bg-white text-slate-900 placeholder:text-slate-400 transition focus:outline-none focus:ring-2 ${
                      errors.noAbsen
                        ? 'border-rose-400 focus:ring-rose-500/30'
                        : 'border-slate-300 focus:border-emerald-600 focus:ring-emerald-500/20'
                    }`}
                  />
                </div>
                <p className="mt-1.5 text-[11px] text-slate-400">
                  Isi angka urutan absen di kelas (1–99).
                </p>
                {errors.noAbsen && (
                  <p role="alert" className="mt-1 text-xs text-rose-600 flex items-center gap-1">
                    <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                    <span>{errors.noAbsen}</span>
                  </p>
                )}
              </div>
            </div>

            <div className="pt-3">
              <button
                type="submit"
                className="w-full py-3 px-6 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-sm rounded-xl transition shadow-md hover:shadow-lg flex items-center justify-center gap-2 focus-visible:outline-2 focus-visible:outline-emerald-600 active:scale-99 cursor-pointer"
              >
                <span>Masuk ke Beranda Laboratorium</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};
