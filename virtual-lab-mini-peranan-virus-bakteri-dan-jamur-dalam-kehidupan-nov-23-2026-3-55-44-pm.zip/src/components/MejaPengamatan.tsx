import React, { useState, useMemo } from 'react';
import {
  Microscope,
  ArrowRight,
  ArrowLeft,
  CheckCircle2,
  AlertTriangle,
  PlusCircle,
  Sparkles,
  Sun,
  Sliders,
  Maximize2,
  Grid,
  Info,
  ChevronLeft,
  ChevronRight,
  RotateCcw,
  Tag,
  FlaskConical,
  Box,
  Play,
  Pause,
  RotateCw,
  List,
  Eye,
} from 'lucide-react';
import { ORGANISM_GROUPS } from '../data/biologyData';
import { OrganismDetail, OrganismGroup } from '../types';
import { OrganismSvg } from './OrganismSvg';
import { Microscope3DCanvas } from './Microscope3DCanvas';
import { playLensClickSound, playSlidePlaceSound, playSwitchSound } from '../utils/labAudio';

interface MejaPengamatanProps {
  onGoToWorksheet: () => void;
  onGoToBeranda: () => void;
  onAddOrganismToWorksheet: (organism: OrganismDetail) => void;
}

// Magnification lenses available on the revolving nosepiece
type LensPower = '40x' | '100x' | '400x' | '1000x';

interface LensConfig {
  power: LensPower;
  label: string;
  colorRing: string; // international microscopy ring code
  scale: number;
  scaleUnit: string;
  fovSize: string;
}

const LENSES: Record<LensPower, LensConfig> = {
  '40x': {
    power: '40x',
    label: '4× Scanning',
    colorRing: 'bg-red-500',
    scale: 0.75,
    scaleUnit: 'Skala: 100 µm',
    fovSize: 'Lapang pandang luas',
  },
  '100x': {
    power: '100x',
    label: '10× Low Power',
    colorRing: 'bg-yellow-400',
    scale: 0.95,
    scaleUnit: 'Skala: 50 µm',
    fovSize: 'Struktur koloni',
  },
  '400x': {
    power: '400x',
    label: '40× High Power',
    colorRing: 'bg-blue-600',
    scale: 1.15,
    scaleUnit: 'Skala: 10 µm',
    fovSize: 'Detail seluler jernih',
  },
  '1000x': {
    power: '1000x',
    label: '100× Oil Immersion / TEM',
    colorRing: 'bg-slate-200 border border-slate-400',
    scale: 1.45,
    scaleUnit: 'Skala: 1 µm / 100 nm',
    fovSize: 'Ultra resolusi organel',
  },
};

export const MejaPengamatan: React.FC<MejaPengamatanProps> = ({
  onGoToWorksheet,
  onGoToBeranda,
  onAddOrganismToWorksheet,
}) => {
  // All organisms flattened for rapid indexing
  const allOrganisms = useMemo(() => {
    return ORGANISM_GROUPS.flatMap((g) => g.organisms);
  }, []);

  // Active specimen on the microscope stage (defaults to Bakteriofag)
  const [selectedOrganismId, setSelectedOrganismId] = useState<string>(allOrganisms[0].id);
  const [activeGroupFilter, setActiveGroupFilter] = useState<'all' | 'virus' | 'bakteri' | 'jamur'>('all');
  const [activeCategoryFilter, setActiveCategoryFilter] = useState<'all' | 'Menguntungkan' | 'Merugikan'>('all');

  // Microscope optical controls state
  const [currentLens, setCurrentLens] = useState<LensPower>('400x');
  const [focusValue, setFocusValue] = useState<number>(65); // 0 (very blurry) to 100 (sharpest at 65)
  const [lightIntensity, setLightIntensity] = useState<number>(85); // 20 to 100
  const [isLightOn, setIsLightOn] = useState<boolean>(true);
  const [showGraticule, setShowGraticule] = useState<boolean>(true);
  const [showStructureLabels, setShowStructureLabels] = useState<boolean>(true);
  const [activeHotspot, setActiveHotspot] = useState<string | null>(null);
  const [showAllStructuresList, setShowAllStructuresList] = useState<boolean>(false);

  // 3D Visualization Controls
  const [viewMode, setViewMode] = useState<'3d' | '2d'>('3d');
  const [is3dPlaying, setIs3dPlaying] = useState<boolean>(true);

  // Success toast feedback
  const [recordedToast, setRecordedToast] = useState<string | null>(null);

  const activeOrganism = useMemo(() => {
    return allOrganisms.find((org) => org.id === selectedOrganismId) || allOrganisms[0];
  }, [allOrganisms, selectedOrganismId]);

  const activeGroup = useMemo(() => {
    return ORGANISM_GROUPS.find((g) => g.organisms.some((o) => o.id === activeOrganism.id)) || ORGANISM_GROUPS[0];
  }, [activeOrganism]);

  // Blur calculation based on optical focus knob deviation from sweet spot (65)
  const focusDeviation = Math.abs(focusValue - 65);
  const blurAmount = (focusDeviation / 10).toFixed(1); // 0px at 65, up to ~3.5px
  const isOptimalFocus = focusDeviation <= 6;

  // Change specimen slide
  const handleSelectOrganism = (org: OrganismDetail) => {
    playSlidePlaceSound();
    setSelectedOrganismId(org.id);
    setActiveHotspot(null);
  };

  // Change lens power
  const handleSelectLens = (power: LensPower) => {
    playLensClickSound();
    setCurrentLens(power);
  };

  // Toggle light
  const handleToggleLight = () => {
    playSwitchSound();
    setIsLightOn((prev) => !prev);
  };

  // Auto-focus helper
  const handleAutoFocus = () => {
    playLensClickSound();
    setFocusValue(65);
  };

  // Copy to worksheet
  const handleRecordToWorksheet = () => {
    onAddOrganismToWorksheet(activeOrganism);
    setRecordedToast(`Preparat "${activeOrganism.name}" berhasil dicatat ke Lembar Kerja!`);
    setTimeout(() => {
      setRecordedToast(null);
    }, 3200);
  };

  // Next/Previous specimen
  const currentIndex = allOrganisms.findIndex((o) => o.id === activeOrganism.id);
  const handlePrevOrganism = () => {
    const nextIdx = (currentIndex - 1 + allOrganisms.length) % allOrganisms.length;
    handleSelectOrganism(allOrganisms[nextIdx]);
  };
  const handleNextOrganism = () => {
    const nextIdx = (currentIndex + 1) % allOrganisms.length;
    handleSelectOrganism(allOrganisms[nextIdx]);
  };

  // Filtered slides for tray
  const filteredOrganisms = useMemo(() => {
    return allOrganisms.filter((org) => {
      if (activeCategoryFilter !== 'all' && org.category !== activeCategoryFilter) {
        return false;
      }
      if (activeGroupFilter !== 'all') {
        const belongsToGroup = ORGANISM_GROUPS.find((g) => g.id === activeGroupFilter)?.organisms.some(
          (o) => o.id === org.id
        );
        if (!belongsToGroup) return false;
      }
      return true;
    });
  }, [allOrganisms, activeCategoryFilter, activeGroupFilter]);

  return (
    <div className="space-y-8 animate-fade-in">
      {/* Toast Notification */}
      {recordedToast && (
        <div
          role="status"
          aria-live="polite"
          className="fixed bottom-6 right-6 z-50 bg-slate-900 text-white px-4 py-3 rounded-xl shadow-xl border border-emerald-500/50 flex items-center gap-3 text-sm animate-scale-up"
        >
          <div className="w-6 h-6 rounded-full bg-emerald-500 text-slate-950 flex items-center justify-center font-bold text-xs shrink-0">
            ✓
          </div>
          <span>{recordedToast}</span>
          <button
            onClick={() => setRecordedToast(null)}
            className="text-slate-400 hover:text-white ml-2 text-xs"
            aria-label="Tutup notifikasi"
          >
            ✕
          </button>
        </div>
      )}

      {/* Laboratory Workbench Header */}
      <div className="bg-white rounded-2xl p-6 sm:p-7 border border-slate-200/90 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs font-semibold text-emerald-700 mb-1">
            <FlaskConical className="w-4 h-4 text-emerald-600" />
            <span>Stasiun Kerja Laboratorium Biologi Digital · Fase E (Kelas X)</span>
          </div>
          <h2 className="text-xl sm:text-2xl font-bold text-slate-900 tracking-tight">
            Meja Pengamatan Mikroskop Virtual
          </h2>
          <p className="text-xs sm:text-sm text-slate-600 mt-1 max-w-2xl leading-relaxed">
            Pilih kaca preparat objek di rak bawah untuk dipasang ke meja mikroskop. Putar pemutar fokus, ganti lensa objektif revolver, dan amati struktur serta peranan organisme dalam kehidupan.
          </p>
        </div>

        <div className="flex items-center gap-2.5 self-start md:self-auto shrink-0">
          <button
            onClick={onGoToBeranda}
            className="px-3.5 py-2 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors flex items-center gap-1.5 focus-visible:outline-2 focus-visible:outline-slate-600"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>Beranda</span>
          </button>
          <button
            onClick={onGoToWorksheet}
            className="px-4 py-2 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 rounded-lg transition-colors shadow-xs flex items-center gap-1.5 focus-visible:outline-2 focus-visible:outline-emerald-600"
          >
            <span>Buka Lembar Kerja</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* MAIN WORKBENCH: Interactive Microscope & Lab Notebook (Split 12 cols) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* LEFT / CENTER: Virtual Digital Microscope Eyepiece & Optical Stage (7 cols) */}
        <div className="lg:col-span-7 bg-slate-950 rounded-3xl p-5 sm:p-7 border-2 border-slate-800 shadow-xl text-white flex flex-col items-center relative overflow-hidden">
          {/* Subtle laboratory metal finish reflections */}
          <div className="absolute top-0 inset-x-0 h-1 bg-gradient-to-r from-transparent via-emerald-500/40 to-transparent" />

          {/* Top Bar inside Microscope: Active Specimen Status & 3D/2D Mode Switcher */}
          <div className="w-full flex flex-wrap items-center justify-between pb-3.5 mb-3 border-b border-slate-800/90 text-xs text-slate-400 gap-2">
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse" />
              <span className="font-mono text-emerald-400 uppercase tracking-wider text-[11px] font-bold">
                {activeGroup.title} · {activeOrganism.scientificName}
              </span>
            </div>

            {/* 3D / 2D Switcher & Play/Pause Controls */}
            <div className="flex items-center gap-2">
              <div className="inline-flex items-center p-0.5 bg-slate-900 rounded-lg border border-slate-800 text-[11px]">
                <button
                  onClick={() => setViewMode('3d')}
                  className={`px-2.5 py-1 rounded font-bold transition flex items-center gap-1 ${
                    viewMode === '3d'
                      ? 'bg-emerald-600 text-white shadow-xs'
                      : 'text-slate-400 hover:text-white'
                  }`}
                  title="Tampilan 3D Organisme Bergerak di Bawah Mikroskop"
                >
                  <Box className="w-3 h-3" />
                  <span>3D Realistis</span>
                </button>
                <button
                  onClick={() => setViewMode('2d')}
                  className={`px-2.5 py-1 rounded font-bold transition flex items-center gap-1 ${
                    viewMode === '2d'
                      ? 'bg-emerald-600 text-white shadow-xs'
                      : 'text-slate-400 hover:text-white'
                  }`}
                  title="Tampilan Diagram Vektor 2D"
                >
                  <span>2D Skematis</span>
                </button>
              </div>

              {viewMode === '3d' && (
                <button
                  onClick={() => setIs3dPlaying(!is3dPlaying)}
                  className={`p-1.5 rounded-lg border text-[11px] transition flex items-center gap-1 ${
                    is3dPlaying
                      ? 'bg-slate-900 border-slate-700 text-emerald-400 hover:text-white'
                      : 'bg-amber-950 border-amber-600 text-amber-300'
                  }`}
                  title={is3dPlaying ? 'Jeda Gerak 3D' : 'Lanjutkan Gerak 3D'}
                  aria-label={is3dPlaying ? 'Jeda Gerak 3D' : 'Lanjutkan Gerak 3D'}
                >
                  {is3dPlaying ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
                </button>
              )}

              <span className="font-mono text-slate-300 text-[11px] bg-slate-900 px-2 py-1 rounded-md border border-slate-800">
                {LENSES[currentLens].label.split(' ')[0]}
              </span>
            </div>
          </div>

          {/* CIRCULAR MICROSCOPE EYEPIECE (Lensa Okuler Binokuler 3D) */}
          <div className="relative my-2">
            {/* Outer metallic barrel ring */}
            <div className="w-72 h-72 sm:w-88 sm:h-88 md:w-96 md:h-96 rounded-full p-3 bg-gradient-to-b from-slate-700 via-slate-900 to-slate-950 shadow-2xl border-4 border-slate-800 flex items-center justify-center relative">
              {/* Inner bezel with millimeter tick marks */}
              <div className="w-full h-full rounded-full p-2.5 bg-slate-950 border border-slate-800 flex items-center justify-center relative overflow-hidden">
                {/* Optical Field of View (Lingkaran Lensa Pengamatan) */}
                <div
                  className={`w-full h-full rounded-full relative overflow-hidden flex items-center justify-center transition-all duration-300 ${
                    isLightOn ? 'bg-gradient-to-br ' + activeOrganism.slideTint : 'bg-slate-950'
                  }`}
                  style={{
                    filter: isLightOn && viewMode === '2d'
                      ? `brightness(${lightIntensity / 100}) contrast(${1 + (100 - focusDeviation) / 250})`
                      : undefined,
                  }}
                >
                  {/* Glass condenser glare & lens vignette */}
                  <div className="absolute inset-0 rounded-full shadow-[inset_0_0_50px_rgba(0,0,0,0.85)] pointer-events-none z-20" />
                  <div className="absolute -top-10 -left-10 w-44 h-44 rounded-full bg-white/5 blur-xl pointer-events-none z-20" />

                  {/* Stage Micrometer / Graticule Scale Grid */}
                  {showGraticule && isLightOn && (
                    <div className="absolute inset-0 pointer-events-none z-10 opacity-35">
                      <div className="w-full h-[1px] bg-emerald-400 absolute top-1/2 -translate-y-1/2" />
                      <div className="h-full w-[1px] bg-emerald-400 absolute left-1/2 -translate-x-1/2" />
                      <div className="w-3/4 h-3/4 border border-emerald-400/40 rounded-full absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2" />
                      <div className="w-1/2 h-1/2 border border-emerald-400/30 rounded-full absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2" />
                      {/* Scale ruler ticks */}
                      <div className="absolute bottom-6 left-1/2 -translate-x-1/2 flex items-center gap-1 text-[10px] text-emerald-300 font-mono bg-slate-950/70 px-2 py-0.5 rounded border border-emerald-400/30">
                        <span>{LENSES[currentLens].scaleUnit}</span>
                      </div>
                    </div>
                  )}

                  {/* SPECIMEN GRAPHIC (3D INTERACTIVE THREE.JS OR 2D SCHEMATIC) */}
                  <div className="w-full h-full flex items-center justify-center transition-all duration-300 select-none">
                    {viewMode === '3d' ? (
                      <Microscope3DCanvas
                        organism={activeOrganism}
                        lensPower={currentLens}
                        focusBlur={Number(blurAmount)}
                        lightIntensity={lightIntensity}
                        isLightOn={isLightOn}
                        isPlaying={is3dPlaying}
                        showStructureLabels={showStructureLabels}
                        activeHotspot={activeHotspot}
                        onSelectHotspot={setActiveHotspot}
                      />
                    ) : (
                      <div
                        className="w-full h-full flex items-center justify-center transition-all duration-300 select-none"
                        style={{
                          transform: `scale(${LENSES[currentLens].scale})`,
                          filter: `blur(${blurAmount}px)`,
                        }}
                      >
                        <OrganismSvg type={activeOrganism.svgType} className="w-full h-full" />
                      </div>
                    )}
                  </div>

                  {/* 2D INTERACTIVE STRUCTURE PINS (Scales with 4x - 1000x magnification) */}
                  {viewMode === '2d' && showStructureLabels && isLightOn && (
                    <div className="absolute inset-0 z-30 pointer-events-auto overflow-hidden rounded-full">
                      {activeOrganism.structures.map((struct, sIdx) => {
                        const isOpened = activeHotspot === struct.name;
                        const scale = LENSES[currentLens].scale;
                        // Dynamic center-relative scaling to match SVG transform: scale(...)
                        const adjustedX = 50 + (struct.xPercent - 50) * scale;
                        const adjustedY = 50 + (struct.yPercent - 50) * scale;
                        const dx = adjustedX - 50;
                        const dy = adjustedY - 50;
                        const distFromCenter = Math.sqrt(dx * dx + dy * dy);
                        // Prevent pin from floating outside circular lens frame
                        if (distFromCenter > 47) return null;

                        const isRightSide = adjustedX > 50;

                        return (
                          <div
                            key={sIdx}
                            className="absolute -translate-x-1/2 -translate-y-1/2 group transition-all duration-150"
                            style={{
                              left: `${adjustedX.toFixed(2)}%`,
                              top: `${adjustedY.toFixed(2)}%`,
                            }}
                          >
                            <button
                              onClick={() => setActiveHotspot(isOpened ? null : struct.name)}
                              className={`relative flex items-center justify-center p-2 focus-visible:outline-2 focus-visible:outline-white ${
                                isOpened ? 'scale-125 z-40' : 'hover:scale-115'
                              }`}
                              aria-label={`Lihat struktur ${struct.name}`}
                              title={`${struct.name} (Klik untuk membaca keterangan lengkap di panel bawah)`}
                            >
                              <span
                                className={`w-4 h-4 rounded-full border-2 border-slate-950 shadow-md transition-all ${
                                  isOpened
                                    ? 'bg-yellow-400 ring-4 ring-yellow-400/50 scale-110'
                                    : 'bg-emerald-400 group-hover:bg-emerald-300 ring-2 ring-emerald-500/40'
                                }`}
                              >
                                <span className={`w-1.5 h-1.5 rounded-full ${isOpened ? 'bg-slate-950' : 'bg-slate-950/80'}`} />
                              </span>
                              <span className={`absolute w-7 h-7 rounded-full animate-ping pointer-events-none ${isOpened ? 'bg-yellow-400/40' : 'bg-emerald-400/30'}`} />

                              {/* Smart Inward-Facing Label Tag (Never clipped by circular lens border) */}
                              <span
                                className={`absolute top-1/2 -translate-y-1/2 ${
                                  isRightSide ? 'right-[calc(100%+6px)]' : 'left-[calc(100%+6px)]'
                                } px-2.5 py-1 rounded-md text-[10px] font-bold whitespace-nowrap pointer-events-none transition-all shadow-lg ${
                                  isOpened
                                    ? 'bg-yellow-400 text-slate-950 block z-40 ring-1 ring-slate-900/40'
                                    : 'bg-slate-900/95 text-white border border-slate-700 hidden group-hover:block z-30'
                                }`}
                              >
                                {struct.name}
                              </span>
                            </button>
                          </div>
                        );
                      })}
                    </div>
                  )}

                  {/* Dark Room Indicator if Light is OFF */}
                  {!isLightOn && (
                    <div className="absolute inset-0 flex flex-col items-center justify-center bg-slate-950/95 text-slate-500 text-xs z-30">
                      <Sun className="w-6 h-6 text-slate-600 mb-1" />
                      <span>Lampu kondensor mati</span>
                      <button
                        onClick={handleToggleLight}
                        className="mt-2 px-3 py-1 bg-emerald-600 text-white rounded text-[11px] font-semibold"
                      >
                        Nyalakan Lampu
                      </button>
                    </div>
                  )}
                </div>
              </div>
            </div>

            {/* Quick Focus Status indicator */}
            <div className="mt-2 flex items-center justify-center gap-2 text-xs">
              <span
                className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-[11px] font-semibold transition-colors ${
                  isOptimalFocus
                    ? 'bg-emerald-950/80 text-emerald-300 border border-emerald-500/50'
                    : 'bg-amber-950/80 text-amber-300 border border-amber-500/50'
                }`}
              >
                <Sparkles className="w-3 h-3" />
                <span>{isOptimalFocus ? 'Fokus Optik: Tajam & Jernih' : 'Fokus Optik: Sedikit Kabur (Putar Mikrometer)'}</span>
              </span>
              {!isOptimalFocus && (
                <button
                  onClick={handleAutoFocus}
                  className="text-[11px] text-emerald-400 hover:text-emerald-300 underline font-medium"
                >
                  Auto-Focus
                </button>
              )}
            </div>

            {/* 3D Drag & Rotate User Guidance */}
            {viewMode === '3d' && (
              <div className="mt-1.5 flex items-center justify-center gap-1.5 text-[11px] text-slate-400">
                <RotateCw className="w-3 h-3 text-emerald-400 animate-spin-slow" />
                <span>Geser/seret pada lingkaran lensa untuk memutar 3D 360° · Titik pin mengikuti organel</span>
              </div>
            )}

            {/* PANEL KETERANGAN TUNJUKAN ORGANEL (Ditempatkan di luar lensa agar terlihat 100% dan bebas dari halangan lensa) */}
            <div className="w-full mt-3 p-3 sm:p-4 rounded-2xl bg-slate-900/95 border-2 border-emerald-500/40 shadow-xl text-left">
              {/* Header: Title, Magnification Status, and View Mode Toggle */}
              <div className="flex flex-wrap items-center justify-between gap-2 pb-2.5 mb-2.5 border-b border-slate-800">
                <div className="flex items-center gap-2">
                  <div className="w-6 h-6 rounded-lg bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center text-emerald-400">
                    <Info className="w-3.5 h-3.5" />
                  </div>
                  <div>
                    <h4 className="text-xs sm:text-sm font-bold text-white flex items-center gap-1.5">
                      <span>Keterangan Tunjukan Struktur Organel</span>
                      <span className="text-[10px] font-mono font-normal text-emerald-400 bg-emerald-950/80 px-2 py-0.5 rounded border border-emerald-500/40">
                        {viewMode === '3d' ? '3D Tracked' : '2D Scaled'} · {currentLens}
                      </span>
                    </h4>
                  </div>
                </div>

                {/* View Mode Toggle: Single Focus vs View All Structures */}
                <div className="flex items-center gap-1.5">
                  <button
                    onClick={() => setShowAllStructuresList(!showAllStructuresList)}
                    className={`px-2.5 py-1 rounded-lg text-[11px] font-medium transition flex items-center gap-1 border ${
                      showAllStructuresList
                        ? 'bg-emerald-600 border-emerald-500 text-white shadow-xs'
                        : 'bg-slate-800/90 hover:bg-slate-800 border-slate-700 text-slate-300'
                    }`}
                    title={showAllStructuresList ? 'Kembali ke tampilan fokus' : 'Tampilkan seluruh keterangan organel'}
                  >
                    {showAllStructuresList ? <Eye className="w-3 h-3" /> : <List className="w-3 h-3" />}
                    <span>{showAllStructuresList ? 'Fokus Tunggal' : `Lihat Semua (${activeOrganism.structures.length})`}</span>
                  </button>

                  {activeHotspot && !showAllStructuresList && (
                    <button
                      onClick={() => setActiveHotspot(null)}
                      className="px-2 py-1 rounded-lg text-[10px] bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition border border-slate-700"
                      title="Batal pilih organel"
                      aria-label="Tutup keterangan organel"
                    >
                      ✕ Tutup
                    </button>
                  )}
                </div>
              </div>

              {/* MODE 1: VIEW ALL STRUCTURES (Semua keterangan terlihat sekaligus di luar lensa) */}
              {showAllStructuresList ? (
                <div className="space-y-2.5 max-h-80 overflow-y-auto pr-1">
                  <div className="text-[11px] text-slate-400 flex items-center justify-between pb-1">
                    <span>Daftar lengkap seluruh struktur organel <strong>{activeOrganism.name}</strong>:</span>
                    <span className="text-[10px] text-emerald-400 font-mono">{activeOrganism.structures.length} Bagian</span>
                  </div>
                  <div className="grid grid-cols-1 gap-2">
                    {activeOrganism.structures.map((struct, sIdx) => {
                      const isSelected = activeHotspot === struct.name;
                      return (
                        <div
                          key={sIdx}
                          className={`p-3 rounded-xl border transition-all ${
                            isSelected
                              ? 'bg-slate-950 border-yellow-400/80 shadow-md ring-1 ring-yellow-400/40'
                              : 'bg-slate-950/60 border-slate-800 hover:border-slate-700'
                          }`}
                        >
                          <div className="flex items-center justify-between mb-1.5">
                            <div className="flex items-center gap-2">
                              <span
                                className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-bold ${
                                  isSelected
                                    ? 'bg-yellow-400 text-slate-950'
                                    : 'bg-emerald-950 text-emerald-300 border border-emerald-500/40'
                                }`}
                              >
                                {sIdx + 1}
                              </span>
                              <span className="font-bold text-xs sm:text-sm text-white">
                                {struct.name}
                              </span>
                            </div>
                            <button
                              onClick={() => {
                                setActiveHotspot(struct.name);
                              }}
                              className={`text-[10px] font-medium px-2 py-0.5 rounded transition ${
                                isSelected
                                  ? 'bg-yellow-400 text-slate-950 font-bold'
                                  : 'bg-slate-800 hover:bg-slate-700 text-slate-300'
                              }`}
                            >
                              {isSelected ? '✓ Terpilih di Lensa' : 'Sorot di Lensa'}
                            </button>
                          </div>
                          <p className="text-xs text-slate-300 leading-relaxed font-normal">
                            {struct.description}
                          </p>
                        </div>
                      );
                    })}
                  </div>
                </div>
              ) : (
                /* MODE 2: SINGLE FOCUS ORGANELLE (Detail mendalam struktur yang sedang ditunjuk) */
                <div>
                  {(() => {
                    const activeStruct = activeOrganism.structures.find((s) => s.name === activeHotspot);
                    const currentIdx = activeStruct
                      ? activeOrganism.structures.findIndex((s) => s.name === activeHotspot)
                      : -1;

                    if (!activeStruct) {
                      return (
                        <div className="p-3 rounded-xl bg-slate-950/70 border border-dashed border-slate-800 text-slate-400 text-xs flex items-center gap-3">
                          <div className="w-8 h-8 rounded-full bg-slate-900 border border-slate-700 flex items-center justify-center shrink-0 text-emerald-400">
                            <Tag className="w-4 h-4" />
                          </div>
                          <div className="leading-snug">
                            <p className="font-semibold text-slate-200">
                              Belum ada organel yang dipilih.
                            </p>
                            <p className="text-[11px] text-slate-400 mt-0.5">
                              Klik titik penunjuk (pin hijau/kuning) pada spesimen di atas, atau pilih salah satu tombol organel di bawah untuk membaca keterangan fungsinya.
                            </p>
                          </div>
                        </div>
                      );
                    }

                    return (
                      <div className="p-3.5 rounded-xl bg-slate-950 border border-emerald-500/50 shadow-inner">
                        {/* Title and Index Row */}
                        <div className="flex items-center justify-between gap-2 mb-2">
                          <div className="flex items-center gap-2">
                            <span className="w-3 h-3 rounded-full bg-yellow-400 animate-pulse shrink-0" />
                            <h5 className="font-extrabold text-sm sm:text-base text-yellow-300">
                              {activeStruct.name}
                            </h5>
                          </div>
                          <span className="text-[10px] font-mono text-slate-400 bg-slate-900 px-2 py-0.5 rounded border border-slate-800">
                            Struktur {currentIdx + 1} dari {activeOrganism.structures.length}
                          </span>
                        </div>

                        {/* Full Detailed Description (100% visible, outside lens) */}
                        <p className="text-xs sm:text-sm text-slate-200 leading-relaxed font-normal bg-slate-900/60 p-2.5 rounded-lg border border-slate-800/80">
                          {activeStruct.description}
                        </p>

                        {/* Navigation between structures */}
                        <div className="mt-2.5 pt-2 border-t border-slate-800/80 flex items-center justify-between text-xs">
                          <button
                            onClick={() => {
                              const prevIdx =
                                currentIdx > 0
                                  ? currentIdx - 1
                                  : activeOrganism.structures.length - 1;
                              setActiveHotspot(activeOrganism.structures[prevIdx].name);
                            }}
                            className="inline-flex items-center gap-1 text-[11px] text-slate-400 hover:text-white px-2 py-1 rounded bg-slate-900 hover:bg-slate-800 transition"
                          >
                            <ChevronLeft className="w-3 h-3" />
                            <span>Organel Sebelumnya</span>
                          </button>
                          <button
                            onClick={() => {
                              const nextIdx =
                                currentIdx < activeOrganism.structures.length - 1
                                  ? currentIdx + 1
                                  : 0;
                              setActiveHotspot(activeOrganism.structures[nextIdx].name);
                            }}
                            className="inline-flex items-center gap-1 text-[11px] text-emerald-400 hover:text-emerald-300 px-2 py-1 rounded bg-slate-900 hover:bg-slate-800 transition font-medium"
                          >
                            <span>Organel Berikutnya</span>
                            <ChevronRight className="w-3 h-3" />
                          </button>
                        </div>
                      </div>
                    );
                  })()}
                </div>
              )}

              {/* Quick Organelle Selector Buttons (Pills Bar) */}
              <div className="mt-3 pt-2.5 border-t border-slate-800">
                <div className="text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-1.5 flex items-center justify-between">
                  <span>Pilih Organel untuk Menampilkan Keterangan:</span>
                  <span className="text-slate-500">{activeOrganism.structures.length} Bagian</span>
                </div>
                <div className="flex flex-wrap items-center gap-1.5">
                  {activeOrganism.structures.map((struct, idx) => {
                    const isActive = activeHotspot === struct.name;
                    return (
                      <button
                        key={idx}
                        onClick={() => {
                          setActiveHotspot(isActive ? null : struct.name);
                        }}
                        className={`px-2.5 py-1 rounded-lg text-[11px] font-semibold transition-all flex items-center gap-1.5 ${
                          isActive
                            ? 'bg-yellow-400 text-slate-950 shadow-md font-bold ring-2 ring-yellow-400/50 scale-102'
                            : 'bg-slate-800/90 hover:bg-slate-800 text-slate-300 hover:text-white border border-slate-700/60'
                        }`}
                        title={struct.description}
                      >
                        <span
                          className={`w-4 h-4 rounded-full flex items-center justify-center text-[9px] font-bold ${
                            isActive
                              ? 'bg-slate-950 text-yellow-400'
                              : 'bg-slate-700 text-slate-300'
                          }`}
                        >
                          {idx + 1}
                        </span>
                        <span>{struct.name}</span>
                      </button>
                    );
                  })}
                </div>
              </div>
            </div>
          </div>

          {/* MICROSCOPE CONTROLS BENCH (Panel Pengaturan Optik Mikroskop) */}
          <div className="w-full mt-4 pt-4 border-t border-slate-800 space-y-4">
            {/* 1. Revolving Nosepiece Lenses (Revolver Objektif) */}
            <div>
              <div className="text-[11px] font-bold uppercase tracking-wider text-slate-400 mb-2 flex items-center justify-between">
                <span>Revolver Lensa Objektif:</span>
                <span className="text-[10px] text-slate-500">Standar DIN Laboratorium</span>
              </div>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                {(Object.keys(LENSES) as LensPower[]).map((power) => {
                  const lens = LENSES[power];
                  const isActive = currentLens === power;
                  return (
                    <button
                      key={power}
                      onClick={() => handleSelectLens(power)}
                      className={`p-2.5 rounded-xl border text-left transition-all duration-150 flex flex-col justify-between focus-visible:outline-2 focus-visible:outline-emerald-500 ${
                        isActive
                          ? 'bg-slate-900 border-emerald-500 shadow-md ring-1 ring-emerald-500/50'
                          : 'bg-slate-900/60 border-slate-800 hover:bg-slate-900 hover:border-slate-700 text-slate-400'
                      }`}
                    >
                      <div className="flex items-center justify-between mb-1">
                        <span className={`w-3 h-3 rounded-full ${lens.colorRing}`} />
                        <span className="text-[10px] font-mono text-slate-400">{power}</span>
                      </div>
                      <div className="text-xs font-bold text-white leading-tight">
                        {lens.label.split(' ')[0]}
                      </div>
                      <div className="text-[10px] text-slate-400 truncate">
                        {lens.label.split(' ').slice(1).join(' ')}
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* 2. Knobs: Focus Slider & Condenser Light Slider */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-1">
              {/* Focus Knob (Makrometer & Mikrometer) */}
              <div className="bg-slate-900/80 p-3 rounded-xl border border-slate-800">
                <div className="flex items-center justify-between text-xs mb-1.5">
                  <label htmlFor="microscope-focus-slider" className="font-semibold text-slate-300 flex items-center gap-1.5">
                    <Sliders className="w-3.5 h-3.5 text-emerald-400" />
                    <span>Pemutar Fokus (Mikrometer)</span>
                  </label>
                  <span className="font-mono text-[11px] text-emerald-400">{focusValue}%</span>
                </div>
                <input
                  id="microscope-focus-slider"
                  type="range"
                  min="0"
                  max="100"
                  value={focusValue}
                  onChange={(e) => setFocusValue(Number(e.target.value))}
                  className="w-full accent-emerald-500 cursor-pointer h-1.5 bg-slate-800 rounded-lg"
                />
                <div className="flex items-center justify-between text-[10px] text-slate-500 mt-1">
                  <span>Kabur</span>
                  <span className="text-emerald-400 font-semibold">Titik Fokus Ideal (65)</span>
                  <span>Kabur</span>
                </div>
              </div>

              {/* Condenser Light Slider & Power Switch */}
              <div className="bg-slate-900/80 p-3 rounded-xl border border-slate-800">
                <div className="flex items-center justify-between text-xs mb-1.5">
                  <div className="flex items-center gap-2">
                    <label htmlFor="microscope-light-slider" className="font-semibold text-slate-300 flex items-center gap-1.5">
                      <Sun className="w-3.5 h-3.5 text-yellow-400" />
                      <span>Intensitas Lampu LED</span>
                    </label>
                  </div>
                  <button
                    onClick={handleToggleLight}
                    className={`text-[10px] font-bold px-2 py-0.5 rounded transition ${
                      isLightOn ? 'bg-emerald-600 text-white' : 'bg-slate-800 text-slate-400'
                    }`}
                  >
                    {isLightOn ? 'ON' : 'OFF'}
                  </button>
                </div>
                <input
                  id="microscope-light-slider"
                  type="range"
                  min="20"
                  max="100"
                  disabled={!isLightOn}
                  value={lightIntensity}
                  onChange={(e) => setLightIntensity(Number(e.target.value))}
                  className="w-full accent-yellow-400 cursor-pointer h-1.5 bg-slate-800 rounded-lg disabled:opacity-40"
                />
                <div className="flex items-center justify-between text-[10px] text-slate-500 mt-1">
                  <span>Redup</span>
                  <span className="text-yellow-400 font-mono">{isLightOn ? `${lightIntensity}%` : 'Mati'}</span>
                  <span>Terang</span>
                </div>
              </div>
            </div>

            {/* 3. Toggles: Graticule Grid & Structure Hotspots */}
            <div className="flex flex-wrap items-center justify-between gap-2 pt-1 text-xs">
              <div className="flex items-center gap-2">
                <button
                  onClick={() => setShowGraticule(!showGraticule)}
                  className={`px-3 py-1.5 rounded-lg border text-[11px] font-medium transition flex items-center gap-1.5 ${
                    showGraticule
                      ? 'bg-emerald-950 border-emerald-500 text-emerald-300'
                      : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-white'
                  }`}
                >
                  <Grid className="w-3.5 h-3.5" />
                  <span>Skala Mistar Graticule: {showGraticule ? 'Aktif' : 'Nonaktif'}</span>
                </button>

                <button
                  onClick={() => setShowStructureLabels(!showStructureLabels)}
                  className={`px-3 py-1.5 rounded-lg border text-[11px] font-medium transition flex items-center gap-1.5 ${
                    showStructureLabels
                      ? 'bg-emerald-950 border-emerald-500 text-emerald-300'
                      : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-white'
                  }`}
                >
                  <Info className="w-3.5 h-3.5" />
                  <span>Pin Struktur Organel: {showStructureLabels ? 'Tampil' : 'Sembunyi'}</span>
                </button>
              </div>

              <div className="text-[11px] text-slate-400">
                Klik pin hijau di atas spesimen untuk detail organel
              </div>
            </div>
          </div>
        </div>

        {/* RIGHT: Specimen Card & Laboratory Logbook (5 cols) */}
        <div className="lg:col-span-5 space-y-5">
          {/* Active Specimen Glass Slide Preview (Visual Kaca Preparat Laboratorium) */}
          <div className="bg-white rounded-3xl p-6 border border-slate-200/90 shadow-sm space-y-4">
            {/* Glass Slide Realistic Banner */}
            <div className="relative rounded-2xl p-4 bg-gradient-to-r from-slate-100 via-emerald-50/40 to-slate-100 border border-slate-300/80 shadow-inner overflow-hidden">
              {/* Frosted glass slide label edge */}
              <div className="flex items-center justify-between mb-3 border-b border-slate-300/80 pb-2">
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded-full bg-slate-300 border border-slate-400" />
                  <span className="text-[11px] font-mono uppercase tracking-wider text-slate-500 font-semibold">
                    Kaca Objek Preparat No. {currentIndex + 1}
                  </span>
                </div>
                <span
                  className={`text-[11px] font-bold px-2.5 py-0.5 rounded-full ${
                    activeOrganism.category === 'Menguntungkan'
                      ? 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                      : 'bg-rose-100 text-rose-800 border border-rose-300'
                  }`}
                >
                  {activeOrganism.category === 'Menguntungkan' ? '✓ Menguntungkan' : '⚠ Merugikan'}
                </span>
              </div>

              {/* Title & Classification */}
              <div>
                <h3 className="text-xl font-extrabold text-slate-900 tracking-tight leading-snug">
                  {activeOrganism.name}
                </h3>
                <p className="text-xs text-slate-500 italic font-serif mt-0.5">
                  {activeOrganism.scientificName}
                </p>
              </div>

              {/* Lab Technique & Staining */}
              <div className="mt-3 pt-2.5 border-t border-slate-200/80 grid grid-cols-1 sm:grid-cols-2 gap-2 text-[11px]">
                <div>
                  <span className="text-slate-400 block font-medium">Metode Pewarnaan:</span>
                  <span className="font-semibold text-slate-700">{activeOrganism.stainMethod}</span>
                </div>
                <div>
                  <span className="text-slate-400 block font-medium">Perbesaran Rekomendasi:</span>
                  <span className="font-semibold text-emerald-800">{activeOrganism.magnificationDesc}</span>
                </div>
              </div>
            </div>

            {/* Peranan Utama dalam Kehidupan (Materi Dokumen PDF) */}
            <div
              className={`p-4 rounded-2xl border transition-colors ${
                activeOrganism.category === 'Menguntungkan'
                  ? 'bg-emerald-50/80 border-emerald-200 text-emerald-950'
                  : 'bg-rose-50/80 border-rose-200 text-rose-950'
              }`}
            >
              <div className="text-xs font-bold uppercase tracking-wider mb-1.5 flex items-center gap-1.5 opacity-90">
                <Sparkles className="w-3.5 h-3.5" />
                <span>Peranan Utama dalam Kehidupan:</span>
              </div>
              <p className="text-sm font-semibold leading-relaxed">
                {activeOrganism.peranan}
              </p>
            </div>

            {/* Active Organelle Spotlight in Notebook */}
            {activeHotspot && (() => {
              const activeStruct = activeOrganism.structures.find((s) => s.name === activeHotspot);
              if (!activeStruct) return null;
              return (
                <div className="p-3.5 rounded-2xl bg-amber-50/80 border border-amber-300/80 text-amber-950 text-xs shadow-xs">
                  <div className="flex items-center justify-between font-bold text-amber-900 mb-1">
                    <span className="flex items-center gap-1.5">
                      <span className="w-2 h-2 rounded-full bg-amber-500 animate-pulse" />
                      <span>Keterangan Tunjukan Organel: {activeStruct.name}</span>
                    </span>
                    <button
                      onClick={() => setActiveHotspot(null)}
                      className="text-amber-700 hover:text-amber-950 text-[10px] px-1.5 py-0.5 rounded bg-amber-100 hover:bg-amber-200 transition"
                      title="Tutup sorotan struktur"
                    >
                      ✕ Tutup
                    </button>
                  </div>
                  <p className="text-amber-900/90 leading-relaxed text-[11px] font-normal">
                    {activeStruct.description}
                  </p>
                </div>
              );
            })()}

            {/* Mekanisme / Alasan Singkat */}
            <div className="bg-slate-50 rounded-2xl p-4 border border-slate-200/80 space-y-1.5 text-xs sm:text-sm">
              <div className="font-bold text-slate-800 flex items-center gap-1.5">
                <span>Alasan / Mekanisme Kerja Biologis:</span>
              </div>
              <p className="text-slate-600 leading-relaxed text-xs sm:text-sm">
                {activeOrganism.alasan}
              </p>
            </div>

            {/* Deskripsi & Ciri Morfologi */}
            <div className="space-y-2 text-xs text-slate-600">
              <p className="leading-relaxed">
                {activeOrganism.description}
              </p>
              <div className="bg-slate-50/60 p-3 rounded-xl border border-slate-200/60 space-y-1.5 text-[11px]">
                <div>
                  <strong className="text-slate-700">Ciri Morfologi Khas: </strong>
                  <span className="text-slate-600">{activeOrganism.ciriKhas}</span>
                </div>
                <div>
                  <strong className="text-slate-700">Habitat / Inang Alami: </strong>
                  <span className="text-slate-600">{activeOrganism.habitatAtauInang}</span>
                </div>
              </div>
            </div>

            {/* Interactive Action: Catat ke Lembar Kerja */}
            <div className="pt-2 flex flex-col sm:flex-row items-center gap-3">
              <button
                onClick={handleRecordToWorksheet}
                className="w-full sm:flex-1 py-3 px-4 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs sm:text-sm rounded-xl transition-all shadow-xs hover:shadow flex items-center justify-center gap-2 focus-visible:outline-2 focus-visible:outline-emerald-600 active:scale-98"
              >
                <PlusCircle className="w-4 h-4" />
                <span>Catat ke Lembar Kerja Saya</span>
              </button>
            </div>

            {/* Previous / Next Organism Navigator */}
            <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
              <button
                onClick={handlePrevOrganism}
                className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg hover:bg-slate-100 text-slate-700 transition"
              >
                <ChevronLeft className="w-3.5 h-3.5" />
                <span>Sebelumnya</span>
              </button>
              <span className="font-mono text-[11px] text-slate-400">
                Spesimen {currentIndex + 1} / {allOrganisms.length}
              </span>
              <button
                onClick={handleNextOrganism}
                className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg hover:bg-slate-100 text-slate-700 transition"
              >
                <span>Berikutnya</span>
                <ChevronRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* BOTTOM BENCH: Rak Kaca Objek Preparat (Glass Slide Rack & Organizer) */}
      <div className="bg-white rounded-3xl p-6 sm:p-7 border border-slate-200/90 shadow-xs space-y-5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-200">
          <div>
            <div className="flex items-center gap-2 text-xs font-semibold text-emerald-700 mb-0.5">
              <Microscope className="w-3.5 h-3.5" />
              <span>Rak Preparat Mikroskop Laboratorium</span>
            </div>
            <h3 className="text-lg font-bold text-slate-900 tracking-tight">
              Pilih Kaca Preparat untuk Dipasang ke Meja Mikroskop
            </h3>
          </div>

          {/* Group and Category Filters */}
          <div className="flex flex-wrap items-center gap-2 text-xs">
            {/* Filter Group: All, Virus, Bakteri, Jamur */}
            <div className="inline-flex items-center p-1 bg-slate-100 rounded-xl">
              <button
                onClick={() => setActiveGroupFilter('all')}
                className={`px-3 py-1.5 rounded-lg font-medium transition-colors ${
                  activeGroupFilter === 'all'
                    ? 'bg-white text-slate-900 shadow-xs font-bold'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Semua Objek
              </button>
              <button
                onClick={() => setActiveGroupFilter('virus')}
                className={`px-3 py-1.5 rounded-lg font-medium transition-colors ${
                  activeGroupFilter === 'virus'
                    ? 'bg-white text-emerald-800 shadow-xs font-bold'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Virus
              </button>
              <button
                onClick={() => setActiveGroupFilter('bakteri')}
                className={`px-3 py-1.5 rounded-lg font-medium transition-colors ${
                  activeGroupFilter === 'bakteri'
                    ? 'bg-white text-teal-800 shadow-xs font-bold'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Bakteri
              </button>
              <button
                onClick={() => setActiveGroupFilter('jamur')}
                className={`px-3 py-1.5 rounded-lg font-medium transition-colors ${
                  activeGroupFilter === 'jamur'
                    ? 'bg-white text-sky-800 shadow-xs font-bold'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Jamur
              </button>
            </div>

            {/* Filter Category: Menguntungkan vs Merugikan */}
            <div className="inline-flex items-center p-1 bg-slate-100 rounded-xl">
              <button
                onClick={() => setActiveCategoryFilter('all')}
                className={`px-2.5 py-1.5 rounded-lg text-[11px] font-medium transition-colors ${
                  activeCategoryFilter === 'all'
                    ? 'bg-slate-900 text-white shadow-xs font-bold'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Semua
              </button>
              <button
                onClick={() => setActiveCategoryFilter('Menguntungkan')}
                className={`px-2.5 py-1.5 rounded-lg text-[11px] font-medium transition-colors ${
                  activeCategoryFilter === 'Menguntungkan'
                    ? 'bg-emerald-600 text-white shadow-xs font-bold'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Menguntungkan
              </button>
              <button
                onClick={() => setActiveCategoryFilter('Merugikan')}
                className={`px-2.5 py-1.5 rounded-lg text-[11px] font-medium transition-colors ${
                  activeCategoryFilter === 'Merugikan'
                    ? 'bg-rose-600 text-white shadow-xs font-bold'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Merugikan
              </button>
            </div>
          </div>
        </div>

        {/* 3D Glass Slide Cards Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-3.5">
          {filteredOrganisms.map((org) => {
            const isLoaded = org.id === activeOrganism.id;
            return (
              <button
                key={org.id}
                onClick={() => handleSelectOrganism(org)}
                className={`group text-left p-3.5 rounded-2xl border transition-all duration-150 flex flex-col justify-between relative overflow-hidden focus-visible:outline-2 focus-visible:outline-emerald-600 ${
                  isLoaded
                    ? 'bg-gradient-to-b from-emerald-50 to-teal-50/50 border-emerald-500 shadow-md ring-2 ring-emerald-500/30'
                    : 'bg-slate-50 hover:bg-white border-slate-200/90 hover:border-slate-300 hover:shadow-xs'
                }`}
              >
                {/* Glass Slide Visual Styling */}
                <div className="flex items-start justify-between gap-1 mb-2">
                  <span
                    className={`text-[10px] font-bold px-2 py-0.5 rounded-md ${
                      org.category === 'Menguntungkan'
                        ? 'bg-emerald-100 text-emerald-800'
                        : 'bg-rose-100 text-rose-800'
                    }`}
                  >
                    {org.category}
                  </span>
                  {isLoaded && (
                    <span className="text-[10px] font-bold text-emerald-700 bg-emerald-100/80 px-2 py-0.5 rounded-full flex items-center gap-1">
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-600" />
                      Aktif
                    </span>
                  )}
                </div>

                {/* Thumbnail Diagram */}
                <div className="w-full h-24 my-1 flex items-center justify-center p-2 rounded-xl bg-white/80 border border-slate-200/50 group-hover:scale-105 transition-transform duration-200">
                  <OrganismSvg type={org.svgType} className="w-full h-full" />
                </div>

                <div className="mt-2">
                  <div className="text-xs font-bold text-slate-900 truncate group-hover:text-emerald-700 transition-colors">
                    {org.name}
                  </div>
                  <div className="text-[11px] text-slate-500 italic truncate font-serif">
                    {org.scientificName}
                  </div>
                </div>

                <div className="mt-2 pt-2 border-t border-slate-200/60 text-[10px] text-slate-500 truncate">
                  {org.stainMethod.split(' (')[0]}
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Navigation Footer to Next Steps */}
      <div className="bg-slate-50 border border-slate-200/80 rounded-2xl p-5 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-600">
        <div className="flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
          <span>
            Sudah selesai mengamati preparat mikroskop? Lanjutkan untuk mencatat temuanmu ke lembar kerja.
          </span>
        </div>

        <button
          onClick={onGoToWorksheet}
          className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-6 py-3 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl transition shadow-xs focus-visible:outline-2 focus-visible:outline-emerald-600 active:scale-98"
        >
          <span>Lanjut ke Lembar Kerja Pengamatan</span>
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
