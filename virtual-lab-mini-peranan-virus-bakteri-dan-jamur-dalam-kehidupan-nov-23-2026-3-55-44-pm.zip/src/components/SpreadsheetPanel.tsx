import React, { useState, useRef } from 'react';
import {
  FileSpreadsheet,
  Download,
  Copy,
  Check,
  ExternalLink,
  CheckCircle2,
  Table,
  Trash2,
  Upload,
  AlertCircle,
} from 'lucide-react';
import { SpreadsheetScoreRow, StudentIdentity } from '../types';
import { SPREADSHEET_HEADERS } from '../utils/studentValidation';
import { buildCsvContent, buildTsvContent, parseCsvScoreRows } from '../utils/spreadsheetExport';
import { ConfirmDialog } from './ConfirmDialog';

interface SpreadsheetPanelProps {
  studentIdentity: StudentIdentity;
  scoreRecords: SpreadsheetScoreRow[];
  lastRecordedNotice: string | null;
  onDeleteRecord: (id: string) => void;
  onClearRecords: () => void;
  onImportRecords: (rows: SpreadsheetScoreRow[]) => void;
}

export const SpreadsheetPanel: React.FC<SpreadsheetPanelProps> = ({
  studentIdentity,
  scoreRecords,
  lastRecordedNotice,
  onDeleteRecord,
  onClearRecords,
  onImportRecords,
}) => {
  const [copiedTsv, setCopiedTsv] = useState<boolean>(false);
  const [panelNotice, setPanelNotice] = useState<string | null>(null);
  const [panelError, setPanelError] = useState<string | null>(null);
  const [pendingDeleteId, setPendingDeleteId] = useState<string | null>(null);
  const [showClearConfirm, setShowClearConfirm] = useState<boolean>(false);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const handleDownloadCsv = () => {
    if (scoreRecords.length === 0) {
      setPanelError('Belum ada data skor untuk diunduh. Kirim jawaban kuis terlebih dahulu.');
      return;
    }
    setPanelError(null);
    const csv = buildCsvContent(scoreRecords);
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    const safeClass = (studentIdentity.kelas || 'KelasX').replace(/[^a-zA-Z0-9_-]/g, '_');
    link.href = url;
    link.download = `Rekap_Skor_Kuis_Biologi_${safeClass}.csv`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
    setPanelNotice('File Spreadsheet (.csv) berhasil diunduh. Anda dapat membukanya langsung di Google Sheets atau Microsoft Excel.');
  };

  const handleCopyForSheets = async () => {
    if (scoreRecords.length === 0) {
      setPanelError('Belum ada data skor untuk disalin. Kirim jawaban kuis terlebih dahulu.');
      return;
    }
    setPanelError(null);
    const tsv = buildTsvContent(scoreRecords, true);
    try {
      await navigator.clipboard.writeText(tsv);
      setCopiedTsv(true);
      setPanelNotice('Tabel skor berhasil disalin! Buka Google Sheets lalu tekan Ctrl+V (Tempel) pada sel A1.');
      window.setTimeout(() => setCopiedTsv(false), 3000);
    } catch {
      setPanelError('Browser membatasi akses clipboard otomatis. Silakan gunakan tombol "Unduh Spreadsheet (.csv)".');
    }
  };

  const handleCsvFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    e.target.value = '';
    if (!file) return;

    setPanelError(null);
    setPanelNotice(null);
    try {
      const text = await file.text();
      const imported = parseCsvScoreRows(text);
      if (imported.length === 0) {
        setPanelError('File CSV tidak memuat baris data skor yang valid.');
        return;
      }
      onImportRecords(imported);
      setPanelNotice(`Berhasil menggabungkan ${imported.length} data siswa dari file "${file.name}".`);
    } catch {
      setPanelError('Gagal membaca file CSV. Pastikan format file sesuai hasil ekspor aplikasi ini.');
    }
  };

  const handleConfirmDeleteSingle = () => {
    if (pendingDeleteId) {
      onDeleteRecord(pendingDeleteId);
      setPendingDeleteId(null);
    }
  };

  const handleConfirmClearAll = () => {
    onClearRecords();
    setShowClearConfirm(false);
    setPanelNotice('Seluruh daftar rekap skor lokal telah dikosongkan.');
  };

  const pendingDeleteTarget = scoreRecords.find((r) => r.id === pendingDeleteId);

  return (
    <section
      aria-label="Rekap Skor dan Ekspor Spreadsheet Gratis"
      className="bg-white rounded-2xl p-5 sm:p-6 border border-emerald-200 shadow-xs space-y-5"
    >
      {/* Top Bar */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 pb-4 border-b border-slate-100">
        <div className="flex items-start gap-3">
          <div className="w-10 h-10 rounded-xl bg-emerald-100 text-emerald-700 flex items-center justify-center shrink-0">
            <FileSpreadsheet className="w-5 h-5" />
          </div>
          <div>
            <div className="flex flex-wrap items-center gap-2">
              <h3 className="text-sm sm:text-base font-bold text-slate-900">
                Rekap Skor Otomatis &amp; Ekspor Spreadsheet
              </h3>
              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-bold bg-emerald-100 text-emerald-800 border border-emerald-200">
                <CheckCircle2 className="w-3 h-3" />
                Gratis · Tanpa Login
              </span>
            </div>
            <p className="text-xs text-slate-500 mt-0.5">
              Saat tombol <strong>Kirim Jawaban Kuis</strong> ditekan, Nama ({studentIdentity.nama}), Kelas ({studentIdentity.kelas}), No. Absen ({studentIdentity.noAbsen}), Jumlah Benar, dan Jumlah Salah langsung tercatat &amp; siap diekspor ke Google Sheets/Excel (.csv).
            </p>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-wrap items-center gap-2 shrink-0">
          <button
            type="button"
            onClick={handleDownloadCsv}
            disabled={scoreRecords.length === 0}
            className="px-3.5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-xl transition flex items-center gap-1.5 shadow-xs disabled:opacity-50"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Unduh Spreadsheet (.csv)</span>
          </button>

          <button
            type="button"
            onClick={handleCopyForSheets}
            disabled={scoreRecords.length === 0}
            className="px-3 py-2 bg-white hover:bg-emerald-50 text-emerald-800 border border-emerald-300 text-xs font-semibold rounded-xl transition flex items-center gap-1.5 disabled:opacity-50"
          >
            {copiedTsv ? (
              <>
                <Check className="w-3.5 h-3.5 text-emerald-600" />
                <span>Tersalin!</span>
              </>
            ) : (
              <>
                <Copy className="w-3.5 h-3.5 text-emerald-600" />
                <span>Salin ke Google Sheets</span>
              </>
            )}
          </button>

          <a
            href="https://sheets.new"
            target="_blank"
            rel="noopener noreferrer"
            className="px-3 py-2 bg-slate-50 hover:bg-slate-100 text-slate-700 border border-slate-300 text-xs font-semibold rounded-xl transition inline-flex items-center gap-1.5"
          >
            <span>Buka Google Sheets</span>
            <ExternalLink className="w-3.5 h-3.5" />
          </a>

          <input
            ref={fileInputRef}
            type="file"
            accept=".csv,text/csv"
            onChange={handleCsvFileChange}
            className="hidden"
            aria-label="Impor file CSV rekap skor"
          />
          <button
            type="button"
            onClick={() => fileInputRef.current?.click()}
            className="px-3 py-2 bg-white hover:bg-slate-100 text-slate-700 border border-slate-300 text-xs font-semibold rounded-xl transition flex items-center gap-1.5"
            title="Gabungkan file .csv dari siswa lain"
          >
            <Upload className="w-3.5 h-3.5 text-slate-600" />
            <span>Gabung CSV</span>
          </button>
        </div>
      </div>

      {/* Notices */}
      {lastRecordedNotice && (
        <div
          role="status"
          className="p-3.5 bg-emerald-50 border border-emerald-300 text-emerald-900 text-xs rounded-xl flex items-start gap-2"
        >
          <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
          <div>
            <strong className="block font-bold">Skor Berhasil Dicatat ke Tabel Rekap!</strong>
            <span className="text-emerald-800">{lastRecordedNotice}</span>
          </div>
        </div>
      )}

      {panelNotice && (
        <div
          role="status"
          className="p-3 bg-emerald-50/70 border border-emerald-200 text-emerald-900 text-xs rounded-xl flex items-center gap-2"
        >
          <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
          <span>{panelNotice}</span>
        </div>
      )}

      {panelError && (
        <div
          role="alert"
          className="p-3 bg-rose-50 border border-rose-200 text-rose-800 text-xs rounded-xl flex items-center gap-2"
        >
          <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
          <span>{panelError}</span>
        </div>
      )}

      {/* Score Table */}
      <div className="border border-slate-200 rounded-xl overflow-hidden">
        <div className="px-4 py-2.5 bg-slate-100/80 border-b border-slate-200 flex flex-wrap items-center justify-between gap-2 text-xs">
          <div className="flex items-center gap-2 font-bold text-slate-700">
            <Table className="w-4 h-4 text-emerald-700" />
            <span>Pratinjau Tabel Spreadsheet ({scoreRecords.length} Catatan Siswa)</span>
          </div>
          {scoreRecords.length > 0 && (
            <button
              type="button"
              onClick={() => setShowClearConfirm(true)}
              className="text-[11px] font-semibold text-rose-600 hover:text-rose-700 hover:underline flex items-center gap-1"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>Kosongkan Tabel</span>
            </button>
          )}
        </div>

        <div className="overflow-x-auto max-h-64">
          <table className="w-full text-left text-[11px] border-collapse">
            <thead className="bg-emerald-900 text-white sticky top-0">
              <tr>
                {SPREADSHEET_HEADERS.map((col) => (
                  <th key={col} className="py-2 px-3 font-semibold whitespace-nowrap">
                    {col}
                  </th>
                ))}
                <th className="py-2 px-2 text-center font-semibold whitespace-nowrap">Aksi</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200 bg-white">
              {scoreRecords.length === 0 ? (
                <tr>
                  <td colSpan={9} className="py-5 px-3 text-center text-slate-400">
                    Belum ada catatan skor. Jawab 5 soal di bawah lalu klik &quot;Kirim Jawaban Kuis&quot; untuk mencatat skor otomatis.
                  </td>
                </tr>
              ) : (
                scoreRecords.map((row) => (
                  <tr key={row.id} className="hover:bg-emerald-50/40">
                    <td className="py-2 px-3 text-slate-600 whitespace-nowrap">{row.timestamp}</td>
                    <td className="py-2 px-3 font-semibold text-slate-900 whitespace-nowrap">{row.nama}</td>
                    <td className="py-2 px-3 text-slate-700 whitespace-nowrap">{row.kelas}</td>
                    <td className="py-2 px-3 text-slate-700 whitespace-nowrap">{row.noAbsen}</td>
                    <td className="py-2 px-3 font-bold text-emerald-700 whitespace-nowrap">{row.skor}</td>
                    <td className="py-2 px-3 font-semibold text-emerald-700 whitespace-nowrap">{row.benar}</td>
                    <td className="py-2 px-3 font-semibold text-rose-600 whitespace-nowrap">{row.salah}</td>
                    <td className="py-2 px-3 text-slate-700 whitespace-nowrap">{row.predikat}</td>
                    <td className="py-2 px-2 text-center">
                      <button
                        type="button"
                        onClick={() => setPendingDeleteId(row.id)}
                        className="p-1 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded transition"
                        title={`Hapus catatan ${row.nama}`}
                        aria-label={`Hapus catatan ${row.nama}`}
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Confirm Delete Single Row */}
      <ConfirmDialog
        isOpen={pendingDeleteId !== null}
        title="Hapus Catatan Skor Siswa?"
        description="Baris nilai siswa ini akan dihapus dari tabel rekap lokal."
        details={
          pendingDeleteTarget
            ? [
                `Nama: ${pendingDeleteTarget.nama} (${pendingDeleteTarget.kelas}, Absen ${pendingDeleteTarget.noAbsen})`,
                `Skor: ${pendingDeleteTarget.skor}/100 (Benar: ${pendingDeleteTarget.benar}, Salah: ${pendingDeleteTarget.salah})`,
              ]
            : undefined
        }
        confirmLabel="Ya, Hapus Baris"
        variant="danger"
        onConfirm={handleConfirmDeleteSingle}
        onCancel={() => setPendingDeleteId(null)}
      />

      {/* Confirm Clear All Rows */}
      <ConfirmDialog
        isOpen={showClearConfirm}
        title="Kosongkan Semua Catatan Skor?"
        description={`Seluruh ${scoreRecords.length} baris rekap skor yang tersimpan di browser ini akan dihapus. Pastikan Anda sudah mengunduh file .csv jika masih dibutuhkan.`}
        confirmLabel="Ya, Kosongkan Semua"
        variant="danger"
        onConfirm={handleConfirmClearAll}
        onCancel={() => setShowClearConfirm(false)}
      />
    </section>
  );
};
