import { OrganismGroup, QuizQuestion, WorksheetRow } from '../types';

export const ORGANISM_GROUPS: OrganismGroup[] = [
  {
    id: 'virus',
    title: 'Virus',
    subtitle: 'Partikel Aseluler & Parasit Intraseluler Obligat',
    badge: 'Skala 20 - 400 nm (Mikroskop Elektron)',
    description: 'Partikel aseluler (virion) yang hanya dapat bereplikasi di dalam sel inang hidup. Memiliki materi genetik (DNA atau RNA) yang diselubungi kapsid protein pelindung.',
    colorTheme: {
      primary: 'emerald',
      bg: 'bg-emerald-50/70',
      border: 'border-emerald-200',
      badgeBg: 'bg-emerald-100',
      badgeText: 'text-emerald-800',
      accent: 'text-emerald-600',
    },
    organisms: [
      {
        id: 'bakteriofag',
        name: 'Bakteriofag (Phage T4)',
        scientificName: 'Bacteriophage T4',
        category: 'Menguntungkan',
        peranan: 'Dimanfaatkan dalam penelitian rekayasa genetika dan terapi fag untuk membasmi bakteri patogen.',
        alasan: 'Bakteriofag secara spesifik menginfeksi dan melisiskan dinding bakteri tanpa merusak sel tubuh manusia.',
        description: 'Bakteriofag adalah virus pemakan bakteri. Dalam bioteknologi dan kedokteran modern, bakteriofag sangat berharga sebagai vektor pengantar gen, agen kloning DNA, serta terapi alternatif antibiotik alami (fagoterapi) untuk mengatasi infeksi bakteri resistan obat.',
        ciriKhas: 'Morfologi kompleks: kepala ikosahedral berisi materi genetik DNA untai ganda, leher kontraktil, lempeng dasar, dan serabut ekor panjang.',
        habitatAtauInang: 'Bakteri gram-negatif (misal Escherichia coli)',
        stainMethod: 'Negative Staining (Uranil Asetat / Asam Fosfotungstat)',
        slideTint: 'from-emerald-950 via-teal-900 to-slate-950',
        magnificationDesc: '150.000× (Transmission Electron Microscope / TEM)',
        structures: [
          { name: 'Kapsid Ikosahedral', description: 'Cangkang protein berbentuk polihedral 20 sisi yang melindungi materi genetik DNA di dalamnya.', xPercent: 50, yPercent: 28, pos3d: [0, 1.35, 0] },
          { name: 'DNA Untai Ganda', description: 'Materi genetik virus yang disuntikkan ke dalam sitoplasma sel bakteri inang.', xPercent: 50, yPercent: 36, pos3d: [0, 1.0, 0] },
          { name: 'Selubung Leher (Sheath)', description: 'Saluran silindris kontraktil yang menyuntikkan DNA menembus dinding sel bakteri.', xPercent: 50, yPercent: 62, pos3d: [0, -0.1, 0] },
          { name: 'Serabut Ekor (Tail Fibers)', description: 'Serabut fleksibel yang mengenali reseptor spesifik pada permukaan dinding luar bakteri.', xPercent: 28, yPercent: 84, pos3d: [-0.65, -1.1, 0.4] },
        ],
        svgType: 'bakteriofag'
      },
      {
        id: 'influenza',
        name: 'Virus Influenza',
        scientificName: 'Influenza virus (Tipe A, B, C)',
        category: 'Merugikan',
        peranan: 'Menyebabkan penyakit influenza (flu) akut yang menginfeksi saluran pernapasan manusia dan hewan.',
        alasan: 'Menyebabkan demam tinggi, batuk berlendir, pilek, sakit kepala hebat, dan nyeri otot melalui droplet udara.',
        description: 'Virus RNA beruntai tunggal yang memiliki membran lipid ganda (envelope) dengan tonjolan glikoprotein hemaglutinin (HA) dan neuraminidase (NA). Sering bermutasi antigenic drift & shift sehingga memicu epidemi musiman berulang.',
        ciriKhas: 'Bentuk bola sferis berdiameter 80-120 nm dengan duri-duri glikoprotein HA dan NA menyerupai landak.',
        habitatAtauInang: 'Sel epitel bersilia pada saluran pernapasan manusia dan unggas',
        stainMethod: 'Cryo-Electron Microscopy & Imunofluoresensi Antibodi',
        slideTint: 'from-rose-950 via-red-900 to-slate-950',
        magnificationDesc: '200.000× (Cryo-TEM)',
        structures: [
          { name: 'Spike Hemaglutinin (HA)', description: 'Glikoprotein berbentuk duri yang menempel pada reseptor asam sialat sel epitel inang.', xPercent: 50, yPercent: 12, pos3d: [0, 1.75, 0] },
          { name: 'Spike Neuraminidase (NA)', description: 'Enzim yang memotong asam sialat untuk melepaskan virion baru saat pertunasan.', xPercent: 84, yPercent: 35, pos3d: [1.6, 0.6, 0] },
          { name: 'Selubung Lipid (Envelope)', description: 'Lapisan membran ganda lipid yang diperoleh virus dari membran sel inang.', xPercent: 50, yPercent: 27, pos3d: [-1.2, 0.6, 0.3] },
          { name: 'Segmen RNA & Nukleoprotein', description: '8 segmen RNA untai tunggal (-) yang membawa instruksi genetik virus influenza.', xPercent: 50, yPercent: 52, pos3d: [0, 0, 0.2] },
        ],
        svgType: 'influenza'
      },
      {
        id: 'dengue',
        name: 'Virus Dengue (DENV)',
        scientificName: 'Dengue virus (DENV 1-4)',
        category: 'Merugikan',
        peranan: 'Menyebabkan demam berdarah dengue (DBD) dan syok hemoragik yang berbahaya bagi keselamatan jiwa.',
        alasan: 'Merusak endotel pembuluh darah menyebabkan kebocoran plasma masif dan penurunan jumlah trombosit secara drastis.',
        description: 'Arbovirus dari famili Flaviviridae yang disebarkan melalui perantara vektor nyamuk Aedes aegypti dan Aedes albopictus. Memiliki 4 serotipe (DENV 1-4), di mana infeksi sekunder dapat memicu badai sitokin dan perdarahan internal.',
        ciriKhas: 'Bentuk ikosahedral sangat rapat berdiameter 50 nm dengan permukaan herringbone dimer protein E yang simetris.',
        habitatAtauInang: 'Kelenjar ludah nyamuk Aedes & monosit/makrofag darah manusia',
        stainMethod: 'Kriomikroskopi Elektron & Pewarnaan Perak PCR',
        slideTint: 'from-rose-950 via-pink-900 to-slate-950',
        magnificationDesc: '250.000× (Cryo-EM)',
        structures: [
          { name: 'Dimer Glikoprotein E', description: 'Protein permukaan penentu serotipe yang memicu pengikatan dan fusi membran virus.', xPercent: 50, yPercent: 22, pos3d: [0.3, 1.35, 0.2] },
          { name: 'Membran Lipid M', description: 'Membran pelindung yang menyelubungi partikel sebelum matang.', xPercent: 78, yPercent: 50, pos3d: [-1.0, -0.5, 0.5] },
          { name: 'Kapsid Protein C', description: 'Struktur ikosahedral dalam yang mengemas molekul (+)ssRNA genom dengue.', xPercent: 50, yPercent: 50, pos3d: [0, 0, 0] },
        ],
        svgType: 'dengue'
      }
    ]
  },
  {
    id: 'bakteri',
    title: 'Bakteri',
    subtitle: 'Organisme Prokariotik Uniseluler Tanpa Membran Inti',
    badge: 'Skala 0.5 - 5.0 µm (Mikroskop Cahaya & Imersi)',
    description: 'Mikroorganisme bersel tunggal tanpa membran inti (prokariotik), memiliki dinding sel dari peptidoglikan, dan dapat hidup bebas di berbagai habitat (tanah, air, udara, hingga tubuh makhluk hidup).',
    colorTheme: {
      primary: 'teal',
      bg: 'bg-teal-50/70',
      border: 'border-teal-200',
      badgeBg: 'bg-teal-100',
      badgeText: 'text-teal-800',
      accent: 'text-teal-600',
    },
    organisms: [
      {
        id: 'yoghurt_bacteria',
        name: 'Lactobacillus & Streptococcus',
        scientificName: 'Lactobacillus bulgaricus & Streptococcus thermophilus',
        category: 'Menguntungkan',
        peranan: 'Pembuatan produk olahan susu yoghurt melalui proses fermentasi asam laktat.',
        alasan: 'Mengubah laktosa menjadi asam laktat yang mengendapkan kasein susu sehingga bertekstur kental, bercita rasa asam segar, dan menyehatkan usus.',
        description: 'Bakteri asam laktat (BAL) yang bekerja secara simbiosis mutualistik kooperatif. Streptococcus thermophilus memproduksi asam format dan CO2 yang menstimulasi Lactobacillus bulgaricus untuk menghasilkan asam laktat dan aroma khas asetaldehida.',
        ciriKhas: 'Lactobacillus berbentuk basil (batang gram-positif), sedangkan Streptococcus berbentuk kokus (bulat berderet seperti kalung rantai).',
        habitatAtauInang: 'Media susu hewani dan saluran pencernaan manusia (mikrobiota probiotik)',
        stainMethod: 'Pewarnaan Gram (Gram Positif: Mengikat Kristal Violet, Berwarna Ungu-Biru)',
        slideTint: 'from-teal-950 via-cyan-900 to-slate-950',
        magnificationDesc: '1000× (Lensa Objektif 100× + Minyak Imersi)',
        structures: [
          { name: 'Lactobacillus (Basil)', description: 'Sel bakteri berbentuk batang panjang lurus, penghasil utama asam laktat.', xPercent: 38, yPercent: 44, pos3d: [-0.7, 0.35, 0] },
          { name: 'Streptococcus (Kokus Rantai)', description: 'Sel bulat yang tersusun dalam untaian rantai, penurun pH susu awal.', xPercent: 36, yPercent: 68, pos3d: [-0.3, -1.2, 0.5] },
          { name: 'Dinding Peptidoglikan Tebal', description: 'Lapisan peptidoglikan khas bakteri Gram-positif yang mengikat kuat kristal violet.', xPercent: 65, yPercent: 55, pos3d: [0.6, -0.35, 0.3] },
        ],
        svgType: 'lactobacillus'
      },
      {
        id: 'rhizobium',
        name: 'Bakteri Rhizobium',
        scientificName: 'Rhizobium leguminosarum',
        category: 'Menguntungkan',
        peranan: 'Membantu fiksasi gas nitrogen bebas (N2) di udara menjadi amonia di bintil akar tanaman legum.',
        alasan: 'Bersimbiosis mutualisme dengan tanaman suku polong-polongan (Fabaceae), menyediakan pasokan nitrogen alami untuk kesuburan tanaman.',
        description: 'Rhizobium memproduksi kompleks enzim nitrogenase yang mampu memecah ikatan rangkap tiga gas N2 di atmosfer menjadi senyawa amonium yang siap diserap tanaman. Tanaman inang membalas dengan menyuplai karbohidrat hasil fotosintesis dan leghemoglobin untuk menjaga kondisi mikroaerobik.',
        ciriKhas: 'Bakteri batang gram-negatif yang berdiferensiasi menjadi bakteroid polimorfik di dalam jaringan sel korteks bintil akar.',
        habitatAtauInang: 'Bintil akar tanaman legum (kedelai, kacang tanah, alfalfa, buncis)',
        stainMethod: 'Pewarnaan Smear Karbol Fuksin & Metilen Biru pada Sayatan Bintil Akar',
        slideTint: 'from-emerald-950 via-green-900 to-slate-950',
        magnificationDesc: '1000× (Lensa Objektif 100× Imersi)',
        structures: [
          { name: 'Nodul / Bintil Akar', description: 'Pembengkakan jaringan korteks akar akibat respons infeksi menguntungkan oleh Rhizobium.', xPercent: 30, yPercent: 41, pos3d: [0.7, 0.3, 0.2] },
          { name: 'Bakteroid Rhizobium', description: 'Bentuk pleomorfik sel bakteri yang aktif mensintesis enzim nitrogenase.', xPercent: 68, yPercent: 55, pos3d: [0.85, 0.45, 0.4] },
          { name: 'Jaringan Pembuluh Akar', description: 'Saluran xilem dan floem pengangkut nitrogen hasil fiksasi menuju seluruh organ tanaman.', xPercent: 50, yPercent: 20, pos3d: [0, 1.3, 0] },
        ],
        svgType: 'rhizobium'
      },
      {
        id: 'salmonella',
        name: 'Salmonella enterica',
        scientificName: 'Salmonella enterica subsp. enterica',
        category: 'Merugikan',
        peranan: 'Penyebab penyakit bawaan pangan (foodborne disease), demam tifoid, dan keracunan makanan akut.',
        alasan: 'Menginfeksi lapisan mukosa usus halus lewat makanan/minuman tercemar feses, memicu diare berat, kram usus, muntah, dan demam tinggi.',
        description: 'Bakteri patogen enterik yang dapat bertahan hidup di saluran pencernaan hewan ternak dan unggas. Bila tertelan melalui telur setengah matang atau daging mentah, Salmonella menggunakan sistem sekresi tipe III (T3SS) untuk menginvasi enterosit usus dan makrofag manusia.',
        ciriKhas: 'Bakteri batang lurus (basil) gram-negatif fakultatif anaerob, memiliki flagela peritrik (cambuk di sekujur permukaan sel) untuk berenang lincah.',
        habitatAtauInang: 'Saluran pencernaan unggas, sapi, babi, dan usus manusia',
        stainMethod: 'Pewarnaan Gram (Gram Negatif: Merah Safranin) & Pewarnaan Flagela Leifson',
        slideTint: 'from-amber-950 via-yellow-900 to-slate-950',
        magnificationDesc: '1000× (Minyak Imersi / Kontras Fase)',
        structures: [
          { name: 'Flagela Peritrik', description: 'Filamen cambuk protein flagelin yang tersebar di sekeliling dinding sel untuk motilitas cepat.', xPercent: 20, yPercent: 35, pos3d: [-1.2, 0.6, 0.4] },
          { name: 'Badan Sel Basil', description: 'Sel silindris berisi materi genetik nukleoid melingkar tanpa membran pelindung.', xPercent: 50, yPercent: 50, pos3d: [0, 0, 0] },
          { name: 'Membran Luar Lipopolisakarida', description: 'Endotoksin lipid A yang memicu respons inflamasi dan demam pada inang.', xPercent: 68, yPercent: 44, pos3d: [0.75, 0.4, 0.2] },
        ],
        svgType: 'salmonella'
      }
    ]
  },
  {
    id: 'jamur',
    title: 'Jamur (Fungi)',
    subtitle: 'Organisme Eukariotik Heterotrof Berdinding Sel Kitin',
    badge: 'Skala 5 µm - Multiseluler (Mikroskop Cahaya)',
    description: 'Kelompok organisme eukariotik yang tidak berklorofil, memiliki dinding sel dari zat kitin, dan memperoleh nutrisi secara absorptif heterotrof (saprofit, parasit, atau simbion).',
    colorTheme: {
      primary: 'sky',
      bg: 'bg-sky-50/70',
      border: 'border-sky-200',
      badgeBg: 'bg-sky-100',
      badgeText: 'text-sky-800',
      accent: 'text-sky-600',
    },
    organisms: [
      {
        id: 'rhizopus',
        name: 'Jamur Tempe (Rhizopus)',
        scientificName: 'Rhizopus oligosporus / Rhizopus oryzae',
        category: 'Menguntungkan',
        peranan: 'Fermentasi biji kedelai rebus menjadi tempe yang kaya protein dan bergizi tinggi.',
        alasan: 'Miselium jamur menyatukan butir kedelai menjadi padatan kompak putih, serta memproduksi enzim protease pelisis protein kompleks menjadi asam amino.',
        description: 'Kapang Zygomycota yang tumbuh cepat pada kedelai. Hifa hialinnya yang lebat menjalin biji kedelai menjadi blok padat putih bersih. Jamur ini juga mendegradasi fitat antinutrisi sehingga mineral kalsium dan zat besi lebih mudah diserap tubuh manusia.',
        ciriKhas: 'Hifa tanpa sekat (senositik/koenositik), memiliki rizoid mirip akar, stolon merayap, serta sporangiofor tegak berujung bola sporangium berisi spora.',
        habitatAtauInang: 'Biji kedelai terfermentasi dan substrat nabati kaya karbohidrat',
        stainMethod: 'Preparat Basah Laktofenol Cotton Blue (LPCB) / Pewarnaan Tinta Parker Biru',
        slideTint: 'from-sky-950 via-blue-900 to-slate-950',
        magnificationDesc: '400× (Lensa Objektif 40× / Mikroskop Senyawa)',
        structures: [
          { name: 'Sporangium Bulat', description: 'Kotak spora berdinding tipis yang menampung ratusan sporangiospora aseksual.', xPercent: 60, yPercent: 24, pos3d: [0.3, 1.2, -0.2] },
          { name: 'Sporangiofor Tegak', description: 'Tangkai hifa khusus yang menjulang tinggi mengangkat sporangium ke udara.', xPercent: 44, yPercent: 48, pos3d: [0.3, 0.0, -0.2] },
          { name: 'Rizoid Mirap Akar', description: 'Hifa bercabang mirip akar penembus biji kedelai untuk menyerap nutrisi.', xPercent: 44, yPercent: 88, pos3d: [-0.3, -1.5, 0.1] },
          { name: 'Kedelai Tempe', description: 'Substrat kedelai yang diselimuti miselium putih kompak berprotein tinggi.', xPercent: 70, yPercent: 82, pos3d: [0.6, -1.8, 0.2] },
        ],
        svgType: 'rhizopus'
      },
      {
        id: 'saccharomyces',
        name: 'Ragi Roti (Saccharomyces cerevisiae)',
        scientificName: 'Saccharomyces cerevisiae',
        category: 'Menguntungkan',
        peranan: 'Pembuatan adonan roti mengembang empuk dan fermentasi tape/minuman bioteknologi.',
        alasan: 'Melakukan fermentasi alkoholik secara anaerob, melepaskan gas karbondioksida (CO2) yang merongga dan mengembangkan adonan roti.',
        description: 'Jamur uniseluler (khamir) dari divisi Ascomycota. Merupakan mikroorganisme model biologi seluler terkemuka di dunia. Selama pembuatan roti, gas CO2 terperangkap dalam jala gluten tepung, membuat tekstur roti berserat halus dan empuk saat dipanggang.',
        ciriKhas: 'Sel mikroskopis bulat-oval uniseluler berukuran 5-10 µm yang bereproduksi vegetatif secara pertunasan (budding).',
        habitatAtauInang: 'Substrat berkadar glukosa tinggi (adonan tepung, buah matang, nektar bunga)',
        stainMethod: 'Preparat Basah dengan Larutan Lugol / Yodium Encer',
        slideTint: 'from-amber-950 via-orange-900 to-slate-950',
        magnificationDesc: '400× s.d. 1000× (Mikroskop Cahaya)',
        structures: [
          { name: 'Sel Induk Khamir', description: 'Sel uniseluler utama yang menyimpan cadangan glikogen dan vakuola besar.', xPercent: 46, yPercent: 54, pos3d: [0, 0, 0] },
          { name: 'Tunas Baru (Bud)', description: 'Tonjolan sel anakan hasil pembelahan mitosis aseksual yang sedang tumbuh.', xPercent: 64, yPercent: 41, pos3d: [1.2, 0.7, 0.3] },
          { name: 'Gelembung Gas CO2', description: 'Karbondioksida hasil fermentasi alkohol yang mengembangkan adonan tepung.', xPercent: 20, yPercent: 34, pos3d: [-0.9, 1.1, 0.5] },
        ],
        svgType: 'saccharomyces'
      },
      {
        id: 'trichophyton',
        name: 'Trichophyton (Jamur Kulit)',
        scientificName: 'Trichophyton rubrum / mentagrophytes',
        category: 'Merugikan',
        peranan: 'Penyebab infeksi jamur dermatofitosis pada kulit manusia (kadas, kurap, dan kutu air/tinea pedis).',
        alasan: 'Menghasilkan enzim keratinase yang melisiskan dan memakan protein keratin pada lapisan tanduk kulit, rambut, dan kuku.',
        description: 'Jamur dermatofit parasit yang mengkolonisasi jaringan berkeratin tubuh manusia. Berkembang sangat cepat di lingkungan hangat, berkeringat, dan lembap. Menyebabkan peradangan kulit melingkar (ringworm) dengan batas eritematosa yang gatal sekali.',
        ciriKhas: 'Hifa bersekat hialin bercabang dengan mikrokonidia berbentuk tetesan air (tear-shaped) serta makrokonidia silindris berdinding tipis.',
        habitatAtauInang: 'Stratum korneum kulit manusia, folikel rambut, dan lempeng kuku',
        stainMethod: 'Pemeriksaan Kerokan Kulit dengan KOH 10-20% & Pewarnaan Calcofluor White',
        slideTint: 'from-rose-950 via-purple-900 to-slate-950',
        magnificationDesc: '400× (Mikroskop Cahaya)',
        structures: [
          { name: 'Makrokonidia Berdinding Tipis', description: 'Spora reproduksi multiseluler berbentuk silinder memanjang seperti cerutu.', xPercent: 74, yPercent: 33, pos3d: [1.0, 0.8, 0.3] },
          { name: 'Hifa Bersekat (Septat)', description: 'Filamen hifa dengan sekat melintang (septa) yang menembus lapisan keratin kulit.', xPercent: 48, yPercent: 58, pos3d: [0.0, -0.4, 0.0] },
          { name: 'Mikrokonidia Tetesan Air', description: 'Spora uniseluler kecil bulat piriform penular infeksi pada pori kulit.', xPercent: 36, yPercent: 52, pos3d: [-0.8, 0.3, 0.2] },
        ],
        svgType: 'trichophyton'
      },
      {
        id: 'aspergillus',
        name: 'Aspergillus flavus',
        scientificName: 'Aspergillus flavus',
        category: 'Merugikan',
        peranan: 'Penghasil racun mikotoksin aflatoksin berbahaya yang mencemari bahan pangan biji-bijian.',
        alasan: 'Aflatoksin B1 yang diproduksinya sangat hepatotoksik dan karsinogenik kuat (pemicu kanker hati) serta tahan panas proses memasak biasa.',
        description: 'Kapang saprofit yang kerap mencemari kacang tanah, jagung, beras, dan rempah yang disimpan di gudang lembap. Konsumsi pangan yang terkontaminasi aflatoksin dapat memicu kegagalan organ hati akut hingga kanker hepatoseluler karsinoma.',
        ciriKhas: 'Konidiofor tidak bersekat dengan vesikel bulat di ujungnya yang dikelilingi fialid dan rantai panjang konidia berwarna hijau kekuningan.',
        habitatAtauInang: 'Kacang tanah, jagung, sereal lembap, dan tanah pertanian',
        stainMethod: 'Preparat Laktofenol Cotton Blue (LPCB) & Deteksi Sinar UV Panjang Gelombang 365 nm',
        slideTint: 'from-yellow-950 via-lime-900 to-slate-950',
        magnificationDesc: '400× (Lensa Objektif 40×)',
        structures: [
          { name: 'Rantai Konidiospora', description: 'Untaian spora aseksual berwarna hijau kekuningan yang mudah terbang mencemari makanan.', xPercent: 50, yPercent: 12, pos3d: [0, 1.45, 0] },
          { name: 'Vesikel Bulat', description: 'Kepala pembengkakan di ujung konidiofor tempat menempelnya sel fialid pembuat spora.', xPercent: 50, yPercent: 42, pos3d: [0, 0.4, 0] },
          { name: 'Konidiofor / Tangkai Hifa', description: 'Tangkai hifa tegak berdinding tebal dan kasar penyangga kepala pembengkakan.', xPercent: 50, yPercent: 70, pos3d: [0, -1.0, 0] },
          { name: 'Zat Racun Aflatoksin', description: 'Metabolit sekunder mikotoksin yang disekresikan jamur ke dalam butir kacang.', xPercent: 76, yPercent: 68, pos3d: [0.7, -0.6, 0.2] },
        ],
        svgType: 'aspergillus'
      }
    ]
  }
];

export const INITIAL_WORKSHEET_ROWS: WorksheetRow[] = [
  {
    id: 'row-1',
    namaOrganisme: '',
    peranan: '',
    kategori: '',
    alasanSingkat: '',
  },
  {
    id: 'row-2',
    namaOrganisme: '',
    peranan: '',
    kategori: '',
    alasanSingkat: '',
  },
  {
    id: 'row-3',
    namaOrganisme: '',
    peranan: '',
    kategori: '',
    alasanSingkat: '',
  },
  {
    id: 'row-4',
    namaOrganisme: '',
    peranan: '',
    kategori: '',
    alasanSingkat: '',
  }
];

export const SAMPLE_WORKSHEET_ROWS: WorksheetRow[] = [
  {
    id: 'sample-1',
    namaOrganisme: 'Bakteriofag',
    peranan: 'Dimanfaatkan dalam penelitian genetika dan terapi fag pembasmi bakteri patogen',
    kategori: 'Menguntungkan',
    alasanSingkat: 'Dapat melisiskan bakteri patogen secara spesifik tanpa merusak sel tubuh manusia'
  },
  {
    id: 'sample-2',
    namaOrganisme: 'Lactobacillus & Streptococcus',
    peranan: 'Pembuatan produk olahan susu (yoghurt)',
    kategori: 'Menguntungkan',
    alasanSingkat: 'Mengubah laktosa menjadi asam laktat sehingga susu mengental dan bercita rasa asam segar'
  },
  {
    id: 'sample-3',
    namaOrganisme: 'Salmonella enterica',
    peranan: 'Penyebab penyakit bawaan pangan (foodborne disease) dan tipes',
    kategori: 'Merugikan',
    alasanSingkat: 'Menghasilkan racun dan menginfeksi usus halus hingga memicu diare dan demam tinggi'
  },
  {
    id: 'sample-4',
    namaOrganisme: 'Rhizopus oligosporus',
    peranan: 'Fermentasi kedelai dalam pembuatan tempe',
    kategori: 'Menguntungkan',
    alasanSingkat: 'Hifa putihnya menyatukan kedelai dan enzim protease mencerna protein menjadi mudah diserap'
  },
  {
    id: 'sample-5',
    namaOrganisme: 'Aspergillus flavus',
    peranan: 'Menghasilkan racun aflatoksin pada kacang dan jagung lembap',
    kategori: 'Merugikan',
    alasanSingkat: 'Aflatoksin bersifat karsinogenik yang dapat memicu kanker hati dan kerusakan organ'
  }
];

export const QUIZ_QUESTIONS: QuizQuestion[] = [
  {
    id: 1,
    topic: 'Virus',
    question: 'Organisme aseluler berikut yang memiliki peranan menguntungkan dalam dunia penelitian bioteknologi dan terapi medis karena kemampuannya menginfeksi bakteri patogen adalah...',
    options: [
      'Virus Influenza',
      'Virus Dengue',
      'Bakteriofag',
      'Tobacco Mosaic Virus'
    ],
    correctIndex: 2,
    explanation: 'Bakteriofag (fag) adalah virus yang secara khusus menginfeksi bakteri. Virus ini dimanfaatkan secara luas dalam penelitian rekayasa genetika sebagai vektor kloning gen dan dalam terapi fag (fagoterapi) untuk membasmi bakteri yang telah resistan terhadap antibiotik.'
  },
  {
    id: 2,
    topic: 'Bakteri',
    question: 'Dalam industri bioteknologi pangan konvensional, kombinasi bakteri Lactobacillus bulgaricus dan Streptococcus thermophilus dimanfaatkan untuk pembuatan...',
    options: [
      'Kecap manis',
      'Yoghurt',
      'Nata de coco',
      'Antibiotik penisilin'
    ],
    correctIndex: 1,
    explanation: 'Lactobacillus bulgaricus dan Streptococcus thermophilus adalah bakteri asam laktat (BAL) yang bekerja sama memfermentasi gula laktosa pada susu menjadi asam laktat, menghasilkan koagulasi protein susu dengan tekstur kental dan rasa khas yoghurt.'
  },
  {
    id: 3,
    topic: 'Bakteri',
    question: 'Bakteri Rhizobium leguminosarum memiliki peranan yang sangat menguntungkan di bidang pertanian karena mampu...',
    options: [
      'Menghasilkan toksin pembasmi hama tikus',
      'Membantu fiksasi gas nitrogen bebas di bintil akar tanaman legum',
      'Mempercepat pembusukan buah saat pascapanen',
      'Mengubah amonia langsung menjadi gas ozon di udara'
    ],
    correctIndex: 1,
    explanation: 'Rhizobium bersimbiosis mutualisme dengan tanaman polong-polongan (Leguminosae) membentuk bintil akar. Bakteri ini memiliki enzim nitrogenase yang mampu memfiksasi (mengikat) gas nitrogen (N2) dari atmosfer menjadi amonia sehingga menyuburkan tanah pertanian secara alami.'
  },
  {
    id: 4,
    topic: 'Jamur',
    question: 'Jamur Saccharomyces cerevisiae sangat penting dalam kehidupan sehari-hari, terutama dalam pembuatan roti, karena proses fermentasinya menghasilkan...',
    options: [
      'Gas oksigen yang mensterilkan tepung',
      'Aflatoksin yang membunuh bakteri pembusuk',
      'Gas karbondioksida (CO2) yang membuat adonan mengembang berpori empuk',
      'Zat kitin yang mengeraskan kulit roti luar'
    ],
    correctIndex: 2,
    explanation: 'Saccharomyces cerevisiae (ragi khamir) melakukan fermentasi alkohol anaerob terhadap gula dalam adonan tepung. Pelepasan gelembung gas karbon dioksida (CO2) terperangkap dalam jaring gluten sehingga membuat adonan roti mengembang empuk saat dipanggang.'
  },
  {
    id: 5,
    topic: 'Jamur',
    question: 'Bahan pangan seperti kacang tanah dan jagung yang disimpan dalam kondisi lembap dapat ditumbuhi jamur berbahaya Aspergillus flavus. Jamur ini digolongkan merugikan karena menghasilkan racun...',
    options: [
      'Aflatoksin yang bersifat karsinogenik (pemicu kanker)',
      'Penisilin yang merusak sel darah merah',
      'Endotoksin peptida pelisis dinding lambung',
      'Asam laktat yang merusak email gigi'
    ],
    correctIndex: 0,
    explanation: 'Aspergillus flavus menghasilkan senyawa metabolit sekunder berbahaya bernama aflatoksin (terutama Aflatoksin B1). Aflatoksin bersifat hepatotoksik dan karsinogenik kuat yang dapat memicu kanker hati dan kerusakan fungsi organ pada manusia dan hewan.'
  }
];
