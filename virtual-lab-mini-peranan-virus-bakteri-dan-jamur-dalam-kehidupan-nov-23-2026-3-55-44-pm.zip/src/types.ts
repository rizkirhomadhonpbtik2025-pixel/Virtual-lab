export type ActiveTab = 'beranda' | 'pengamatan' | 'lembarkerja' | 'kuis';

export type OrganismCategory = 'Menguntungkan' | 'Merugikan';

export interface OrganismStructure {
  name: string;
  description: string;
  xPercent: number; // percentage from left
  yPercent: number; // percentage from top
  pos3d?: [number, number, number]; // 3D local coordinate in model space
}

export interface OrganismDetail {
  id: string;
  name: string;
  scientificName: string;
  category: OrganismCategory;
  peranan: string;
  alasan: string;
  description: string;
  ciriKhas: string;
  habitatAtauInang: string;
  stainMethod: string;
  slideTint: string;
  magnificationDesc: string;
  structures: OrganismStructure[];
  svgType: 'bakteriofag' | 'influenza' | 'dengue' | 'lactobacillus' | 'rhizobium' | 'salmonella' | 'rhizopus' | 'saccharomyces' | 'trichophyton' | 'aspergillus';
}

export interface OrganismGroup {
  id: 'virus' | 'bakteri' | 'jamur';
  title: string;
  subtitle: string;
  badge: string;
  description: string;
  colorTheme: {
    primary: string;
    bg: string;
    border: string;
    badgeBg: string;
    badgeText: string;
    accent: string;
  };
  organisms: OrganismDetail[];
}

export interface WorksheetRow {
  id: string;
  namaOrganisme: string;
  peranan: string;
  kategori: OrganismCategory | '';
  alasanSingkat: string;
}

export interface QuizQuestion {
  id: number;
  question: string;
  options: string[];
  correctIndex: number;
  explanation: string;
  topic: 'Virus' | 'Bakteri' | 'Jamur';
}

export interface StudentIdentity {
  nama: string;
  kelas: string;
  noAbsen: string;
}

export interface SpreadsheetScoreRow {
  id: string;
  timestamp: string;
  nama: string;
  kelas: string;
  noAbsen: string;
  skor: number;
  benar: number;
  salah: number;
  predikat: string;
}

