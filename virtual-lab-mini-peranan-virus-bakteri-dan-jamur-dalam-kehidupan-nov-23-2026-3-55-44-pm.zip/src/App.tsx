import React, { useState, useCallback } from 'react';
import { Header } from './components/Header';
import { Beranda } from './components/Beranda';
import { MejaPengamatan } from './components/MejaPengamatan';
import { LembarKerja } from './components/LembarKerja';
import { Kuis } from './components/Kuis';
import { IdentitasSiswa } from './components/IdentitasSiswa';
import {
  ActiveTab,
  WorksheetRow,
  OrganismDetail,
  StudentIdentity,
  SpreadsheetScoreRow,
} from './types';
import { INITIAL_WORKSHEET_ROWS } from './data/biologyData';
import { countCompletedRows } from './utils/quizLogic';
import { Microscope } from 'lucide-react';

const STUDENT_IDENTITY_STORAGE_KEY = 'vlab_bioperan_student_identity';
const SCORE_RECORDS_STORAGE_KEY = 'vlab_bioperan_score_records';

function loadStoredIdentity(): StudentIdentity {
  try {
    const raw = window.localStorage.getItem(STUDENT_IDENTITY_STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      return {
        nama: typeof parsed.nama === 'string' ? parsed.nama : '',
        kelas: typeof parsed.kelas === 'string' ? parsed.kelas : '',
        noAbsen: typeof parsed.noAbsen === 'string' ? parsed.noAbsen : '',
      };
    }
  } catch {
    // ignore storage errors
  }
  return { nama: '', kelas: '', noAbsen: '' };
}

function loadStoredScoreRecords(): SpreadsheetScoreRow[] {
  try {
    const raw = window.localStorage.getItem(SCORE_RECORDS_STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed)) {
        return parsed.filter(
          (item): item is SpreadsheetScoreRow =>
            Boolean(item && typeof item.id === 'string' && typeof item.nama === 'string')
        );
      }
    }
  } catch {
    // ignore storage errors
  }
  return [];
}

function saveScoreRecords(records: SpreadsheetScoreRow[]) {
  try {
    window.localStorage.setItem(SCORE_RECORDS_STORAGE_KEY, JSON.stringify(records));
  } catch {
    // ignore storage errors
  }
}

export default function App() {
  const isAutostart =
    typeof window !== 'undefined' &&
    new URLSearchParams(window.location.search).get('autostart') === '1';

  const [studentIdentity, setStudentIdentity] = useState<StudentIdentity>(() => {
    const stored = loadStoredIdentity();
    if (isAutostart && !stored.nama) {
      return { nama: 'Siswa Demo', kelas: 'X-1', noAbsen: '1' };
    }
    return stored;
  });

  // Always show Student Identity screen before entering Beranda unless ?autostart=1
  const [hasEnteredLab, setHasEnteredLab] = useState<boolean>(isAutostart);
  const [activeTab, setActiveTab] = useState<ActiveTab>('beranda');
  const [worksheetRows, setWorksheetRows] = useState<WorksheetRow[]>(INITIAL_WORKSHEET_ROWS);
  const [quizSubmitted, setQuizSubmitted] = useState<boolean>(false);
  const [scoreRecords, setScoreRecords] = useState<SpreadsheetScoreRow[]>(() =>
    loadStoredScoreRecords()
  );

  const handleRecordScore = useCallback((record: SpreadsheetScoreRow) => {
    setScoreRecords((prev) => {
      const updated = [...prev, record];
      saveScoreRecords(updated);
      return updated;
    });
  }, []);

  const handleDeleteScoreRecord = useCallback((id: string) => {
    setScoreRecords((prev) => {
      const updated = prev.filter((row) => row.id !== id);
      saveScoreRecords(updated);
      return updated;
    });
  }, []);

  const handleClearScoreRecords = useCallback(() => {
    setScoreRecords([]);
    saveScoreRecords([]);
  }, []);

  const handleImportScoreRecords = useCallback((imported: SpreadsheetScoreRow[]) => {
    setScoreRecords((prev) => {
      const updated = [...prev, ...imported];
      saveScoreRecords(updated);
      return updated;
    });
  }, []);

  const handleUpdateIdentity = (updated: StudentIdentity) => {
    setStudentIdentity(updated);
    try {
      window.localStorage.setItem(STUDENT_IDENTITY_STORAGE_KEY, JSON.stringify(updated));
    } catch {
      // ignore
    }
  };

  const handleSubmitIdentityGate = (identity: StudentIdentity) => {
    handleUpdateIdentity(identity);
    setHasEnteredLab(true);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Handler to copy viewed organism from Meja Pengamatan straight into the worksheet
  const handleAddOrganismToWorksheet = (organism: OrganismDetail) => {
    setWorksheetRows((prevRows) => {
      const emptyRowIndex = prevRows.findIndex(
        (r) => !r.namaOrganisme.trim() && !r.peranan.trim()
      );

      const newRowData: WorksheetRow = {
        id: emptyRowIndex !== -1 ? prevRows[emptyRowIndex].id : `row-${Date.now()}`,
        namaOrganisme: organism.name,
        peranan: organism.peranan,
        kategori: organism.category,
        alasanSingkat: organism.alasan,
      };

      if (emptyRowIndex !== -1) {
        const updated = [...prevRows];
        updated[emptyRowIndex] = newRowData;
        return updated;
      } else {
        return [...prevRows, newRowData];
      }
    });
  };

  const completedCount = countCompletedRows(worksheetRows);

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleTabChange = (tab: ActiveTab) => {
    setActiveTab(tab);
    scrollToTop();
  };

  // Student Identity Gate before entering Beranda
  if (!hasEnteredLab) {
    return (
      <IdentitasSiswa
        initialIdentity={studentIdentity}
        onSubmitIdentity={handleSubmitIdentityGate}
      />
    );
  }

  return (
    <div className="min-h-screen bg-slate-50/60 text-slate-800 flex flex-col font-sans selection:bg-emerald-100 selection:text-emerald-900">
      {/* Top Navigation Bar */}
      <Header
        activeTab={activeTab}
        onSelectTab={handleTabChange}
        completedWorksheetCount={completedCount}
        quizSubmitted={quizSubmitted}
        studentIdentity={studentIdentity}
        onEditIdentity={() => setHasEnteredLab(false)}
      />

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-8">
        {activeTab === 'beranda' && (
          <Beranda
            onStart={() => handleTabChange('pengamatan')}
            onNavigateTab={handleTabChange}
          />
        )}

        {activeTab === 'pengamatan' && (
          <MejaPengamatan
            onGoToWorksheet={() => handleTabChange('lembarkerja')}
            onGoToBeranda={() => handleTabChange('beranda')}
            onAddOrganismToWorksheet={handleAddOrganismToWorksheet}
          />
        )}

        {activeTab === 'lembarkerja' && (
          <LembarKerja
            rows={worksheetRows}
            onUpdateRows={setWorksheetRows}
            onGoToQuiz={() => handleTabChange('kuis')}
            onGoToPengamatan={() => handleTabChange('pengamatan')}
            studentIdentity={studentIdentity}
            onUpdateIdentity={handleUpdateIdentity}
          />
        )}

        {activeTab === 'kuis' && (
          <Kuis
            onGoToBeranda={() => handleTabChange('beranda')}
            onGoToWorksheet={() => handleTabChange('lembarkerja')}
            onQuizCompletedChange={setQuizSubmitted}
            studentIdentity={studentIdentity}
            onEditIdentity={() => setHasEnteredLab(false)}
            scoreRecords={scoreRecords}
            onRecordScore={handleRecordScore}
            onDeleteScoreRecord={handleDeleteScoreRecord}
            onClearScoreRecords={handleClearScoreRecords}
            onImportScoreRecords={handleImportScoreRecords}
          />
        )}
      </main>

      {/* Footer */}
      <footer className="bg-white border-t border-slate-200 mt-auto py-6 print:hidden">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-500">
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 rounded-lg bg-emerald-100 flex items-center justify-center text-emerald-700">
              <Microscope className="w-3.5 h-3.5" />
            </div>
            <span>Virtual Lab Mini Biologi · Fase E (Kelas X SMA/MA)</span>
          </div>

          <div className="flex items-center gap-1.5">
            <span>Dikembangkan berdasarkan rancangan media pembelajaran</span>
            <span aria-hidden="true">·</span>
            <span className="font-medium text-slate-700">Rizki Rhomadhon</span>
            <span className="text-slate-400">(NPM 2413024077)</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
